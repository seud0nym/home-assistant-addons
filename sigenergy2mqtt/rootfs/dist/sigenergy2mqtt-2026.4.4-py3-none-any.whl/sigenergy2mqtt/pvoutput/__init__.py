"""PVOutput service wiring for Sigenergy sensors.

This module inspects all configured devices and sensors, selects compatible
topics, and builds the two PVOutput service devices used at runtime:
:class:`~sigenergy2mqtt.pvoutput.status.PVOutputStatusService` and
:class:`~sigenergy2mqtt.pvoutput.output.PVOutputOutputService`.
"""

from __future__ import annotations

from sigenergy2mqtt.common.consumption_source import ConsumptionSource
from sigenergy2mqtt.common.output_field import OutputField
from sigenergy2mqtt.common.status_field import StatusField
from sigenergy2mqtt.common.voltage_source import VoltageSource

__all__ = ["get_pvoutput_services"]

import logging
from typing import TYPE_CHECKING

from sigenergy2mqtt.common import UnitOfEnergy, UnitOfPower
from sigenergy2mqtt.config import active_config
from sigenergy2mqtt.devices.smartport.enphase import EnphaseVoltage
from sigenergy2mqtt.modbus import ModbusDataType
from sigenergy2mqtt.sensors.base import Sensor, TypedSensorMixin
from sigenergy2mqtt.sensors.inverter_read_only import DailyChargeEnergy, DailyDischargeEnergy, PhaseVoltage, PVVoltageSensor
from sigenergy2mqtt.sensors.plant_derived import GridSensorDailyExportEnergy, GridSensorDailyImportEnergy, TotalDailyPVEnergy, TotalLifetimePVEnergy, TotalPVPower
from sigenergy2mqtt.sensors.plant_read_only import (
    ESSTotalChargedEnergy,
    ESSTotalDischargedEnergy,
    PlantBatterySoC,
    PlantPVPower,
    PlantRatedEnergyCapacity,
    PlantTotalImportedEnergy,
    TotalLoadConsumption,
    TotalLoadDailyConsumption,
)

from .output import PVOutputOutputService
from .status import PVOutputStatusService
from .topic import Topic

if TYPE_CHECKING:
    from sigenergy2mqtt.main.thread_config import ThreadConfig


def get_gain(sensor: Sensor, negate: bool = False) -> float:
    """Return the topic gain that normalizes sensor values for PVOutput.

    Args:
        sensor: Source sensor whose scaling is converted into PVOutput units.
        negate: When ``True``, return the gain as a negative multiplier.
    """
    if sensor.gain is None:
        gain = 1.0
    elif sensor.unit in (UnitOfEnergy.KILO_WATT_HOUR, UnitOfPower.KILO_WATT) and sensor.gain == 100:
        gain = 10.0
    else:
        gain = float(sensor.gain)
    return gain if negate is False else gain * -1.0


def get_pvoutput_services(configs: list[ThreadConfig]) -> list[PVOutputStatusService | PVOutputOutputService]:
    """Build and configure PVOutput status/output service devices.

    The function scans all publishable sensors from all thread configs,
    maps each sensor to the relevant PVOutput status/output field(s), and
    enables raw publishing where required so MQTT receives numeric values that
    can be uploaded directly.

    Args:
        configs: Thread configurations containing discovered devices.

    Returns:
        A two-item list with status and output services, or an empty list when
        PVOutput support is disabled in configuration.
    """
    if not active_config.pvoutput.enabled:
        return []
    logger = logging.getLogger("pvoutput")
    logger.setLevel(active_config.pvoutput.log_level)

    plant_pv_power: PlantPVPower | None = None
    total_pv_power: TotalPVPower | None = None

    donation = {k: v for k, v in active_config.pvoutput.extended.items() if v != ""}  # type: ignore[reportGeneralTypeIssues]

    extended_data: dict[StatusField, str | None] = {field: None for field in StatusField}
    status_topics: dict[StatusField, list[Topic]] = {field: [] for field in StatusField}
    output_topics: dict[OutputField, list[Topic]] = {field: [] for field in OutputField}

    for device in [device for config in configs for device in config.devices]:
        for sensor in [sensor for sensor in device.get_all_sensors().values() if sensor.publishable and sensor.raw_state_topic is not None]:
            match sensor:
                case DailyChargeEnergy():
                    if active_config.pvoutput.consumption == ConsumptionSource.NET_OF_BATTERY:
                        sensor.publish_raw = True
                        output_topics[OutputField.CONSUMPTION].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor)))
                case DailyDischargeEnergy():
                    if active_config.pvoutput.consumption == ConsumptionSource.NET_OF_BATTERY:
                        sensor.publish_raw = True
                        output_topics[OutputField.CONSUMPTION].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor, negate=True)))
                case ESSTotalChargedEnergy():
                    sensor.publish_raw = True
                    status_topics[StatusField.BATTERY_CHARGED].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor)))
                    status_topics[StatusField.BATTERY_POWER].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor)))
                    if active_config.pvoutput.consumption == ConsumptionSource.NET_OF_BATTERY:
                        status_topics[StatusField.CONSUMPTION_ENERGY].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor)))
                        status_topics[StatusField.CONSUMPTION_POWER].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor)))
                case ESSTotalDischargedEnergy():
                    sensor.publish_raw = True
                    status_topics[StatusField.BATTERY_DISCHARGED].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor)))
                    status_topics[StatusField.BATTERY_POWER].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor, negate=True)))
                    if active_config.pvoutput.consumption == ConsumptionSource.NET_OF_BATTERY:
                        status_topics[StatusField.CONSUMPTION_ENERGY].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor, negate=True)))
                        status_topics[StatusField.CONSUMPTION_POWER].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor, negate=True)))
                case GridSensorDailyExportEnergy():
                    sensor.publish_raw = True
                    output_topics[OutputField.EXPORTS].append(Topic(sensor.raw_state_topic, None, get_gain(sensor)))
                case GridSensorDailyImportEnergy():
                    sensor.publish_raw = True
                    gain = get_gain(sensor)
                    if active_config.pvoutput.consumption == ConsumptionSource.IMPORTED:
                        output_topics[OutputField.CONSUMPTION].append(Topic(sensor.raw_state_topic, None, gain))
                    output_topics[OutputField.IMPORTS].append(Topic(sensor.raw_state_topic, None, gain))
                case PhaseVoltage():
                    if (
                        active_config.pvoutput.voltage == VoltageSource.L_N_AVG
                        or active_config.pvoutput.voltage == VoltageSource.L_L_AVG
                        or (active_config.pvoutput.voltage == VoltageSource.PHASE_A and sensor.phase == "A")
                        or (active_config.pvoutput.voltage == VoltageSource.PHASE_B and sensor.phase == "B")
                        or (active_config.pvoutput.voltage == VoltageSource.PHASE_C and sensor.phase == "C")
                    ):
                        status_topics[StatusField.VOLTAGE].append(Topic(sensor.state_topic, getattr(sensor, "scan_interval", None)))  # Need voltage, not raw
                case PlantBatterySoC():
                    status_topics[StatusField.BATTERY_SOC].append(Topic(sensor.state_topic, sensor.scan_interval))  # Need percentage, not raw
                case PlantPVPower():
                    plant_pv_power = sensor
                case PlantRatedEnergyCapacity():
                    sensor.publish_raw = True
                    status_topics[StatusField.BATTERY_CAPACITY].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor)))
                case PlantTotalImportedEnergy():
                    if active_config.pvoutput.consumption == ConsumptionSource.IMPORTED:
                        sensor.publish_raw = True
                        status_topics[StatusField.CONSUMPTION_ENERGY].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor)))
                case PVVoltageSensor() | EnphaseVoltage():
                    if active_config.pvoutput.voltage == VoltageSource.PV:
                        status_topics[StatusField.VOLTAGE].append(Topic(sensor.state_topic, getattr(sensor, "scan_interval", None)))  # Need voltage, not raw
                case TotalDailyPVEnergy():
                    sensor.publish_raw = True
                    output_topics[OutputField.GENERATION].append(Topic(sensor.raw_state_topic, None, get_gain(sensor)))
                case TotalLifetimePVEnergy():
                    sensor.publish_raw = True
                    gain = get_gain(sensor)
                    status_topics[StatusField.GENERATION_ENERGY].append(Topic(sensor.raw_state_topic, None, gain))
                    status_topics[StatusField.GENERATION_POWER].append(Topic(sensor.raw_state_topic, None, get_gain(sensor)))
                case TotalLoadConsumption():
                    if active_config.pvoutput.consumption in (ConsumptionSource.CONSUMPTION, ConsumptionSource.NET_OF_BATTERY):
                        sensor.publish_raw = True
                        status_topics[StatusField.CONSUMPTION_ENERGY].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor)))
                        status_topics[StatusField.CONSUMPTION_POWER].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor)))
                case TotalLoadDailyConsumption():
                    if active_config.pvoutput.consumption in (ConsumptionSource.CONSUMPTION, ConsumptionSource.NET_OF_BATTERY):
                        sensor.publish_raw = True
                        output_topics[OutputField.CONSUMPTION].append(Topic(sensor.raw_state_topic, sensor.scan_interval, get_gain(sensor)))
                case TotalPVPower():
                    total_pv_power = sensor
            for k, v in donation.items():
                if (sensor.__class__.__name__.lower() == v.lower() or sensor["object_id"] == v or f"sensor.{sensor['object_id']}" == v) and isinstance(sensor, TypedSensorMixin):
                    if sensor.data_type == ModbusDataType.STRING:
                        logger.warning(f"PVOutput extended field '{k}' is configured to use sensor '{v}', which does not have a numeric data type")
                    else:
                        key = StatusField(k)
                        status_topics[key].append(Topic(sensor.state_topic, getattr(sensor, "scan_interval", None), precision=sensor.precision))  # Used displayed value, not raw
                        extended_data[key] = sensor.device_class

    if total_pv_power is not None:
        total_pv_power.publish_raw = True
        output_topics[OutputField.PEAK_POWER].append(Topic(total_pv_power.raw_state_topic, None, get_gain(total_pv_power)))
    elif plant_pv_power is not None:
        plant_pv_power.publish_raw = True
        output_topics[OutputField.PEAK_POWER].append(Topic(plant_pv_power.raw_state_topic, plant_pv_power.scan_interval, get_gain(plant_pv_power)))

    if active_config.pvoutput.temperature_topic:
        status_topics[StatusField.TEMPERATURE].append(Topic(active_config.pvoutput.temperature_topic, scan_interval=None))

    status = PVOutputStatusService(logger, status_topics, extended_data)
    output = PVOutputOutputService(logger, output_topics)

    return [status, output]
