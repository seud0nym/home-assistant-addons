import sigenergy2mqtt.sensors.inverter_derived as derived
import sigenergy2mqtt.sensors.inverter_read_only as ro
from sigenergy2mqtt.common import DeviceType, Protocol
from sigenergy2mqtt.config import active_config
from sigenergy2mqtt.devices import ModbusDevice


class ESS(ModbusDevice):
    def __init__(
        self,
        plant_index: int,
        device_address: int,
        device_type: DeviceType,
        protocol_version: Protocol,
        model_id: str,
        serial_number: str,
    ):
        super().__init__(
            type=device_type,
            name=f"{model_id} {serial_number} ESS",
            plant_index=plant_index,
            device_address=device_address,
            model="Energy Storage System",
            protocol_version=protocol_version,
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_{device_address:03d}_{self.__class__.__name__.lower()}",
            model_id=model_id,
            serial_number=serial_number,
        )

        self._add_sensor(ro.RatedChargingPower(plant_index, device_address))
        self._add_sensor(ro.RatedDischargingPower(plant_index, device_address))
        self._add_sensor(ro.MaxBatteryChargePower(plant_index, device_address))
        self._add_sensor(ro.MaxBatteryDischargePower(plant_index, device_address))
        self._add_sensor(ro.AvailableBatteryChargeEnergy(plant_index, device_address))
        self._add_sensor(ro.AvailableBatteryDischargeEnergy(plant_index, device_address))
        self._add_sensor(ro.InverterBatterySoC(plant_index, device_address))
        self._add_sensor(ro.InverterBatterySoH(plant_index, device_address))
        self._add_sensor(ro.AverageCellTemperature(plant_index, device_address))
        self._add_sensor(ro.AverageCellVoltage(plant_index, device_address))
        self._add_sensor(ro.InverterAlarm3(plant_index, device_address))
        self._add_sensor(ro.InverterMaxBatteryTemperature(plant_index, device_address))
        self._add_sensor(ro.InverterMinBatteryTemperature(plant_index, device_address))
        self._add_sensor(ro.InverterMaxCellVoltage(plant_index, device_address))
        self._add_sensor(ro.InverterMinCellVoltage(plant_index, device_address))
        self._add_sensor(ro.DailyChargeEnergy(plant_index, device_address))
        self._add_sensor(ro.AccumulatedChargeEnergy(plant_index, device_address))
        self._add_sensor(ro.DailyDischargeEnergy(plant_index, device_address))
        self._add_sensor(ro.AccumulatedDischargeEnergy(plant_index, device_address))
        self._add_sensor(ro.RatedBatteryCapacity(plant_index, device_address))

        battery_power = ro.ChargeDischargePower(plant_index, device_address)
        if self._add_sensor(battery_power):  # will return False if sensor not added because not applicable to this device_type
            self._add_sensor(derived.InverterBatteryChargingPower(plant_index, device_address, battery_power))
            self._add_sensor(derived.InverterBatteryDischargingPower(plant_index, device_address, battery_power))
