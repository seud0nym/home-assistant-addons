"""sigenergy2mqtt configuration package."""

import logging
import os
import sys

from sigenergy2mqtt.common.consumption_source import ConsumptionSource
from sigenergy2mqtt.common.output_field import OutputField
from sigenergy2mqtt.common.status_field import StatusField
from sigenergy2mqtt.common.voltage_source import VoltageSource

from . import cli, const
from .config import Config, ConfigurationError, _create_persistent_state_path, _swap_active_config, active_config, configure_root_logging
from .settings import Settings

__all__ = [
    "active_config",
    "Config",
    "ConfigurationError",
    "configure_root_logging",
    "ConsumptionSource",
    "initialize",
    "initialize_async",
    "OutputField",
    "Settings",
    "StatusField",
    "VoltageSource",
    "_swap_active_config",
]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _apply_cli_to_env(variable: str, value: str | list[str]) -> None:
    """
    Set an environment variable from a CLI argument.
    """
    os.environ[variable] = ",".join(x for x in value) if isinstance(value, list) else str(value)
    logging.debug(f"Environment variable '{variable}' set from CLI: value='{'[REDACTED]' if 'PASSWORD' in os.environ[variable] or 'API_KEY' in os.environ[variable] else os.environ[variable]}'")


def _is_arg_explicitly_set(value) -> bool:
    """
    Return True only when an argparse value was explicitly supplied on the
    command line.

    argparse stores False for unset boolean flags and None for omitted
    optional arguments — neither should override a config value.
    """
    if value is None:
        return False
    if isinstance(value, bool):
        return value is True
    if isinstance(value, str) and value.lower() in ("false", ""):
        return False
    return True


def _promote_cli_to_env(args) -> None:
    """
    Copy explicitly-set CLI arguments into environment variables, unless an
    environment variable for that key is already present.

    This makes CLI and ENV identical from the perspective of the config
    loader: both arrive as env vars, ENV wins over CLI by virtue of already
    being set, and config file values are the fallback.

    The Modbus read-only flag is a special case: enabling it must atomically
    disable the two mutually-exclusive flags to keep the environment
    consistent before the config loader runs.
    """
    skip = {"clean", "discovery_only", "validate_only", "show_version"}

    for arg, value in vars(args).items():
        if arg in skip:
            continue

        if arg in (const.SIGENERGY2MQTT_PERSISTENCE_MQTT_REDUNDANCY):  # uses store_false, where as all other boolean flags use store_true
            if value is True:
                continue
        elif not _is_arg_explicitly_set(value):  # not explicitly set, skipping
            continue

        if os.getenv(arg):  # superseded by environment variable, skipping
            continue

        if arg == const.SIGENERGY2MQTT_MODBUS_READ_ONLY and value in (True, 1, "true", "True"):  # special case for read-only flag
            _apply_cli_to_env(const.SIGENERGY2MQTT_MODBUS_READ_ONLY, "true")  # publish read-only sensors
            _apply_cli_to_env(const.SIGENERGY2MQTT_MODBUS_READ_WRITE, "false")  # unpublish read-write sensors
            _apply_cli_to_env(const.SIGENERGY2MQTT_MODBUS_WRITE_ONLY, "false")  # unpublish write-only sensors
            continue

        _apply_cli_to_env(arg, value)


def _discover_config_file() -> str | None:
    """
    Return the path of the first config file to load, or None to fall back
    to environment-variable / default-value initialisation.

    Search order:
      1. $SIGENERGY2MQTT_CONFIG environment variable
      2. /etc/sigenergy2mqtt.yaml
      3. /data/sigenergy2mqtt.yaml  (common in container environments)
    """
    env_path = os.getenv(const.SIGENERGY2MQTT_CONFIG, "").strip()
    if env_path:
        if not os.path.isfile(env_path):
            raise ConfigurationError(f"Specified config file {env_path!r} does not exist.")
        return env_path

    for candidate in ("/etc/sigenergy2mqtt.yaml", "/data/sigenergy2mqtt.yaml"):
        if os.path.isfile(candidate):
            return candidate

    return None


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def initialize(args=None) -> bool:
    """
    Initialise the configuration module.

    Phase 1: Parse CLI, load YAML/env config WITHOUT auto-discovery.
    Auto-discovery is deferred until StateStore is available.

    Returns:
        False if early exit required, otherwise True
    """
    # 1. Parse CLI
    # When imported inside pytest, sys.argv contains pytest's own flags
    # (e.g. --collect-only) which are unrelated to sigenergy2mqtt and would
    # otherwise raise a parser error during test discovery.
    if args is None and "pytest" in sys.modules:
        args = []

    parsed_args = cli.parse_args(args)

    if parsed_args.show_version:
        return False  # Caller handles sys.exit if appropriate

    # 2. CLI → env (ENV already set takes priority, no duplicate processing logic)
    _promote_cli_to_env(parsed_args)

    # 3. Set persistent state path early
    try:
        active_config.persistent_state_path = _create_persistent_state_path()
    except ConfigurationError:
        raise
    except Exception as exc:
        raise ConfigurationError(f"Error processing configuration: {exc}") from exc

    # 5. Early-exit flags
    if getattr(parsed_args, "clean", False):
        active_config.clean = True

    validate_mode = getattr(parsed_args, "validate_only", None)
    active_config.validate_only_mode = validate_mode
    active_config.validate_show_credentials = validate_mode == "show_credentials"

    if validate_mode:
        return True

    if getattr(parsed_args, "discovery_only", False):
        active_config.home_assistant.discovery_only = True

    return True


async def initialize_async() -> None:
    """Phase 2 (async): load YAML + env + auto-discovery.
    Called from async_main() after StateStore is initialised.
    Also called for --validate mode (before validate_connections).
    """
    path = _discover_config_file()
    if path:
        await active_config.load(path)
    else:
        logging.debug("No config file found; using environment variables and defaults.")
        await active_config.reload()
