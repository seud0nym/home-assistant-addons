"""
Centralised runtime metrics store for sigenergy2mqtt.

All mutable state is protected by a :class:`threading.Lock`. Callers should
use the async helper methods rather than mutating class attributes directly.
Timing values are stored in milliseconds unless noted otherwise.

Call :meth:`Metrics.commence` from the service ``on_commencement`` handler to
initialise the time-sensitive ``_started`` and ``sigenergy2mqtt_started``
fields at actual service start rather than at module-import time.
"""

import asyncio
import logging
import threading
import time
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor, wait
from contextlib import asynccontextmanager
from datetime import datetime
from typing import ClassVar

from sigenergy2mqtt.config import active_config

logger = logging.getLogger(__name__)


class Metrics:
    """
    Class-level store for all sigenergy2mqtt operational metrics.

    Attributes are class variables so they can be read cheaply from anywhere
    without an instance. All writes go through the provided async helper
    methods, which acquire the internal :class:`threading.Lock` before mutating
    state, preventing TOCTOU races.
    """

    _lock: threading.Lock = threading.Lock()
    _pending_lock: threading.Lock = threading.Lock()
    _executor_lock: threading.Lock = threading.Lock()
    _executor: ThreadPoolExecutor | None = None
    _pending_updates: ClassVar[list[Future]] = []

    _started: float = 0.0
    """Monotonic reference timestamp set by :meth:`commence`. Used for rate calculations."""

    # ------------------------------------------------------------------
    # Modbus read metrics
    # ------------------------------------------------------------------

    sigenergy2mqtt_modbus_cache_fill_reads: int = 0
    """Number of reads that triggered a physical cache-fill."""

    sigenergy2mqtt_modbus_cache_hit_percentage: float = 0.0
    """Percentage of modbus reads satisfied from cache."""

    sigenergy2mqtt_modbus_reads: int = 0
    """Total number of modbus read calls."""

    sigenergy2mqtt_modbus_read_total: float = 0.0
    """Cumulative elapsed time of all modbus reads, in milliseconds."""

    sigenergy2mqtt_modbus_read_max: float = 0.0
    """Maximum single modbus read duration, in milliseconds."""

    sigenergy2mqtt_modbus_read_mean: float = 0.0
    """Mean modbus read duration per register read, in milliseconds."""

    sigenergy2mqtt_modbus_read_min: float = float("inf")
    """Minimum single modbus read duration, in milliseconds."""

    sigenergy2mqtt_modbus_read_errors: int = 0
    """Number of modbus read errors."""

    sigenergy2mqtt_modbus_physical_read_percentage: float = 0.0
    """Percentage of modbus reads that resulted in a physical bus read."""

    sigenergy2mqtt_modbus_skipped_errors: int = 0
    """Number of modbus skipped read errors."""

    # ------------------------------------------------------------------
    # MQTT publish metrics
    # ------------------------------------------------------------------

    sigenergy2mqtt_mqtt_publish_attempts: int = 0
    """Total number of logical MQTT state publish attempts."""

    sigenergy2mqtt_mqtt_publish_failures: int = 0
    """Number of MQTT state publish attempts that failed."""

    sigenergy2mqtt_mqtt_physical_publishes: int = 0
    """Number of attempts that resulted in an actual MQTT state publish."""

    sigenergy2mqtt_mqtt_physical_publish_percentage: float = 0.0
    """Percentage of publish attempts that resulted in physical publishes."""

    # ------------------------------------------------------------------
    # Modbus write metrics
    # ------------------------------------------------------------------

    sigenergy2mqtt_modbus_writes: int = 0
    """Total number of modbus write calls."""

    sigenergy2mqtt_modbus_write_total: float = 0.0
    """Cumulative elapsed time of all modbus writes, in milliseconds."""

    sigenergy2mqtt_modbus_write_max: float = 0.0
    """Maximum single modbus write duration, in milliseconds."""

    sigenergy2mqtt_modbus_write_mean: float = 0.0
    """Mean modbus write duration per write call, in milliseconds."""

    sigenergy2mqtt_modbus_write_min: float = float("inf")
    """Minimum single modbus write duration, in milliseconds."""

    sigenergy2mqtt_modbus_write_errors: int = 0
    """Number of modbus write errors."""

    # ------------------------------------------------------------------
    # InfluxDB metrics
    # ------------------------------------------------------------------

    sigenergy2mqtt_influxdb_writes: int = 0
    """Total number of InfluxDB write operations."""

    sigenergy2mqtt_influxdb_write_errors: int = 0
    """Number of InfluxDB write errors."""

    sigenergy2mqtt_influxdb_write_total: float = 0.0
    """Cumulative elapsed time of all InfluxDB writes, in milliseconds."""

    sigenergy2mqtt_influxdb_write_max: float = 0.0
    """Maximum single InfluxDB write duration, in milliseconds."""

    sigenergy2mqtt_influxdb_write_mean: float = 0.0
    """Mean InfluxDB write duration per write call, in milliseconds."""

    sigenergy2mqtt_influxdb_write_min: float = float("inf")
    """Minimum single InfluxDB write duration, in milliseconds."""

    sigenergy2mqtt_influxdb_queries: int = 0
    """Total number of InfluxDB query operations."""

    sigenergy2mqtt_influxdb_query_errors: int = 0
    """Number of InfluxDB query errors."""

    sigenergy2mqtt_influxdb_retries: int = 0
    """Number of InfluxDB retry attempts."""

    sigenergy2mqtt_influxdb_rate_limit_waits: int = 0
    """Number of times execution was paused due to InfluxDB rate limiting."""

    sigenergy2mqtt_influxdb_batch_total: int = 0
    """Total number of data points written to InfluxDB across all batches."""

    # ------------------------------------------------------------------
    # StateStore metrics
    # ------------------------------------------------------------------

    sigenergy2mqtt_state_store_saves: int = 0
    """Total number of StateStore save calls."""

    sigenergy2mqtt_state_store_save_errors: int = 0
    """Number of StateStore save errors."""

    sigenergy2mqtt_state_store_save_total: float = 0.0
    """Cumulative elapsed time of all StateStore saves, in milliseconds."""

    sigenergy2mqtt_state_store_save_max: float = 0.0
    """Maximum single StateStore save duration, in milliseconds."""

    sigenergy2mqtt_state_store_save_mean: float = 0.0
    """Mean StateStore save duration per save call, in milliseconds."""

    sigenergy2mqtt_state_store_save_min: float = float("inf")
    """Minimum single StateStore save duration, in milliseconds."""

    sigenergy2mqtt_state_store_loads: int = 0
    """Total number of StateStore load calls."""

    sigenergy2mqtt_state_store_load_hits: int = 0
    """Number of StateStore load calls that returned a value."""

    sigenergy2mqtt_state_store_load_hit_percentage: float = 0.0
    """Percentage of StateStore load calls that returned a value."""

    sigenergy2mqtt_state_store_load_errors: int = 0
    """Number of StateStore load errors."""

    sigenergy2mqtt_state_store_deletes: int = 0
    """Total number of StateStore delete calls."""

    sigenergy2mqtt_state_store_delete_errors: int = 0
    """Number of StateStore delete errors."""

    # ------------------------------------------------------------------
    # PVOutput metrics
    # ------------------------------------------------------------------

    sigenergy2mqtt_pvoutput_uploads: int = 0
    """Total number of PVOutput upload operations."""

    sigenergy2mqtt_pvoutput_upload_errors: int = 0
    """Number of PVOutput upload errors."""

    sigenergy2mqtt_pvoutput_upload_skipped: int = 0
    """Number of skipped PVOutput uploads."""

    sigenergy2mqtt_pvoutput_upload_total: float = 0.0
    """Cumulative elapsed time of all PVOutput uploads, in milliseconds."""

    sigenergy2mqtt_pvoutput_upload_max: float = 0.0
    """Maximum single PVOutput upload duration, in milliseconds."""

    sigenergy2mqtt_pvoutput_upload_mean: float = 0.0
    """Mean PVOutput upload duration per upload call, in milliseconds."""

    sigenergy2mqtt_pvoutput_upload_min: float = float("inf")
    """Minimum single PVOutput upload duration, in milliseconds."""

    # ------------------------------------------------------------------
    # Service identity
    # ------------------------------------------------------------------

    sigenergy2mqtt_started: str = ""
    """ISO-8601 wall-clock timestamp of service commencement, set by :meth:`commence`."""

    # ------------------------------------------------------------------
    # Class-level defaults for int/float metrics (used by :meth:`reset`)
    # ------------------------------------------------------------------

    _defaults: ClassVar[dict[str, int | float]] = {}

    @classmethod
    async def reset(cls) -> None:
        """Reset all public int and float metrics class fields to their default values."""

        def _update() -> None:
            def _operation() -> None:
                for name, default in cls._defaults.items():
                    setattr(cls, name, default)

            cls._update_with_lock(_operation, "metrics reset")

        cls._submit(_update)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @classmethod
    @asynccontextmanager
    async def lock(cls, timeout: float | None = 1.0):
        """Async context manager that acquires threading.Lock without blocking the event loop.

        Cancellation-safe: if a ``CancelledError`` is raised while the thread-pool
        worker is blocked inside ``threading.Lock.acquire``, the worker may still
        acquire the lock after the coroutine has been unwound.  A ``threading.Event``
        is used to signal the result back to the ``finally`` block so that the lock
        is always released, preventing permanent deadlocks across restart cycles.
        """
        timeout_arg = -1.0 if timeout is None else timeout

        # Use a threading.Event to capture whether the thread-pool worker actually
        # acquired the lock.  This lets the finally block release it even when a
        # CancelledError interrupts the await before the worker finishes.
        acquire_result: list[bool] = [False]
        done_event = threading.Event()

        def _acquire_with_signal() -> bool:
            result = cls._lock.acquire(timeout=timeout_arg)
            acquire_result[0] = result
            done_event.set()
            return result

        try:
            acquired = await asyncio.to_thread(_acquire_with_signal)
        except asyncio.CancelledError:
            # The await was cancelled but the thread may still be running.
            # Block (briefly, without holding the event loop) until the thread
            # finishes so we know whether it acquired the lock.
            await asyncio.to_thread(done_event.wait)
            if acquire_result[0]:
                cls._lock.release()
            raise

        if not acquired:
            raise TimeoutError("Failed to acquire Metrics lock within the timeout period.")

        try:
            yield
        finally:
            cls._lock.release()

    @classmethod
    def commence(cls) -> None:
        """
        Initialise time-sensitive fields and diagnostics collection.

        This is intentionally synchronous. It is called before any async
        workers are running, so no lock is required — direct assignment is
        both safe and necessary to avoid the ``run_until_complete`` /
        running-loop conflict that arises when a synchronous
        ``on_commencement`` handler tries to drive an async coroutine inside
        an already-running event loop.
        """
        cls._started = time.monotonic()
        cls.sigenergy2mqtt_started = datetime.now().astimezone().isoformat()

        from sigenergy2mqtt.diagnostics.collectors import DiagnosticsCollectors

        DiagnosticsCollectors.collect_metrics()

    @classmethod
    def _metrics_enabled(cls) -> bool:
        """Return True when metrics recording is enabled in configuration."""
        return bool(getattr(active_config, "metrics_enabled", True))

    @classmethod
    def _submit(cls, operation: Callable[[], None]) -> None:
        """Queue a metric update to the internal worker and return immediately."""
        if not cls._metrics_enabled():
            return

        with cls._executor_lock:
            if cls._executor is None:
                cls._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="metrics")
            executor = cls._executor

        future = executor.submit(operation)
        with cls._pending_lock:
            cls._pending_updates.append(future)

        def _cleanup(completed: Future) -> None:
            with cls._pending_lock:
                if completed in cls._pending_updates:
                    cls._pending_updates.remove(completed)

        future.add_done_callback(_cleanup)

    @classmethod
    def _update_with_lock(cls, operation: Callable[[], None], warning: str) -> None:
        """Run a metric update while holding the class lock."""
        if not cls._metrics_enabled():
            return

        try:
            # Standard synchronous lock for regular methods
            if not cls._lock.acquire(timeout=1.0):
                raise TimeoutError("Failed to acquire Metrics lock within the timeout period.")
            try:
                operation()
            finally:
                cls._lock.release()
        except (ArithmeticError, LookupError, OSError, ReferenceError, RuntimeError, TimeoutError, TypeError, ValueError) as exc:
            logger.warning(f"Error during {warning}: {exc!r}")

    @classmethod
    async def drain(cls, timeout: float | None = 1.0) -> None:
        """Await completion of queued metrics updates. Primarily intended for tests."""
        with cls._pending_lock:
            pending = list(cls._pending_updates)
        if not pending:
            return
        _, not_done = await asyncio.to_thread(wait, pending, timeout=timeout)
        if not_done:
            raise TimeoutError(f"Timed out waiting for {len(not_done)} metrics updates to finish.")

    @classmethod
    def shutdown(cls, timeout: float | None = 1.0) -> None:
        """Flush pending metric tasks and stop the internal worker thread.

        This is intended for process shutdown paths so interpreter teardown
        does not race with the executor's background thread.
        """
        with cls._pending_lock:
            pending = list(cls._pending_updates)
            cls._pending_updates.clear()

        with cls._executor_lock:
            executor = cls._executor
            cls._executor = None

        if executor is None:
            return

        not_done: set[Future] = set()
        if pending:
            _, not_done = wait(pending, timeout=timeout)
            if not_done:
                logger.warning(f"Metrics shutdown timed out with {len(not_done)} pending updates")

        executor.shutdown(wait=not not_done, cancel_futures=bool(not_done))

    @classmethod
    async def modbus_cache_fill(cls) -> None:
        """Increment the cache-fill read counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_modbus_cache_fill_reads += 1

            cls._update_with_lock(_operation, "modbus cache metrics collection")

        cls._submit(_update)

    @classmethod
    async def modbus_cache_hits(cls, reads: int, hits: int) -> None:
        """
        Record the cache-hit percentage for the current scan cycle.

        Args:
            reads: Total reads attempted in the cycle.
            hits:  Reads satisfied from cache in the cycle.
        """

        def _update() -> None:
            def _operation() -> None:
                percentage = round(hits / reads * 100.0, 2)
                cls.sigenergy2mqtt_modbus_cache_hit_percentage = percentage

            cls._update_with_lock(_operation, "modbus cache metrics collection")

        cls._submit(_update)

    @classmethod
    async def modbus_read(cls, registers: int, seconds: float) -> None:
        """
        Record a completed modbus read operation.

        Args:
            registers: Number of registers read in this operation. (Unused in current metrics but recorded for potential future use in mean calculations.)
            seconds:   Wall-clock duration of the operation in seconds.
        """

        def _update() -> None:
            def _operation() -> None:
                elapsed = seconds * 1000.0
                cls.sigenergy2mqtt_modbus_reads += 1
                cls.sigenergy2mqtt_modbus_physical_read_percentage = round(cls.sigenergy2mqtt_modbus_cache_fill_reads / cls.sigenergy2mqtt_modbus_reads * 100.0, 2)
                cls.sigenergy2mqtt_modbus_read_total += elapsed
                # min/max computed inside the lock to prevent TOCTOU races
                cls.sigenergy2mqtt_modbus_read_max = max(cls.sigenergy2mqtt_modbus_read_max, elapsed)
                cls.sigenergy2mqtt_modbus_read_min = min(cls.sigenergy2mqtt_modbus_read_min, elapsed)
                cls.sigenergy2mqtt_modbus_read_mean = cls.sigenergy2mqtt_modbus_read_total / cls.sigenergy2mqtt_modbus_reads if cls.sigenergy2mqtt_modbus_reads > 0 else 0.0

            cls._update_with_lock(_operation, "modbus read metrics collection")

        cls._submit(_update)

    @classmethod
    async def modbus_read_error(cls) -> None:
        """Increment the modbus read error counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_modbus_read_errors += 1

            cls._update_with_lock(_operation, "modbus read error metrics collection")

        cls._submit(_update)

    @classmethod
    def modbus_skipped_error(cls) -> None:
        """Increment the modbus skipped read counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_modbus_skipped_errors += 1

            cls._update_with_lock(_operation, "modbus skipped read metrics collection")

        cls._submit(_update)

    @classmethod
    async def modbus_write(cls, registers: int, seconds: float) -> None:
        """
        Record a completed modbus write operation.

        Args:
            registers: Number of registers written in this operation.
            seconds:   Wall-clock duration of the operation in seconds.
        """

        def _update() -> None:
            def _operation() -> None:
                elapsed = seconds * 1000.0
                cls.sigenergy2mqtt_modbus_writes += registers
                cls.sigenergy2mqtt_modbus_write_total += elapsed
                # min/max computed inside the lock to prevent TOCTOU races
                cls.sigenergy2mqtt_modbus_write_max = max(cls.sigenergy2mqtt_modbus_write_max, elapsed)
                cls.sigenergy2mqtt_modbus_write_min = min(cls.sigenergy2mqtt_modbus_write_min, elapsed)
                cls.sigenergy2mqtt_modbus_write_mean = cls.sigenergy2mqtt_modbus_write_total / cls.sigenergy2mqtt_modbus_writes if cls.sigenergy2mqtt_modbus_writes > 0 else 0.0

            cls._update_with_lock(_operation, "modbus write metrics collection")

        cls._submit(_update)

    @classmethod
    async def mqtt_publish_attempt(cls, physical_publish: bool) -> None:
        """Record an MQTT state publish attempt.

        Args:
            physical_publish: ``True`` when the state message was physically
                published to MQTT; ``False`` when it was suppressed or failed.
        """

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_mqtt_publish_attempts += 1
                if physical_publish:
                    cls.sigenergy2mqtt_mqtt_physical_publishes += 1
                cls.sigenergy2mqtt_mqtt_physical_publish_percentage = (
                    round(cls.sigenergy2mqtt_mqtt_physical_publishes / cls.sigenergy2mqtt_mqtt_publish_attempts * 100.0, 2) if cls.sigenergy2mqtt_mqtt_publish_attempts > 0 else 0.0
                )

            cls._update_with_lock(_operation, "mqtt publish attempt metrics collection")

        cls._submit(_update)

    @classmethod
    async def mqtt_publish_failure(cls) -> None:
        """Increment the MQTT state publish failure counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_mqtt_publish_failures += 1

            cls._update_with_lock(_operation, "mqtt publish failure metrics collection")

        cls._submit(_update)

    @classmethod
    async def modbus_write_error(cls) -> None:
        """Increment the modbus write error counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_modbus_write_errors += 1

            cls._update_with_lock(_operation, "modbus write error metrics collection")

        cls._submit(_update)

    @classmethod
    async def influxdb_write(cls, batch_size: int, seconds: float) -> None:
        """
        Record a completed InfluxDB write operation.

        Args:
            batch_size: Number of data points in the written batch.
            seconds:    Wall-clock duration of the operation in seconds.
        """

        def _update() -> None:
            def _operation() -> None:
                elapsed = seconds * 1000.0
                cls.sigenergy2mqtt_influxdb_writes += 1
                cls.sigenergy2mqtt_influxdb_batch_total += batch_size
                cls.sigenergy2mqtt_influxdb_write_total += elapsed
                # min/max computed inside the lock to prevent TOCTOU races
                cls.sigenergy2mqtt_influxdb_write_max = max(cls.sigenergy2mqtt_influxdb_write_max, elapsed)
                cls.sigenergy2mqtt_influxdb_write_min = min(cls.sigenergy2mqtt_influxdb_write_min, elapsed)
                cls.sigenergy2mqtt_influxdb_write_mean = cls.sigenergy2mqtt_influxdb_write_total / cls.sigenergy2mqtt_influxdb_writes if cls.sigenergy2mqtt_influxdb_writes > 0 else 0.0

            cls._update_with_lock(_operation, "influxdb write metrics collection")

        cls._submit(_update)

    @classmethod
    async def influxdb_write_error(cls) -> None:
        """Increment the InfluxDB write error counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_influxdb_write_errors += 1

            cls._update_with_lock(_operation, "influxdb write error metrics collection")

        cls._submit(_update)

    @classmethod
    async def influxdb_query(cls) -> None:
        """Record a completed InfluxDB query operation."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_influxdb_queries += 1

            cls._update_with_lock(_operation, "influxdb query metrics collection")

        cls._submit(_update)

    @classmethod
    async def influxdb_query_error(cls) -> None:
        """Increment the InfluxDB query error counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_influxdb_query_errors += 1

            cls._update_with_lock(_operation, "influxdb query error metrics collection")

        cls._submit(_update)

    @classmethod
    async def influxdb_retry(cls) -> None:
        """Increment the InfluxDB retry counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_influxdb_retries += 1

            cls._update_with_lock(_operation, "influxdb retry metrics collection")

        cls._submit(_update)

    @classmethod
    async def influxdb_rate_limit_wait(cls) -> None:
        """Increment the InfluxDB rate-limit wait counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_influxdb_rate_limit_waits += 1

            cls._update_with_lock(_operation, "influxdb rate limit metrics collection")

        cls._submit(_update)

    @classmethod
    async def state_store_save(cls, seconds: float) -> None:
        """
        Record a completed StateStore save operation.

        Args:
            seconds: Wall-clock duration of the operation in seconds.
        """

        def _update() -> None:
            def _operation() -> None:
                elapsed = seconds * 1000.0
                cls.sigenergy2mqtt_state_store_saves += 1
                cls.sigenergy2mqtt_state_store_save_total += elapsed
                cls.sigenergy2mqtt_state_store_save_max = max(cls.sigenergy2mqtt_state_store_save_max, elapsed)
                cls.sigenergy2mqtt_state_store_save_min = min(cls.sigenergy2mqtt_state_store_save_min, elapsed)
                cls.sigenergy2mqtt_state_store_save_mean = cls.sigenergy2mqtt_state_store_save_total / cls.sigenergy2mqtt_state_store_saves if cls.sigenergy2mqtt_state_store_saves > 0 else 0.0

            cls._update_with_lock(_operation, "state store save metrics collection")

        cls._submit(_update)

    @classmethod
    async def state_store_save_error(cls) -> None:
        """Increment the StateStore save error counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_state_store_save_errors += 1

            cls._update_with_lock(_operation, "state store save error metrics collection")

        cls._submit(_update)

    @classmethod
    async def state_store_load(cls, hit: bool) -> None:
        """Record a completed StateStore load call.

        Args:
            hit: ``True`` when the load returned a value; ``False`` when it
                 returned ``None`` (miss, stale, or invalid).
        """

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_state_store_loads += 1
                if hit:
                    cls.sigenergy2mqtt_state_store_load_hits += 1
                cls.sigenergy2mqtt_state_store_load_hit_percentage = (
                    round(cls.sigenergy2mqtt_state_store_load_hits / cls.sigenergy2mqtt_state_store_loads * 100.0, 2) if cls.sigenergy2mqtt_state_store_loads > 0 else 0.0
                )

            cls._update_with_lock(_operation, "state store load metrics collection")

        cls._submit(_update)

    @classmethod
    async def state_store_load_error(cls) -> None:
        """Increment the StateStore load error counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_state_store_load_errors += 1

            cls._update_with_lock(_operation, "state store load error metrics collection")

        cls._submit(_update)

    @classmethod
    async def state_store_delete(cls) -> None:
        """Record a completed StateStore delete call."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_state_store_deletes += 1

            cls._update_with_lock(_operation, "state store delete metrics collection")

        cls._submit(_update)

    @classmethod
    async def state_store_delete_error(cls) -> None:
        """Increment the StateStore delete error counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_state_store_delete_errors += 1

            cls._update_with_lock(_operation, "state store delete error metrics collection")

        cls._submit(_update)

    @classmethod
    async def pvoutput_upload(cls, seconds: float) -> None:
        """
        Record a completed PVOutput upload operation.

        Args:
            seconds: Wall-clock duration of the operation in seconds.
        """

        def _update() -> None:
            def _operation() -> None:
                elapsed = seconds * 1000.0
                cls.sigenergy2mqtt_pvoutput_uploads += 1
                cls.sigenergy2mqtt_pvoutput_upload_total += elapsed
                cls.sigenergy2mqtt_pvoutput_upload_max = max(cls.sigenergy2mqtt_pvoutput_upload_max, elapsed)
                cls.sigenergy2mqtt_pvoutput_upload_min = min(cls.sigenergy2mqtt_pvoutput_upload_min, elapsed)
                cls.sigenergy2mqtt_pvoutput_upload_mean = cls.sigenergy2mqtt_pvoutput_upload_total / cls.sigenergy2mqtt_pvoutput_uploads if cls.sigenergy2mqtt_pvoutput_uploads > 0 else 0.0

            cls._update_with_lock(_operation, "pvoutput upload metrics collection")

        cls._submit(_update)

    @classmethod
    async def pvoutput_upload_error(cls) -> None:
        """Increment the PVOutput upload error counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_pvoutput_upload_errors += 1

            cls._update_with_lock(_operation, "pvoutput upload error metrics collection")

        cls._submit(_update)

    @classmethod
    async def pvoutput_upload_skipped(cls) -> None:
        """Increment the PVOutput upload skipped counter."""

        def _update() -> None:
            def _operation() -> None:
                cls.sigenergy2mqtt_pvoutput_upload_skipped += 1

            cls._update_with_lock(_operation, "pvoutput upload skipped metrics collection")

        cls._submit(_update)


# Snapshot the pristine default values at class-definition time, before any
# metrics have been mutated, so that :meth:`Metrics.reset` restores them
# faithfully.
for _name, _value in vars(Metrics).items():
    if not _name.startswith("_") and isinstance(_value, (int, float)):
        Metrics._defaults[_name] = _value
