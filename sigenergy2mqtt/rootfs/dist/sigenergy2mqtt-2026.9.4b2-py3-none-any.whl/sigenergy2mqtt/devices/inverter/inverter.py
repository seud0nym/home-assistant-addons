import asyncio
import logging
from datetime import timezone
from typing import cast

import sigenergy2mqtt.sensors.inverter_read_only as ro
import sigenergy2mqtt.sensors.inverter_read_write as rw
from sigenergy2mqtt.common import DeviceType, FirmwareVersion, HybridInverter, ProtocolVersion, PVInverter
from sigenergy2mqtt.config import active_config
from sigenergy2mqtt.devices import ModbusDevice
from sigenergy2mqtt.modbus import ModbusClient
from sigenergy2mqtt.sensors.inverter_derived import InverterSelfConsumedPower, PVStringPower

from .ess import ESS
from .pv_string import PVString

logger = logging.getLogger(__name__)


class Inverter(ModbusDevice):
    def __init__(
        self,
        plant_index: int,
        device_address: int,
        device_type: DeviceType,
        protocol_version: ProtocolVersion,
        model_id: str,
        serial: str,
        firmware: str,
    ):
        super().__init__(
            type=device_type,
            name=f"{model_id} {serial}",
            plant_index=plant_index,
            device_address=device_address,
            model=device_type.__str__(),
            protocol_version=protocol_version,
            # HA device registry attributes
            sn=serial,
            hw=firmware,  # MUST use hw abbreviation - see InverterFirmwareVersion
            model_id=model_id,
            serial=serial,
        )

    @classmethod
    async def create(cls, plant_index: int, device_address: int, device_type: DeviceType, protocol_version: ProtocolVersion, tz: timezone, modbus_client: ModbusClient) -> "Inverter":
        model = ro.InverterModel(plant_index, device_address)
        pv_string_count = ro.PVStringCount(plant_index, device_address)
        firmware_version = ro.InverterFirmwareVersion(plant_index, device_address)
        serial_number = ro.InverterSerialNumber(plant_index, device_address)
        pack_bcu_count = ro.PACKBCUCount(plant_index, device_address)

        # Fetch async values in parallel for common inverter sensors
        firmware, model_id, strings, serial = await asyncio.gather(
            firmware_version.get_state(modbus_client=modbus_client),
            model.get_state(modbus_client=modbus_client),
            pv_string_count.get_state(modbus_client=modbus_client),
            serial_number.get_state(modbus_client=modbus_client),
        )

        if isinstance(device_type, HybridInverter):
            battery_count = cast(int, await pack_bcu_count.get_state(modbus_client=modbus_client))
        else:
            battery_count = 0

        inverter = cls(plant_index, device_address, device_type, protocol_version, cast(str, model_id), cast(str, serial), cast(str, firmware))
        await inverter._register_child_devices(plant_index, device_address, device_type, protocol_version, cast(str, model_id), cast(str, serial), cast(int, strings), battery_count)
        await inverter._register_sensors(plant_index, device_address, firmware_version, model, serial_number, tz, pv_string_count, pack_bcu_count, battery_count, modbus_client)

        try:
            parsed_firmware = FirmwareVersion(cast(str, firmware))
            if active_config.ems_mode_check and parsed_firmware.service_pack >= 113:
                logger.debug(f"{inverter.log_identity} ({serial}): Remote EMS Mode check disabled in firmware after SPC113 ({firmware})")
                active_config.ems_mode_check = False
        except ValueError:
            logger.warning(f"{inverter.log_identity} ({serial}): Unable to parse firmware version '{firmware}' for ems_mode_check enforcement")
        return inverter

    async def _register_child_devices(
        self,
        plant_index: int,
        device_address: int,
        device_type: DeviceType,
        protocol_version: ProtocolVersion,
        model_id: str,
        serial: str,
        strings: int,
        battery_count: int,
    ) -> None:
        address = 31027  # PV String 1 Voltage register
        for n in range(1, min(4, strings) + 1):
            self._add_child_device(
                PVString(
                    plant_index=plant_index,
                    device_address=device_address,
                    device_type=device_type,
                    model_id=model_id,
                    serial_number=serial,
                    string_number=n,
                    voltage_address=address,
                    current_address=address + 1,
                    protocol_version=ProtocolVersion.V1_8,
                )
            )
            address += 2  # voltage is in the first register, current in the second
        if protocol_version >= ProtocolVersion.V2_4:
            address = 31042  # PV String 5 Voltage register
            for n in range(5, min(16, strings) + 1):
                self._add_child_device(
                    PVString(
                        plant_index=plant_index,
                        device_address=device_address,
                        device_type=device_type,
                        model_id=model_id,
                        serial_number=serial,
                        string_number=n,
                        voltage_address=address,
                        current_address=address + 1,
                        protocol_version=ProtocolVersion.V2_4,
                    )
                )
                address += 2  # voltage is in the first register, current in the second
        if protocol_version >= ProtocolVersion.V2_8 and isinstance(device_type, PVInverter):
            address = 31066  # PV String 17 Voltage register
            for n in range(17, min(36, strings) + 1):
                self._add_child_device(
                    PVString(
                        plant_index=plant_index,
                        device_address=device_address,
                        device_type=device_type,
                        model_id=model_id,
                        serial_number=serial,
                        string_number=n,
                        voltage_address=address,
                        current_address=address + 1,
                        protocol_version=ProtocolVersion.V2_8,
                    )
                )
                address += 2  # voltage is in the first register, current in the second

        if battery_count > 0:
            self._add_child_device(
                ESS(
                    plant_index=plant_index,
                    device_address=device_address,
                    device_type=device_type,
                    protocol_version=protocol_version,
                    model_id=model_id,
                    serial_number=serial,
                )
            )
        else:
            logger.debug(f"{self.log_identity} Skipped creating ESS device: {battery_count=}")

    async def _register_sensors(
        self,
        plant_index: int,
        device_address: int,
        firmware_version: ro.InverterFirmwareVersion,
        model: ro.InverterModel,
        serial_number: ro.InverterSerialNumber,
        tz: timezone,
        pv_string_count: ro.PVStringCount,
        pack_bcu_count: ro.PACKBCUCount,
        battery_count: int,
        modbus_client: ModbusClient,
    ) -> None:
        output_type = ro.OutputType(plant_index, device_address)
        power_phases = ro.OutputType.to_phases(await output_type.get_state(modbus_client=modbus_client))

        active_power = ro.ActivePower(plant_index, device_address)
        reactive_power = ro.ReactivePower(plant_index, device_address)

        self._add_sensor(model)
        self._add_sensor(serial_number)
        self._add_sensor(firmware_version)
        self._add_sensor(ro.RatedActivePower(plant_index, device_address))
        self._add_sensor(ro.MaxRatedApparentPower(plant_index, device_address))
        self._add_sensor(ro.InverterMaxActivePower(plant_index, device_address))
        self._add_sensor(ro.MaxAbsorptionPower(plant_index, device_address))
        self._add_sensor(ro.InverterRunningState(plant_index, device_address))
        self._add_sensor(ro.MaxActivePowerAdjustment(plant_index, device_address))
        self._add_sensor(ro.MinActivePowerAdjustment(plant_index, device_address))
        self._add_sensor(ro.MaxReactivePowerAdjustment(plant_index, device_address))
        self._add_sensor(ro.MinReactivePowerAdjustment(plant_index, device_address))
        self._add_sensor(active_power)
        self._add_sensor(reactive_power)
        self._add_sensor(ro.InverterPCSAlarm(plant_index, device_address, ro.InverterAlarm1(plant_index, device_address), ro.InverterAlarm2(plant_index, device_address)))
        self._add_sensor(ro.InverterAlarm4(plant_index, device_address))
        self._add_sensor(ro.RatedGridVoltage(plant_index, device_address))
        self._add_sensor(ro.RatedGridFrequency(plant_index, device_address))
        self._add_sensor(ro.GridFrequency(plant_index, device_address))
        self._add_sensor(ro.InverterTemperature(plant_index, device_address))
        self._add_sensor(output_type)
        self._add_sensor(ro.PhaseVoltage(plant_index, device_address, "A", power_phases))
        self._add_sensor(ro.PhaseCurrent(plant_index, device_address, "A", power_phases))
        if power_phases > 1:
            self._add_sensor(ro.PhaseVoltage(plant_index, device_address, "B", power_phases))
            self._add_sensor(ro.PhaseCurrent(plant_index, device_address, "B", power_phases))
        if power_phases > 2:
            self._add_sensor(ro.PhaseVoltage(plant_index, device_address, "C", power_phases))
            self._add_sensor(ro.PhaseCurrent(plant_index, device_address, "C", power_phases))
            self._add_sensor(ro.LineVoltage(plant_index, device_address, "A-B"))
            self._add_sensor(ro.LineVoltage(plant_index, device_address, "B-C"))
            self._add_sensor(ro.LineVoltage(plant_index, device_address, "C-A"))
        self._add_sensor(ro.PowerFactor(plant_index, device_address, active_power, reactive_power))
        self._add_sensor(ro.MPPTCount(plant_index, device_address))
        self._add_sensor(pack_bcu_count)
        self._add_sensor(pv_string_count)
        self._add_sensor(ro.InverterPVPower(plant_index, device_address))
        self._add_sensor(ro.InsulationResistance(plant_index, device_address))
        self._add_sensor(ro.StartupTime(plant_index, device_address, tz))
        self._add_sensor(ro.ShutdownTime(plant_index, device_address, tz))

        self._add_sensor(rw.InverterActivePowerFixedValueAdjustment(plant_index, device_address))
        self._add_sensor(rw.InverterReactivePowerFixedValueAdjustment(plant_index, device_address))
        self._add_sensor(rw.InverterActivePowerPercentageAdjustment(plant_index, device_address))
        self._add_sensor(rw.InverterReactivePowerQSAdjustment(plant_index, device_address))
        self._add_sensor(rw.InverterPowerFactorAdjustment(plant_index, device_address))
        self._add_sensor(rw.InverterStatus(plant_index, device_address))

        self._add_sensor(ro.InverterPVLifetimeGeneration(plant_index, device_address))
        self._add_sensor(ro.InverterPVDailyGeneration(plant_index, device_address))

        self._add_sensor(ro.InverterActivePowerFixedValueAdjustmentFeedback(plant_index, device_address))
        self._add_sensor(ro.InverterReactivePowerFixedValueAdjustmentFeedback(plant_index, device_address))
        self._add_sensor(ro.InverterActivePowerPercentageAdjustmentFeedback(plant_index, device_address))
        self._add_sensor(ro.InverterReactivePowerPercentageAdjustmentFeedback(plant_index, device_address))
        self._add_sensor(ro.InverterPowerFactorAdjustmentFeedback(plant_index, device_address))

        if battery_count > 0:
            battery_power = cast(ro.ChargeDischargePower, self.get_sensor(ro.ChargeDischargePower, search_children=True))
            if battery_power is not None and battery_power.publishable:
                pv_string_power: list[PVStringPower] = [s for s in self.get_all_sensors().values() if isinstance(s, PVStringPower) and s.publishable]
                if len(pv_string_power) > 0:
                    self._add_sensor(InverterSelfConsumedPower(plant_index, device_address, active_power, battery_power, *pv_string_power))
                else:
                    logger.warning(f"{self.log_identity} Skipped creating InverterSelfConsumedPower: No publishable PVStringPower sensors found")
            else:
                logger.warning(f"{self.log_identity} Skipped creating InverterSelfConsumedPower: No publishable ChargeDischargePower sensor found")

        # Add the reserved registers to optimise sensor scanning
        self._add_sensor(ro.ReservedDailyExportEnergy(plant_index, device_address))
        self._add_sensor(ro.ReservedAccumulatedExportEnergy(plant_index, device_address))
        self._add_sensor(ro.ReservedDailyImportEnergy(plant_index, device_address))
        self._add_sensor(ro.ReservedAccumulatedImportEnergy(plant_index, device_address))
        self._add_sensor(ro.Reserved30610(plant_index, device_address))
        self._add_sensor(rw.ReservedGridCode(plant_index, device_address))
        self._add_sensor(rw.ReservedInverterRemoteEMSDispatch(plant_index, device_address))
