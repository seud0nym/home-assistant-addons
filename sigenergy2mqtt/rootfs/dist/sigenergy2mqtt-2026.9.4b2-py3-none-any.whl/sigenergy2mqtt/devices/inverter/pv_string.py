from sigenergy2mqtt.common import DeviceType, ProtocolVersion
from sigenergy2mqtt.config import active_config
from sigenergy2mqtt.devices import ModbusDevice
from sigenergy2mqtt.sensors.inverter_derived import PVStringDailyEnergy, PVStringLifetimeEnergy, PVStringPower
from sigenergy2mqtt.sensors.inverter_read_only import PVCurrentSensor, PVVoltageSensor


class PVString(ModbusDevice):
    def __init__(
        self,
        plant_index: int,
        device_address: int,
        device_type: DeviceType,
        model_id: str,
        serial_number: str,
        string_number: int,
        voltage_address: int,
        current_address: int,
        protocol_version: ProtocolVersion,
    ):
        self.string_number = string_number
        super().__init__(
            type=device_type,
            name=f"{model_id} {serial_number} PV String {string_number}",
            plant_index=plant_index,
            device_address=device_address,
            model="PV String",
            protocol_version=protocol_version,
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_{device_address:03d}_{self.__class__.__name__.lower()}{string_number}",
            model_id=model_id,
            serial_number=serial_number,
            string_number=string_number,
        )

        voltage = PVVoltageSensor(plant_index, device_address, voltage_address, string_number, protocol_version)
        current = PVCurrentSensor(plant_index, device_address, current_address, string_number, protocol_version)
        power = PVStringPower(plant_index, device_address, string_number, voltage, current)
        lifetime_energy = PVStringLifetimeEnergy(plant_index, device_address, string_number, power)
        daily_energy = PVStringDailyEnergy(plant_index, device_address, string_number, lifetime_energy)

        self._add_sensor(voltage)
        self._add_sensor(current)
        self._add_sensor(power)
        self._add_sensor(lifetime_energy)
        self._add_sensor(daily_energy)

    def _build_log_identity(self) -> str:
        base_identity = super()._build_log_identity()
        return f"{base_identity[:-1]},string={self.string_number}]"
