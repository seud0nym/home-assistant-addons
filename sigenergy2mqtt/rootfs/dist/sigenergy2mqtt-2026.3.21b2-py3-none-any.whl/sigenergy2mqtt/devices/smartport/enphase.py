if __name__ == "__main__":
    import sys
    from pathlib import Path

    # .parents[2] goes up three levels: file -> dir -> .. -> .. -> ..
    parent_dir = (Path(__file__).resolve().parents[2] / "src").resolve()
    sys.path.insert(0, str(parent_dir))

import asyncio
import json
import logging
import os
import xml.etree.ElementTree as xml
from time import sleep
from typing import Any, Deque, cast

import requests

# disable warnings of self signed certificate https
import urllib3

from sigenergy2mqtt.common import ConsumptionMethod, DeviceClass, Protocol, StateClass, UnitOfElectricCurrent, UnitOfElectricPotential, UnitOfEnergy, UnitOfFrequency, UnitOfPower, UnitOfReactivePower
from sigenergy2mqtt.config import active_config
from sigenergy2mqtt.config.models.smart_port import SmartPortModule
from sigenergy2mqtt.devices import Device
from sigenergy2mqtt.modbus import ModbusDataType
from sigenergy2mqtt.sensors.base import DerivedSensor, EnergyDailyAccumulationSensor, PVPowerSensor, ReadableSensorMixin, Sensor, SubstituteMixin

urllib3.disable_warnings()


class EnphaseSensor(DerivedSensor):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def set_source_values(self, sensor: Sensor, values: Deque[tuple[float, Any]]) -> bool:
        if not isinstance(sensor, EnphasePVPower):
            logging.warning(f"Attempt to call {self.__class__.__name__}.set_source_values from {sensor.__class__.__name__}")
            return False
        value = values[-1][1]
        if value < 0:
            if self.debug_logging:
                logging.info(f"{self.__class__.__name__} value is negative ({value}), setting to 0.0")
            value = 0.0
        self.set_latest_state(value)
        return True


class EnphasePVPower(ReadableSensorMixin, Sensor, PVPowerSensor):
    def __init__(self, plant_index: int, serial_number: str, host: str, username: str, password: str):
        super().__init__(
            name="PV Power",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_enphase_{serial_number}_active_power",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_enphase_{serial_number}_active_power",
            unit=UnitOfPower.WATT,
            device_class=DeviceClass.POWER,
            state_class=StateClass.MEASUREMENT,
            icon="mdi:solar-power",
            gain=None,
            precision=2,
            scan_interval=active_config.modbus[0].scan_interval.realtime,
        )
        self["enabled_by_default"] = True

        if active_config.log_level == logging.DEBUG and not self.debug_logging:
            requests_log = logging.getLogger("urllib3")
            requests_log.setLevel(logging.INFO)
            requests_log.propagate = True

        self._serial_number = serial_number
        self._host = host
        self._username = username
        self._password = password
        self._token = ""
        self._failover_initiated = False
        self._max_failures = 5
        self._max_failures_retry_interval = 30

    def _process_meter_reading(self, reading: list[dict]) -> bool:
        """Process the meter reading JSON response and update sensor state.

        Args:
            reading: The parsed JSON response from /ivp/meters/readings endpoint

        Returns:
            True if processing was successful

        Raises:
            Exception: If the reading format is invalid or required fields are missing
        """
        solar = reading[0]
        state_is = float(solar["activePower"])
        if state_is < 0:
            if self.debug_logging:
                logging.info(f"{self.__class__.__name__} activePower negative ({state_is}), setting to 0.0")
            state_is = 0.0
        self.set_state(state_is)
        for sensor in self.derived_sensors.values():
            latest = self._states.pop()
            match sensor:
                case EnphaseLifetimePVEnergy():
                    self._states.append((latest[0], solar["actEnergyDlvd"]))
                case EnphaseCurrent():
                    self._states.append((latest[0], solar["current"]))
                case EnphaseFrequency():
                    self._states.append((latest[0], solar["freq"]))
                case EnphasePowerFactor():
                    self._states.append((latest[0], solar["pwrFactor"]))
                case EnphaseReactivePower():
                    self._states.append((latest[0], solar["reactivePower"]))
                case EnphaseVoltage():
                    self._states.append((latest[0], solar["voltage"]))
                case _:
                    self._states.append(latest)
            sensor.set_source_values(self, self._states)
        latest = self._states.pop()
        self._states.append((latest[0], state_is))
        self._failover_initiated = False
        return True

    async def _update_internal_state(self, **kwargs) -> bool:
        reauthenticate = False if "reauthenticate" not in kwargs else kwargs["reauthenticate"]
        token = self.get_token(reauthenticate)
        url = f"https://{self._host}/ivp/meters/readings"
        headers = {"Authorization": f"Bearer {token}"}
        if self.debug_logging:
            logging.debug(f"{self.__class__.__name__} Fetching data for Envoy device {self._serial_number} from {url}")
        try:
            with requests.get(url, timeout=self.scan_interval, verify=False, headers=headers) as response:
                if response.status_code == 401:
                    logging.warning(f"{self.__class__.__name__} Authentication failed: Generating new token")
                    return await self._update_internal_state(reauthenticate=True)
                elif response.status_code != 200:
                    logging.error(f"{self.__class__.__name__} Failed to connect to {url}: Response={response}")
                    raise Exception(f"{self.__class__.__name__} Failed to connect to {url}: Response={response}")
                else:
                    elapsed_time = response.elapsed.total_seconds()
                    if self.debug_logging:
                        logging.debug(f"{self.__class__.__name__} Response from {url} took {elapsed_time:.2f} seconds")
                    try:
                        reading = response.json()
                        if self.debug_logging:
                            logging.debug(f"{self.__class__.__name__} Response from {url}: JSON={json.dumps(reading)}")
                        return self._process_meter_reading(reading)
                    except Exception as e:
                        if self.debug_logging:
                            logging.debug(f"{self.__class__.__name__} Unhandled error when processing JSON from {url}: {e}")
                        raise
        except requests.exceptions.RequestException as e:
            logging.error(f"{self.__class__.__name__} Unhandled exception fetching data from {url} : {e}")
            if self._failover_initiated or (self._failures + 1) < self._max_failures:
                raise
            else:
                if "TotalPVPower" in self.derived_sensors:
                    logging.info(f"{self.__class__.__name__} Failed to fetch data from {url} after {self._failures + 1} attempts, failing over to Modbus sensor")
                    self._failover_initiated = cast(SubstituteMixin, self.derived_sensors["TotalPVPower"]).failover(self)
                else:
                    logging.warning(f"{self.__class__.__name__} Failed to fetch data from {url} after {self._failures + 1} attempts, giving up and using last known state")
                    return True
        return False

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "Enphase Envoy API"
        return attributes

    def get_token(self, reauthenticate: bool = False) -> str:
        token_file = os.path.join(active_config.persistent_state_path, f"{self.unique_id}.token")

        def load_token() -> str:
            if os.path.exists(token_file):
                with open(token_file, "r") as f:
                    try:
                        token = f.read()
                        if token:
                            if self.debug_logging:
                                logging.debug(f"Loaded authentication token from {token_file}: {token}")
                        else:
                            if self.debug_logging:
                                logging.debug(f"No authentication token found in {token_file}!")
                            token = ""
                    except Exception as e:
                        logging.warning(f"Failed to load authentication token from {token_file}: {repr(e)}")
                        token = ""
                return token
            else:
                return ""

        def save_token(token) -> None:
            with open(token_file, "w") as f:
                if self.debug_logging:
                    logging.debug(f"Saving authentication token to {token_file}: {token}")
                try:
                    f.write(token)
                except Exception as e:
                    logging.error(f"Failed to save authentication token to {token_file}: {repr(e)}")

        if reauthenticate:
            token = None
        else:
            if self._token and not self._token.isspace():
                token = self._token
                if self.debug_logging:
                    logging.debug(f"Using cached authentication token: {token}")
            else:
                token = load_token()

        if reauthenticate or not token or token == "":
            logging.info("Generating new Enphase authentication token")
            payload = {"user[email]": self._username, "user[password]": self._password}
            if self.debug_logging:
                logging.debug(f"Step 1: Authentication request payload: {payload}")
            with requests.post("https://enlighten.enphaseenergy.com/login/login.json?", data=payload) as response:
                assert response.status_code == 200, f"Failed connect to https://enlighten.enphaseenergy.com/login/login.json? to authenticate: Response={response} Payload={payload}"
                if self.debug_logging:
                    logging.debug(f"Step 1: Authentication response: {response.text}")
                response_data = json.loads(response.text)
                payload = {"session_id": response_data["session_id"], "serial_num": self._serial_number, "username": self._username}
                if self.debug_logging:
                    logging.debug(f"Step 2: Token request payload: {payload}")
                with requests.post("https://entrez.enphaseenergy.com/tokens", json=payload) as response:
                    assert response.status_code == 200, f"Failed connect to https://entrez.enphaseenergy.com/tokens to generate token: Response={response} Payload={payload}"
                    token = response.text
                    save_token(token)

        if self.debug_logging:
            logging.debug(f"Caching authentication token: {token}")
        self._token = token
        return token


class EnphaseLifetimePVEnergy(EnphaseSensor):
    def __init__(self, plant_index: int, serial_number: str):
        super().__init__(
            name="Lifetime Production",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_enphase_{serial_number}_lifetime_pv_energy",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_enphase_{serial_number}_lifetime_pv_energy",
            data_type=ModbusDataType.UINT64,
            unit=UnitOfEnergy.KILO_WATT_HOUR,
            device_class=DeviceClass.ENERGY,
            state_class=StateClass.TOTAL_INCREASING,
            icon="mdi:solar-power",
            gain=1000,
            precision=2,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "Enphase Envoy API when EnphasePVPower derived"
        return attributes


class EnphaseDailyPVEnergy(EnergyDailyAccumulationSensor):
    def __init__(self, plant_index: int, serial_number: str, source: EnphaseLifetimePVEnergy):
        super().__init__(
            name="Daily Production",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_enphase_{serial_number}_daily_pv_energy",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_enphase_{serial_number}_daily_pv_energy",
            source=source,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "Enphase Envoy API when EnphasePVPower derived"
        return attributes


class EnphaseCurrent(EnphaseSensor):
    def __init__(self, plant_index: int, serial_number: str):
        super().__init__(
            name="Current",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_enphase_{serial_number}_current",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_enphase_{serial_number}_current",
            data_type=ModbusDataType.INT32,
            unit=UnitOfElectricCurrent.AMPERE,
            device_class=DeviceClass.CURRENT,
            state_class=None,
            icon="mdi:current-dc",
            gain=1,
            precision=2,
        )
        self["enabled_by_default"] = False

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "Enphase Envoy API when EnphasePVPower derived"
        return attributes


class EnphaseFrequency(EnphaseSensor):
    def __init__(self, plant_index: int, serial_number: str):
        super().__init__(
            name="Frequency",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_enphase_{serial_number}_frequency",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_enphase_{serial_number}_frequency",
            data_type=ModbusDataType.UINT16,
            unit=UnitOfFrequency.HERTZ,
            device_class=DeviceClass.FREQUENCY,
            state_class=None,
            icon="mdi:sine-wave",
            gain=1,
            precision=2,
        )
        self["enabled_by_default"] = False

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "Enphase Envoy API when EnphasePVPower derived"
        return attributes


class EnphasePowerFactor(EnphaseSensor):
    def __init__(self, plant_index: int, serial_number: str):
        super().__init__(
            name="Power Factor",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_enphase_{serial_number}_power_factor",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_enphase_{serial_number}_power_factor",
            data_type=ModbusDataType.UINT16,
            unit=None,
            device_class=DeviceClass.POWER_FACTOR,
            state_class=None,
            icon="mdi:angle-acute",
            gain=1,
            precision=2,
        )
        self["enabled_by_default"] = False

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "Enphase Envoy API when EnphasePVPower derived"
        return attributes


class EnphaseReactivePower(EnphaseSensor):
    def __init__(self, plant_index: int, serial_number: str):
        super().__init__(
            name="Reactive Power",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_enphase_{serial_number}_reactive_power",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_enphase_{serial_number}_reactive_power",
            data_type=ModbusDataType.UINT32,
            unit=UnitOfReactivePower.KILO_VOLT_AMPERE_REACTIVE,
            device_class=None,
            state_class=None,
            icon="mdi:transmission-tower",
            gain=1000,
            precision=2,
        )
        self["enabled_by_default"] = False

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "Enphase Envoy API when EnphasePVPower derived"
        return attributes


class EnphaseVoltage(EnphaseSensor):
    def __init__(self, plant_index: int, serial_number: str):
        super().__init__(
            name="Voltage",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_enphase_{serial_number}_voltage",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_enphase_{serial_number}_voltage",
            data_type=ModbusDataType.UINT16,
            unit=UnitOfElectricPotential.VOLT,
            device_class=DeviceClass.VOLTAGE,
            state_class=None,
            icon="mdi:flash",
            gain=1,
            precision=1,
        )
        self["enabled_by_default"] = False

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "Enphase Envoy API when EnphasePVPower derived"
        return attributes


class SmartPort(Device):
    @classmethod
    def _get_text(cls, root: xml.Element, path: str) -> str:
        element = root.find(path)
        return element.text if element is not None and element.text else ""

    def __init__(self, plant_index: int, config: SmartPortModule):
        fw: str = ""
        sn: str = ""
        pn: str = ""
        if config.testing:
            logging.debug(f"SmartPort {plant_index} testing mode enabled")
            fw = "D7.0.0"
            sn = "123456789012"
            pn = "Envoy-S"
        else:
            url = f"http://{config.host}/info"
            for i in range(1, 4, 1):
                with requests.Session() as session:
                    try:
                        with session.get(url, timeout=20, verify=False) as response:
                            if response.status_code == 200:
                                root = xml.fromstring(response.content)
                                sn = self._get_text(root, "./device/sn")
                                pn = self._get_text(root, "./device/pn")
                                fw = self._get_text(root, "./device/software")
                                if fw.startswith("D7") or fw.startswith("D8"):
                                    break
                                else:
                                    raise Exception(f"Unsupported Enphase Envoy firmware {fw}")
                            else:
                                logging.error(f"SmartPort Failed to initialise from {url} (Attempt #{i}) - Response code was {response.status_code}")
                    except requests.exceptions.ConnectionError as e:
                        logging.error(f"SmartPort Failed to initialise from {url} (Attempt #{i}): {e}")
                sleep(10)
            else:
                raise Exception(f"Unable to initialise from {url} after 3 attempts")
        unique_id = f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_enphase_envoy_{sn}"
        name = "Sigenergy Plant Smart-Port" if plant_index == 0 else f"Sigenergy Plant {plant_index + 1} Smart-Port"
        super().__init__(name, plant_index, unique_id, "Enphase", "Envoy", Protocol.N_A, mdl_id=pn, sn=sn, hw=fw)

        pv_power = EnphasePVPower(plant_index, sn, config.host, config.username, config.password)
        lifetime_pv_energy = EnphaseLifetimePVEnergy(plant_index, sn)
        self._add_read_sensor(pv_power, "Consumption" if active_config.consumption == ConsumptionMethod.CALCULATED else None)
        self._add_derived_sensor(lifetime_pv_energy, pv_power)
        self._add_derived_sensor(EnphaseDailyPVEnergy(plant_index, sn, lifetime_pv_energy), lifetime_pv_energy)
        self._add_derived_sensor(EnphaseCurrent(plant_index, sn), pv_power)
        self._add_derived_sensor(EnphaseFrequency(plant_index, sn), pv_power)
        self._add_derived_sensor(EnphasePowerFactor(plant_index, sn), pv_power)
        self._add_derived_sensor(EnphaseReactivePower(plant_index, sn), pv_power)
        self._add_derived_sensor(EnphaseVoltage(plant_index, sn), pv_power)


if __name__ == "__main__":
    logging.getLogger().setLevel(logging.DEBUG)
    active_config.sensor_debug_logging = True

    async def test():
        smartport = SmartPort(0, active_config.modbus[0].smartport.module)
        print(smartport)
        pv_power_unique_id = f"{active_config.home_assistant.unique_id_prefix}_0_enphase_{smartport['serial_number']}_active_power"
        sensor = smartport.get_sensor(pv_power_unique_id)
        if sensor:
            sensor.debug_logging = True
            print(f"{sensor.name} =  {await sensor.get_state()}")
            for derived in sensor.derived_sensors.values():
                print(f"{derived.name} =  {await derived.get_state()}")
        else:
            print(f"Sensor '{pv_power_unique_id}' not found!!!")

    asyncio.run(test(), debug=True)
