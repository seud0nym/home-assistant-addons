import asyncio
import hashlib
import json
import logging
from collections.abc import Mapping
from typing import Any

import paho.mqtt.client as paho_mqtt
import requests
from paho.mqtt import MQTTException
from paho.mqtt.enums import CallbackAPIVersion
from pymodbus.exceptions import ModbusException

from sigenergy2mqtt.common import InputType, VoltageSource
from sigenergy2mqtt.config import ConfigurationError, active_config
from sigenergy2mqtt.devices import Device
from sigenergy2mqtt.modbus import ModbusClient
from sigenergy2mqtt.persistence import Category, state_store
from sigenergy2mqtt.sensors.base import (
    AlarmCombinedSensor,
    ModbusSensorMixin,
    WriteOnlySensorMixin,
)
from sigenergy2mqtt.sensors.inverter.read_only import OutputType

from .modbus_helpers import read_registers

logger = logging.getLogger(__name__)


async def _validate_modbus_connections() -> None:
    """Verify that each configured Modbus endpoint accepts a TCP connection.

    Opens a short-lived client for every configured host/port, attempts to
    connect, validates the connected state, logs success, and then closes the
    socket. No register writes are performed, and the only register read is the
    output type, when ``pvoutput.voltage`` is ``l/l-avg`` (see
    :func:`_validate_line_to_line_voltage`).
    """
    for index, modbus in enumerate(active_config.modbus):
        if not modbus.host:
            logger.warning(f"Unable to validate Modbus connection for device #{index}, host is not set")
        else:
            client = ModbusClient(modbus.host, port=modbus.port, timeout=modbus.timeout, retries=modbus.retries)
            try:
                await client.connect()
                if not client.connected:
                    raise ConnectionError(f"Unable to connect to modbus://{modbus.host}:{modbus.port}")
                logger.info(f"Validated Modbus connection to modbus://{modbus.host}:{modbus.port} (device #{index})")
                await _validate_line_to_line_voltage(client, index, modbus.host, modbus.port, modbus.inverters)
            finally:
                client.close()


async def _validate_line_to_line_voltage(client: ModbusClient, index: int, host: str, port: int, inverters: list[int]) -> None:
    """Reject ``pvoutput.voltage = l/l-avg`` when the system is not three-phase.

    The phase count is not in the configuration; it is derived from the output
    type register of the first configured inverter, exactly as it is when the
    plant is created at runtime. A register that cannot be read is reported and
    skipped: only a positive reading of fewer than three phases is an error.

    Raises:
        ConfigurationError: If the output type has fewer than three phases.
    """
    if not active_config.pvoutput.enabled or active_config.pvoutput.voltage != VoltageSource.L_L_AVG or not inverters:
        return
    url = f"modbus://{host}:{port}"
    try:
        rr = await read_registers(client, OutputType.ADDRESS, 1, inverters[0], InputType.INPUT)
        if rr is None or rr.isError() or not rr.registers:
            raise ValueError(f"unexpected response {rr}")
        phases = OutputType.to_phases(rr.registers[0])
    except (ModbusException, TimeoutError, OSError, ValueError) as exc:
        logger.warning(f"Unable to read the output type from {url} (device #{index}) to check that pvoutput.voltage '{VoltageSource.L_L_AVG.value}' is supported: {exc}")
        return
    if phases < 3:
        raise ConfigurationError(
            f"pvoutput.voltage is '{VoltageSource.L_L_AVG.value}' (line to line average), which requires a three-phase system, "
            f"but the plant at {url} (device #{index}) has {phases} phase{'s' if phases != 1 else ''}. Use 'l/n-avg', 'phase-a' or 'pv' instead."
        )
    logger.info(f"Validated that {url} (device #{index}) is three-phase, as required by pvoutput.voltage '{VoltageSource.L_L_AVG.value}'")


def _validate_mqtt_connection(show_credentials: bool) -> None:
    """Validate MQTT broker reachability and authentication only.

    Establishes a temporary MQTT session using the configured transport/TLS and
    optional credentials, waits for a successful CONNACK, then disconnects.

    Args:
        show_credentials: When ``True``, include raw configured credentials in
            log output for troubleshooting.
    """
    client_id = f"{active_config.mqtt.client_id_prefix}_validate"
    client = paho_mqtt.Client(CallbackAPIVersion.VERSION2, client_id=client_id, protocol=paho_mqtt.MQTTv311, transport=active_config.mqtt.transport)

    if active_config.mqtt.tls:
        import ssl

        ssl_context = ssl.create_default_context()
        if active_config.mqtt.tls_insecure:
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
        client.tls_set_context(ssl_context)

    url = f"mqtt://{active_config.mqtt.broker}:{active_config.mqtt.port}"
    try:
        if active_config.mqtt.anonymous:
            logger.info(f"Validating MQTT connection to {url} anonymously")
        else:
            if show_credentials:
                logger.info(f"Validating MQTT connection to {url} with username={active_config.mqtt.username!r} password={active_config.mqtt.password!r}")
            else:
                logger.info(f"Validating MQTT connection to {url} with username={active_config.mqtt.username!r} password='[REDACTED]'")
            client.username_pw_set(active_config.mqtt.username, active_config.mqtt.password)

        client.connect(active_config.mqtt.broker, port=active_config.mqtt.port, keepalive=active_config.mqtt.keepalive)

        connected = False
        for _ in range(10):
            rc = client.loop(timeout=1.0)
            if client.is_connected():
                connected = True
                break
            if rc not in (paho_mqtt.MQTT_ERR_SUCCESS, paho_mqtt.MQTT_ERR_NO_CONN):
                raise ConnectionError(f"MQTT broker connection failed with rc={rc}")

        if not connected:
            raise TimeoutError("Timed out waiting for MQTT CONNACK")

        logger.info(f"Validated MQTT connection/authentication to {url}")
    finally:
        try:
            client.disconnect()
            client.loop(timeout=0.1)
        except (OSError, MQTTException) as exc:
            logger.warning(f"Error during MQTT disconnect: {exc}")


def _validate_influxdb_connection(show_credentials: bool) -> None:
    """Validate InfluxDB connectivity/authentication via read-only HTTP calls.

    For v2 config (token+org), performs a GET against the buckets endpoint.
    For v1 config (username+password), performs a read-only query endpoint
    request. No write endpoint is called.

    Args:
        show_credentials: When ``True``, include raw configured credentials in
            log output for troubleshooting.
    """
    if not active_config.influxdb.enabled:
        return

    base = f"http://{active_config.influxdb.host}:{active_config.influxdb.port}"
    timeout = max(active_config.influxdb.write_timeout, 5.0)

    if active_config.influxdb.token and active_config.influxdb.org:
        headers = {"Authorization": f"Token {active_config.influxdb.token}"}
        if show_credentials:
            logger.info(f"Validating InfluxDB v2 credentials for {base}: token={active_config.influxdb.token!r} org={active_config.influxdb.org!r}")
        else:
            logger.info(f"Validating InfluxDB v2 credentials for {base}: token='[REDACTED]' org={active_config.influxdb.org!r}")
        response = requests.get(f"{base}/api/v2/buckets", params={"org": active_config.influxdb.org, "limit": 1}, headers=headers, timeout=timeout)
    else:
        auth = (active_config.influxdb.username, active_config.influxdb.password)
        if show_credentials:
            logger.info(f"Validating InfluxDB v1 credentials for {base}: username={active_config.influxdb.username!r} password={active_config.influxdb.password!r}")
        else:
            logger.info(f"Validating InfluxDB v1 credentials for {base}: username={active_config.influxdb.username!r} password='[REDACTED]'")
        response = requests.get(f"{base}/query", params={"q": "SHOW DATABASES"}, auth=auth, timeout=timeout)

    response.raise_for_status()
    logger.info(f"Validated InfluxDB connection/authentication to {base}")


def _validate_pvoutput_connection(show_credentials: bool) -> None:
    """Validate PVOutput endpoint reachability and API authentication.

    Calls PVOutput's system-info API with configured API key/system ID and
    requires a successful HTTP response. No upload API endpoint is used.

    When ``pvoutput.testing`` is enabled, this probe is skipped to match
    runtime behaviour, which intentionally avoids outbound PVOutput requests
    in testing mode.

    Args:
        show_credentials: When ``True``, include raw configured credentials in
            log output for troubleshooting.
    """
    if not active_config.pvoutput.enabled:
        return

    if active_config.pvoutput.testing:
        logger.info("Skipping PVOutput connection/authentication probe because pvoutput.testing is enabled")
        return

    headers = {
        "X-Pvoutput-Apikey": active_config.pvoutput.api_key,
        "X-Pvoutput-SystemId": active_config.pvoutput.system_id,
        "X-Rate-Limit": "1",
    }
    if show_credentials:
        logger.info(f"Validating PVOutput credentials with api_key={active_config.pvoutput.api_key!r} system_id={active_config.pvoutput.system_id!r}")
    else:
        logger.info(f"Validating PVOutput credentials with api_key='[REDACTED]' system_id={active_config.pvoutput.system_id!r}")

    response = requests.get("https://pvoutput.org/service/r2/getsystem.jsp?donations=1", headers=headers, timeout=10)
    response.raise_for_status()
    logger.info("Validated PVOutput connection/authentication")


async def validate_connections(show_credentials: bool = False) -> None:
    """Run all configured connection/authentication checks for ``--validate``.

    Executes Modbus, MQTT, InfluxDB, and PVOutput validation checks in
    sequence. Intended for one-shot startup validation mode, not steady-state
    runtime.

    Args:
        show_credentials: When ``True``, validation logs include raw
            credentials where applicable.
    """
    await _validate_modbus_connections()
    _validate_mqtt_connection(show_credentials)
    _validate_influxdb_connection(show_credentials)
    _validate_pvoutput_connection(show_credentials)


# Version 2 added ``validated_sensor_unique_ids``, which lets a later startup tell a sensor that was
# probed and found supported from one that is new (for example, added by a software update).
_PUBLISHABLE_SENSOR_VALIDATION_CACHE_VERSION = 2
_VALIDATION_CACHE_KEY_PREFIX = "publishable-sensor-validation."

# An ILLEGAL DATA ADDRESS response is only trusted when it is repeated: a device can answer 0x02
# transiently (for example while a gateway or battery is still initialising), and a sensor
# wrongly flagged as unsupported stays unpublishable until the cache is cleared.
_ILLEGAL_ADDRESS_ATTEMPTS = 3
_ILLEGAL_ADDRESS_RETRY_DELAY = 1.0  # seconds between attempts; applied once per pass over all suspect sensors


def _validation_hash(value: Any) -> str:
    serialized = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _current_modbus_config_hash() -> str:
    return _validation_hash([device.model_dump(mode="json", by_alias=True) for device in active_config.modbus])


def _inverter_firmware_payload(inverter_firmware_versions: Mapping[int, str] | None) -> dict[str, str]:
    return {str(address): str(firmware) for address, firmware in sorted((inverter_firmware_versions or {}).items())}


def _validation_cache_key(device: Device) -> str:
    return f"{_VALIDATION_CACHE_KEY_PREFIX}{_validation_hash(device.unique_id)}.json"


def _log_illegal_data_address(sensor: Any) -> None:
    logger.debug(f"{sensor.log_identity} not supported on this device/firmware: ILLEGAL DATA ADDRESS {sensor.address} (count={sensor.count} type={sensor.input_type} protocol=V{sensor.protocol_version.value})")


def _is_valid_validation_cache_payload(value: str) -> bool:
    try:
        payload = json.loads(value)
    except json.JSONDecodeError:
        return False

    return (
        isinstance(payload, dict)
        and payload.get("cache_version") == _PUBLISHABLE_SENSOR_VALIDATION_CACHE_VERSION
        and isinstance(payload.get("inverter_firmware_versions"), dict)
        and isinstance(payload.get("inverter_firmware_hash"), str)
        and isinstance(payload.get("modbus_config_hash"), str)
        and isinstance(payload.get("illegal_sensor_unique_ids"), list)
        and all(isinstance(sensor_id, str) for sensor_id in payload["illegal_sensor_unique_ids"])
        and isinstance(payload.get("validated_sensor_unique_ids"), list)
        and all(isinstance(sensor_id, str) for sensor_id in payload["validated_sensor_unique_ids"])
    )


async def clear_validation_cache() -> int:
    """Delete every persisted sensor validation cache entry (disk and MQTT).

    The next validation of each device then probes every sensor afresh. Returns the number
    of entries removed.
    """
    removed = await state_store.delete_matching(Category.CONFIG, _VALIDATION_CACHE_KEY_PREFIX)
    logger.info(f"Cleared {removed} sensor validation cache entr{'y' if removed == 1 else 'ies'}")
    return removed


def _mark_illegal(sensor: ModbusSensorMixin) -> None:
    sensor.illegal_data_address = True
    sensor.publishable = False


async def _probe_sensors(modbus_client: ModbusClient, sensors: list[ModbusSensorMixin]) -> tuple[list[ModbusSensorMixin], list[ModbusSensorMixin], list[ModbusSensorMixin]]:
    """Read each sensor's registers and classify it.

    A sensor is *illegal* only if every one of up to ``_ILLEGAL_ADDRESS_ATTEMPTS`` reads returns
    0x02 ILLEGAL DATA ADDRESS. After the first pass only the sensors that returned 0x02 are read
    again, after a single delay, so the delay does not grow with the number of sensors.

    Returns:
        ``(illegal, supported, failed)``. *failed* sensors raised an exception or returned an
        error response other than 0x02 on a read, so the scan is incomplete and must not be cached.
    """
    illegal: list[ModbusSensorMixin] = []
    supported: list[ModbusSensorMixin] = []
    failed: list[ModbusSensorMixin] = []
    suspects = list(sensors)

    for attempt in range(1, _ILLEGAL_ADDRESS_ATTEMPTS + 1):
        if attempt > 1:
            if not suspects:
                break
            logger.debug(f"Re-reading {len(suspects)} sensor{'s' if len(suspects) != 1 else ''} that returned ILLEGAL DATA ADDRESS (attempt {attempt} of {_ILLEGAL_ADDRESS_ATTEMPTS})")
            await asyncio.sleep(_ILLEGAL_ADDRESS_RETRY_DELAY)
        still_suspect: list[ModbusSensorMixin] = []
        for s in suspects:
            try:
                rr = await read_registers(modbus_client, s.address, s.count, s.device_address, s.input_type)
            except (ModbusException, TimeoutError, OSError, ConnectionError) as e:
                # Only an explicit 0x02 is evidence of an unsupported register, never a transient error
                if "0x02 ILLEGAL DATA ADDRESS" in str(e):
                    # Disabled for this run but, as an exception rather than a response, also
                    # counted as failed so that it is never persisted (as before retries existed)
                    logger.debug(f"{s.log_identity}: Validation detected illegal address: {e}")
                    illegal.append(s)
                    failed.append(s)
                else:
                    logger.debug(f"{s.log_identity}: Validation read failed: {e}")
                    failed.append(s)
                continue
            if rr and rr.isError() and rr.exception_code == 0x02:
                still_suspect.append(s)
            elif not rr or rr.isError():
                # Any other error response (e.g. device failure) proves nothing either way
                logger.debug(f"{s.log_identity}: Validation read failed: {rr}")
                failed.append(s)
            else:
                if attempt > 1:
                    logger.debug(f"{s.log_identity}: ILLEGAL DATA ADDRESS was transient - address {s.address} is readable")
                supported.append(s)
        suspects = still_suspect

    for s in suspects:
        _log_illegal_data_address(s)
    illegal.extend(suspects)
    return illegal, supported, failed


async def validate_publishable_sensors(modbus_client: ModbusClient, device: Device, inverter_firmware_versions: Mapping[int, str] | None = None) -> None:
    """Validate all publishable sensors for illegal data addresses.

    Scans all publishable ModbusSensorMixin sensors that are not WriteOnlySensors and
    have not been previously probed (state_count == 0), then marks those returning
    Modbus 0x02 ILLEGAL_DATA_ADDRESS as unpublishable before scan groups are created.
    A 0x02 is only believed if it is repeated (see ``_ILLEGAL_ADDRESS_ATTEMPTS``).

    Results are cached per device and reused on later startups while both the active
    Modbus configuration and the full plant inverter firmware set are unchanged. The
    firmware set is supplied by setup_devices from inverter ``hw`` attributes only;
    non-inverter device software/hardware attributes are ignored.

    A cache hit does not skip probing entirely: sensors that were cached as illegal are
    read again (so a wrong result cannot persist), as are sensors the cache has never
    seen (for example, added by a software update). Everything else is trusted.

    Args:
        modbus_client: Modbus client for reads
        device: Device to validate (and children recursively)
        inverter_firmware_versions: Firmware versions for all created inverters in the
            plant, keyed by inverter Modbus device address.
    """
    if active_config.clean:
        return

    sensors_to_test = [s for s in device.get_all_sensors(search_children=True).values() if isinstance(s, ModbusSensorMixin) and not isinstance(s, WriteOnlySensorMixin) and s.publishable and s.state_count == 0]
    if not sensors_to_test:
        return
    candidates: list[ModbusSensorMixin] = [s for sensor in sensors_to_test for s in (sensor.alarms if isinstance(sensor, AlarmCombinedSensor) else [sensor])]

    firmware_versions = _inverter_firmware_payload(inverter_firmware_versions)
    firmware_hash = _validation_hash(firmware_versions)
    modbus_config_hash = _current_modbus_config_hash()
    cache_key = _validation_cache_key(device)
    cached = await state_store.load(Category.CONFIG, cache_key, validator=_is_valid_validation_cache_payload)

    cached_illegal: set[str] = set()
    cached_validated: set[str] = set()
    to_probe = candidates
    if cached is None:
        logger.debug(f"{device.log_identity} ILLEGAL DATA ADDRESS errors cache not found ({cache_key=})")
    else:
        payload = json.loads(cached)
        if payload["inverter_firmware_hash"] != firmware_hash:
            logger.debug(f"{device.log_identity} ILLEGAL DATA ADDRESS errors cache inverter firmware hash mismatch (cached={payload['inverter_firmware_hash']} current={firmware_hash})")
        elif payload["modbus_config_hash"] != modbus_config_hash:
            logger.debug(f"{device.log_identity} ILLEGAL DATA ADDRESS errors cache modbus config hash mismatch (cached={payload['modbus_config_hash']} current={modbus_config_hash})")
        else:
            cached_illegal = set(payload["illegal_sensor_unique_ids"])
            cached_validated = set(payload["validated_sensor_unique_ids"])
            to_probe = [s for s in candidates if s.unique_id in cached_illegal or s.unique_id not in cached_validated]
            logger.debug(f"{device.log_identity} Applying ILLEGAL DATA ADDRESS errors cache: {len(cached_illegal)} cached illegal, {len(to_probe)} of {len(candidates)} sensors to probe")

    if not to_probe:
        return

    logger.debug(f"{device.log_identity} Validating {len(to_probe)} sensor{'s' if len(to_probe) != 1 else ''} addresses")
    illegal, supported, failed = await _probe_sensors(modbus_client, to_probe)

    for s in illegal:
        _mark_illegal(s)
    for s in failed:
        if s.unique_id in cached_illegal:
            # Unreadable now, so there is no new evidence: keep the cached verdict for this run only
            _log_illegal_data_address(s)
            _mark_illegal(s)
    for s in supported:
        if s.unique_id in cached_illegal:
            logger.info(f"{s.log_identity} no longer reports ILLEGAL DATA ADDRESS - sensor is now supported")

    if failed:
        logger.debug(f"{device.log_identity} Validation scan not cached because one or more sensor reads failed")
        return

    probed_ids = {s.unique_id for s in to_probe}
    illegal_ids = (cached_illegal - probed_ids) | {s.unique_id for s in illegal}
    validated_ids = cached_validated | probed_ids
    if cached is not None and illegal_ids == cached_illegal and validated_ids == cached_validated:
        return  # Nothing changed, so the persisted entry is still exact

    payload = {
        "cache_version": _PUBLISHABLE_SENSOR_VALIDATION_CACHE_VERSION,
        "inverter_firmware_versions": firmware_versions,
        "inverter_firmware_hash": firmware_hash,
        "modbus_config_hash": modbus_config_hash,
        "illegal_sensor_unique_ids": sorted(illegal_ids),
        "validated_sensor_unique_ids": sorted(validated_ids),
    }
    await state_store.save(Category.CONFIG, cache_key, json.dumps(payload, sort_keys=True))
