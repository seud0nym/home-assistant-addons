import copy
import logging
import threading
import time
from dataclasses import dataclass

from pymodbus import FramerType
from pymodbus.client import AsyncModbusTcpClient
from pymodbus.client.mixin import ModbusClientMixin
from pymodbus.exceptions import ConnectionException, ModbusException, ModbusIOException
from pymodbus.logging import Log
from pymodbus.pdu import ExceptionResponse, ModbusPDU

from sigenergy2mqtt.common import InputType
from sigenergy2mqtt.common.outage import OutageTracker, outage_tracker

from .read_ahead import ReadAhead

logger = logging.getLogger(__name__)

# Outage error kind shared by every way a Modbus host can be unreachable
# (connection lost or refused, no response), so they are reported as one error.
CONNECTIVITY = "connectivity"


@dataclass
class ModbusClientHealth:
    """Observed health state for a single Modbus client."""

    client_id: str
    last_connected_at: float | None = None
    last_closed_at: float | None = None
    last_read_at: float | None = None
    connect_count: int = 0
    close_count: int = 0
    disconnect_count: int = 0
    """Connections lost for any reason (including closes initiated by pymodbus), as reported by pymodbus."""
    last_disconnected_at: float | None = None


class ModbusClient(AsyncModbusTcpClient, ModbusClientMixin):
    """Async Modbus TCP client with optional read-ahead caching and metrics hooks.

    This class wraps :class:`pymodbus.client.AsyncModbusTcpClient` to provide:

    * Standardized socket framing and packet tracing support.
    * Per-device register read-ahead cache that can satisfy future reads without
      additional network calls.
    * Metrics tracking for latency, read volume, cache fill/hit rates, and errors.

    The cache stores one :class:`~sigenergy2mqtt.modbus.read_ahead.ReadAhead`
    object per register address and device. Cache entries for specific ranges
    can be invalidated with :meth:`bypass_read_ahead`; the runtime does not
    currently call it.
    """

    # Class-level defaults so instances created without __init__ (e.g. in tests) behave as untracked
    _outage: OutageTracker | None = None
    _closing: bool = False

    def _trace_packet_handler(self, is_send: bool, data: bytes) -> bytes:
        """Format and emit raw packet debug logs when tracing is enabled.

        Args:
            is_send: ``True`` when the packet is outbound, ``False`` for inbound.
            data: Raw Modbus payload bytes.

        Returns:
            The unmodified ``data`` payload, as required by pymodbus trace hooks.
        """
        if self._trace:
            if is_send:
                log_text = Log.build_msg("send: {}", data, ":hex")
            else:
                log_text = Log.build_msg("recv: {}", data, ":hex")
            logger.debug(log_text)
        return data

    def _trace_connect_handler(self, connected: bool) -> None:
        """Record connection losses reported by pymodbus.

        ``close_count`` only counts closes made by this application; pymodbus
        also drops the connection itself (e.g. after repeated timeouts), which
        is only visible through this callback.
        """
        if not connected:
            with self._health_lock:
                self._health.disconnect_count += 1
                self._health.last_disconnected_at = time.monotonic()
            if self._outage is not None and not self._closing:
                # Report the outage as soon as the connection drops, rather than when the next read times out
                self._outage.failure("connection lost", kind=CONNECTIVITY)

    def __init__(self, *args, **kwargs):
        """Initialize the client with socket framing, tracing, and cache state.

        The constructor enforces socket framer mode and installs this instance's
        packet trace handler. It also initializes the read-ahead cache and cache
        counters used by :meth:`_read_registers`.

        Pass ``track_outages=True`` for long-lived runtime clients: connectivity
        failures and recoveries are then reported to the shared
        :class:`~sigenergy2mqtt.common.outage.OutageTracker` for this host, so
        that an outage is logged once when it starts and once when it ends.
        Short-lived clients (validation, probing) leave it off so that expected
        failures are not reported as outages.
        """
        track_outages: bool = kwargs.pop("track_outages", False)
        kwargs["framer"] = FramerType.SOCKET
        kwargs["trace_packet"] = self._trace_packet_handler
        kwargs["trace_connect"] = self._trace_connect_handler
        super().__init__(*args, **kwargs)
        self._read_ahead_pdu: dict[int, dict[int, ReadAhead | None]] = {}
        self._trace: bool = False
        self._read_count: int = 0
        self._cache_hits: int = 0
        # Health tracking
        self._health: ModbusClientHealth = ModbusClientHealth(f"modbus://{self.comm_params.host}:{self.comm_params.port}")
        self._health_lock = threading.RLock()
        self._outage: OutageTracker | None = outage_tracker(self._health.client_id) if track_outages else None

    @property
    def outage(self) -> OutageTracker | None:
        """The outage tracker for this client's host, or ``None`` if not tracked."""
        return self._outage

    async def _read_registers(
        self, address: int, count: int = 1, device_id: int = 1, input_type: InputType = InputType.HOLDING, no_response_expected: bool = False, use_pre_read: bool = False, trace: bool = False
    ) -> ModbusPDU:
        """Read Modbus registers, optionally serving from read-ahead cache first.

        Args:
            address: Start register address.
            count: Number of consecutive registers to read.
            device_id: Modbus unit/device id.
            input_type: Register space to read (holding or input).
            no_response_expected: Forwarded pymodbus option for write-like flows.
            use_pre_read: Whether to attempt serving from read-ahead cache.
            trace: Enable packet-level trace logging for this call only.

        Returns:
            A Modbus PDU response. If the backend returns ``None``, this method
            converts it into an :class:`ExceptionResponse`.

        Raises:
            ModbusException: Re-raised after updating error metrics.
            TypeError: Invalid input type.
        """
        from sigenergy2mqtt.metrics import Metrics

        if use_pre_read:
            self._read_count += 1
            if device_id in self._read_ahead_pdu and address in self._read_ahead_pdu[device_id]:
                pre_read = self._read_ahead_pdu[device_id][address]
                if pre_read is not None:
                    try:
                        rr = pre_read.get_registers(address, count=count)
                        self._cache_hits += 1
                        await Metrics.modbus_cache_hits(self._read_count, self._cache_hits)
                        return rr
                    except IndexError as e:
                        logger.debug(f"Pre-read failed: {e}")
            await Metrics.modbus_cache_hits(self._read_count, self._cache_hits)
        self._trace = trace
        try:
            start = time.monotonic()
            if input_type == InputType.HOLDING:
                rr = await super().read_holding_registers(address, count=count, device_id=device_id, no_response_expected=no_response_expected)
            elif input_type == InputType.INPUT:
                rr = await super().read_input_registers(address, count=count, device_id=device_id, no_response_expected=no_response_expected)
            else:
                raise TypeError(f"Unknown input type '{input_type}'")
            elapsed = time.monotonic() - start
            with self._health_lock:
                self._health.last_read_at = start
            if self._outage is not None and rr is not None:
                # Any response, even an exception response, proves the device is reachable.
                self._outage.success()
            if rr is None:
                rr = ExceptionResponse(function_code=0x3 if input_type == InputType.HOLDING else 0x04, exception_code=0x5, device_id=device_id)
            if rr.isError() or isinstance(rr, ExceptionResponse):
                await Metrics.modbus_read_error()
                return rr
            else:
                await Metrics.modbus_read(count, elapsed)
                return rr
        except ModbusException as e:
            if self._outage is not None and isinstance(e, (ConnectionException, ModbusIOException)):
                self._outage.failure(e, kind=CONNECTIVITY)
            await Metrics.modbus_read_error()
            raise
        except OSError as e:
            if self._outage is not None:
                self._outage.failure(e, kind=CONNECTIVITY)
            await Metrics.modbus_read_error()
            raise
        finally:
            self._trace = False

    def bypass_read_ahead(self, address: int, count: int = 1, device_id: int = 1) -> None:
        """Invalidate read-ahead cache entries for a register range.

        This marks the addressed range as ``None`` for the specified device to
        prevent stale cached reads after writes or other out-of-band changes.

        Args:
            address: Start register address to invalidate.
            count: Number of registers to invalidate.
            device_id: Modbus unit/device id.
        """
        if device_id in self._read_ahead_pdu:
            self._read_ahead_pdu[device_id].update({key: None for key in range(address, address + count)})

    async def connect(self) -> bool:
        self._closing = False
        connected = await super().connect()
        if connected:
            with self._health_lock:
                self._health.connect_count += 1
                self._health.last_connected_at = time.monotonic()
        return connected

    def close(self) -> None:
        was_connected = self.connected
        # A close requested by the application is not an outage. The flag stays set until
        # the next connect() because pymodbus may report the disconnection asynchronously.
        self._closing = True
        super().close()
        if was_connected:
            with self._health_lock:
                self._health.close_count += 1
                self._health.last_closed_at = time.monotonic()

    async def read_ahead_registers(self, address, count: int = 1, device_id: int = 1, input_type: InputType = InputType.INPUT, no_response_expected: bool = False, trace: bool = False) -> int:
        """Pre-fetch a register range and populate the read-ahead cache.

        Args:
            address: Start register address for prefetch.
            count: Number of consecutive registers to prefetch.
            device_id: Modbus unit/device id.
            input_type: Register space to prefetch from.
            no_response_expected: Forwarded pymodbus option.
            trace: Enable packet-level trace logging for this call only.

        Returns:
            Modbus exception code from the response. ``0`` indicates success,
            ``-1`` indicates no response object was available.
        """
        from sigenergy2mqtt.metrics import Metrics

        result: int = -1
        rr = await self._read_registers(address, count=count, device_id=device_id, input_type=input_type, no_response_expected=no_response_expected, use_pre_read=False, trace=trace)
        if rr:
            if device_id not in self._read_ahead_pdu:
                self._read_ahead_pdu[device_id] = {}
            if rr.isError() or isinstance(rr, ExceptionResponse):
                self._read_ahead_pdu[device_id].update({key: None for key in range(address, address + count)})  # Set registers to None to prevent unexpected values
            else:
                self._read_ahead_pdu[device_id].update({key: ReadAhead(address, count, device_id, input_type, rr) for key in range(address, address + count)})
            result = rr.exception_code
        if result == 0:
            await Metrics.modbus_cache_fill()
        return result

    async def read_holding_registers(self, address, *, count: int = 1, device_id: int = 1, no_response_expected: bool = False, trace: bool = False) -> ModbusPDU:
        """Read holding registers, using read-ahead cache when available.

        Args:
            address: Start register address.
            count: Number of consecutive registers to read.
            device_id: Modbus unit/device id.
            no_response_expected: Forwarded pymodbus option.
            trace: Enable packet-level trace logging for this call only.

        Returns:
            A Modbus PDU response.
        """
        return await self._read_registers(address, count=count, device_id=device_id, input_type=InputType.HOLDING, no_response_expected=no_response_expected, use_pre_read=True, trace=trace)

    async def read_input_registers(self, address, *, count: int = 1, device_id: int = 1, no_response_expected: bool = False, trace: bool = False) -> ModbusPDU:
        """Read input registers, using read-ahead cache when available.

        Args:
            address: Start register address.
            count: Number of consecutive registers to read.
            device_id: Modbus unit/device id.
            no_response_expected: Forwarded pymodbus option.
            trace: Enable packet-level trace logging for this call only.

        Returns:
            A Modbus PDU response.
        """
        return await self._read_registers(address, count=count, device_id=device_id, input_type=InputType.INPUT, no_response_expected=no_response_expected, use_pre_read=True, trace=trace)

    def snapshot(self) -> ModbusClientHealth:
        """Return a shallow copy of client health.

        Safe to iterate without holding any lock.  :class:`ModbusClientHealth`
        value is itself a copy — mutating it has no effect.
        """
        with self._health_lock:
            return copy.copy(self._health)
