from __future__ import annotations

import abc
import asyncio
import json
import logging
from pathlib import Path
from random import uniform
from typing import TYPE_CHECKING, Any, cast

import paho.mqtt.client as mqtt

from sigenergy2mqtt.config import active_config
from sigenergy2mqtt.mqtt import MqttHandler
from sigenergy2mqtt.sensors.base import Sensor
from sigenergy2mqtt.sensors.base.constants import DiscoveryKeys

from .child_devices import ha_child_device_name, publishes_as_ha_child

if TYPE_CHECKING:
    from .device import Device

# Constants for Home Assistant republish timing
HA_REPUBLISH_MIN_JITTER = 0.0
HA_REPUBLISH_MAX_JITTER = 3.0

logger = logging.getLogger(__name__)


class HaPublisherMixin(abc.ABC):
    """Mixin providing Home Assistant MQTT discovery and availability publishing.

    Encapsulates all HA-facing publish behaviour: discovery payloads, availability
    topics, sensor attributes, state republishing on HA restart, and the periodic
    discovery republish background task.

    Intended to be mixed into Device. The attributes and abstract method declared
    below are the contract that the concrete class must fulfil.
    """

    # Plain attributes provided by the concrete class.
    name: str
    children: list[Device]
    parent_device: Device | None
    _shutdown_event: asyncio.Event

    # Properties and methods that must be implemented by the concrete class.
    # Declared as abstract so Pyright sees them as properties throughout the mixin,
    # matching the @property implementations in Device.

    @property
    @abc.abstractmethod
    def online(self) -> bool:
        """Whether the device is currently considered online."""
        ...

    @property
    @abc.abstractmethod
    def sensors(self) -> dict[str, Sensor]:
        """All sensors directly owned by this device, keyed by unique_id."""
        ...

    @property
    @abc.abstractmethod
    def unique_id(self) -> str:
        """The primary unique identifier for this device."""
        ...

    @property
    @abc.abstractmethod
    def log_identity(self) -> str:
        """Stable identity used as log prefix."""
        ...

    @abc.abstractmethod
    def get_all_sensors(self, search_children: bool = True) -> dict[str, Sensor]:
        """Return all sensors owned by this device, optionally including child devices."""
        ...

    async def on_ha_state_change(
        self,
        transport: Any,
        mqtt_client: mqtt.Client,
        ha_state: str,
        source: str,
        mqtt_handler: MqttHandler,
    ) -> bool:
        """Handle a Home Assistant availability state change notification.

        When HA comes online, waits a short random jitter period (to avoid thundering
        herd on broker restart) then republishes discovery and forces all sensors to
        republish their current state. This recovers HA's view of the device after
        an HA restart or MQTT broker reconnect.

        See: https://www.home-assistant.io/integrations/mqtt/#birth-and-last-will-messages

        Args:
            transport:     The Modbus client, if available, passed through to sensor
                           publish calls.
            mqtt_client:   The MQTT client used for publishing.
            ha_state:      The HA availability state string, typically "online" or
                           "offline".
            source:        Descriptive string identifying the source of the state
                           change, used for logging.
            mqtt_handler:  The MqttHandler used to coordinate discovery publication.

        Returns:
            True if the online handler completed successfully, False if it was
            cancelled (e.g. during device shutdown) or if ha_state is not "online".
        """
        if ha_state == "online":
            seconds = uniform(HA_REPUBLISH_MIN_JITTER, HA_REPUBLISH_MAX_JITTER)
            logger.debug(f"{self.log_identity} received online state from Home Assistant ({source=}): Republishing discovery and forcing republish of all sensors in {seconds:.1f}s")
            try:
                await asyncio.sleep(seconds)  # https://www.home-assistant.io/integrations/mqtt/#birth-and-last-will-messages
                await mqtt_handler.wait_for(2, self.name, self.publish_discovery_async, mqtt_client, clean=False)
                for sensor in self.get_all_sensors(search_children=True).values():
                    await sensor.publish(mqtt_client, transport, republish=True)
                return True
            except asyncio.CancelledError:
                logger.debug(f"{self.log_identity} on_ha_state_change sleep interrupted")
                return False
        else:
            return False

    def publish_attributes(self, mqtt_client: mqtt.Client, clean: bool = False, propagate: bool = True) -> None:
        """Publish MQTT attribute messages for all sensors on this device.

        Args:
            mqtt_client: The MQTT client used for publishing.
            clean:       If True, publishes empty/null payloads to clear retained
                         attribute messages.
            propagate:   If True (default), recursively publishes attributes for
                         all child devices.
        """
        for sensor in self.sensors.values():
            sensor.publish_attributes(mqtt_client, clean=clean)
        if propagate:
            for device in self.children:
                device.publish_attributes(mqtt_client, clean=clean, propagate=propagate)

    def publish_availability(self, mqtt_client: mqtt.Client, ha_state: bytes | str, qos: int = 2) -> None:
        """Publish this device's availability status to its HA availability topic.

        Publishes to "{discovery_prefix}/device/{unique_id}/availability" with
        retain=True. Recursively publishes availability for all child devices.

        Args:
            mqtt_client: The MQTT client used for publishing.
            ha_state:    The availability state string (e.g. "online", "offline",
                         or None to clear the retained message).
            qos:         MQTT QoS level. Defaults to 2.
        """
        topic = f"{active_config.home_assistant.discovery_prefix}/device/{self.unique_id}/availability"
        if logger.isEnabledFor(logging.DEBUG):
            if ha_state == b"":
                logger.debug(f"{self.log_identity} cleaning availability ({topic=})")
            else:
                logger.debug(f"{self.log_identity} publishing {ha_state} availability ({topic=})")
        mqtt_client.publish(topic, ha_state, qos, True)
        for device in self.children:
            device.publish_availability(mqtt_client, ha_state)

    def _discovery_topic(self) -> str:
        return f"{active_config.home_assistant.discovery_prefix}/device/{self.unique_id}/config"

    def _publish_clean_discovery(self, mqtt_client: mqtt.Client, topic: str) -> mqtt.MQTTMessageInfo:
        self.publish_availability(mqtt_client, b"", qos=1)  # Availability is always retained
        logger.debug(f"{self.log_identity} cleaning discovery ({topic=})")
        return mqtt_client.publish(topic, b"", qos=1, retain=True)  # Clear retained messages

    def _build_discovery_json(self, mqtt_client: mqtt.Client, components: dict[str, Any]) -> str | None:
        """Assemble the device discovery JSON, or None when there are no components."""
        # The publishing client's Last Will marks every entity unavailable if this
        # process dies without publishing "offline" itself (crash, kill, power loss)
        status_topic = getattr(mqtt_client, "status_topic", None)
        if isinstance(status_topic, str) and status_topic:
            for component in components.values():
                availability = component.get(DiscoveryKeys.AVAILABILITY)
                if isinstance(availability, list) and availability:
                    component[DiscoveryKeys.AVAILABILITY] = [*availability, {"topic": status_topic}]
        if not components:
            return None
        discovery: dict[str, Any] = {}
        parent = self.parent_device
        if parent is not None and publishes_as_ha_child(cast("Device", self)):
            discovery["dev"] = parent
            discovery["o"] = active_config.origin
            discovery["cdevs"] = [{"ids": [self.unique_id], "name": ha_child_device_name(cast("Device", self)), "cmps": components}]
        else:
            discovery["dev"] = self
            discovery["o"] = active_config.origin
            discovery["cmps"] = components
        return json.dumps(discovery, allow_nan=False, indent=2, sort_keys=False)

    def _publish_discovery_json(self, mqtt_client: mqtt.Client, topic: str, discovery_json: str | None) -> mqtt.MQTTMessageInfo:
        if discovery_json is None:
            logger.debug(f"{self.log_identity} publishing empty availability because no components found ({topic=})")
            self.publish_availability(mqtt_client, b"", qos=1)
            logger.debug(f"{self.log_identity} publishing empty discovery because no components found ({topic=})")
            return mqtt_client.publish(topic, b"", qos=1, retain=True)  # Clear retained messages
        logger.debug(f"{self.log_identity} publishing discovery ({topic=})")
        return mqtt_client.publish(topic, discovery_json, qos=2, retain=True)

    def _dump_path(self) -> Path | None:
        return Path(active_config.persistent_state_path, f"{self.unique_id}.discovery.json") if active_config.log_level == logging.DEBUG else None

    def publish_discovery(self, mqtt_client: mqtt.Client, clean: bool = False) -> mqtt.MQTTMessageInfo | None:
        """Publish or clear the Home Assistant MQTT discovery payload for this device.

        In normal mode (clean=False), collects discovery components from all sensors,
        assembles the full device discovery JSON (including "dev", "o", and "cmps"
        keys), and publishes it with retain=True to the HA discovery topic. If no
        publishable components exist, publishes a null payload to clear any stale
        retained discovery message.

        In clean mode (clean=True), clears the availability topic first, then
        publishes a null payload to clear the discovery topic.

        If debug logging is enabled, the discovery JSON is also written to disk at
        active_config.persistent_state_path for inspection.

        Every device, including a child, publishes to its own discovery topic
        (``{prefix}/device/{unique_id}/config``) with the same component IDs, so the
        Home Assistant discovery hashes never change. When Home Assistant child
        devices are enabled and this device is an eligible child, the payload's root
        ``dev`` is the parent's device info and this device's components are nested
        in a single ``cdevs`` entry. Nothing is cleared, so Home Assistant sees a
        discovery update rather than a removal followed by a new discovery. Children
        are always published recursively after this device.

        Args:
            mqtt_client: The MQTT client used for publishing.
            clean:       If True, clears retained discovery and availability messages
                         instead of publishing new ones.

        Returns:
            The MQTTMessageInfo from the final mqtt_client.publish() call, or None.
        """
        topic = self._discovery_topic()
        if clean:
            info = self._publish_clean_discovery(mqtt_client, topic)
        else:
            components: dict[str, Any] = {}
            for sensor in self.sensors.values():
                components.update(sensor.get_discovery(mqtt_client))
            discovery_json = self._build_discovery_json(mqtt_client, components)
            if discovery_json is not None and (dump := self._dump_path()) is not None:
                dump.write_text(discovery_json)
                logger.debug(f"{self.log_identity} discovery JSON dumped to {dump.resolve()}")
            info = self._publish_discovery_json(mqtt_client, topic, discovery_json)
        self.publish_attributes(mqtt_client, clean, propagate=False)  # Don't propagate to children because it will happen automatically when child discovery is published
        for device in self.children:
            device.publish_discovery(mqtt_client, clean=clean)
        return info

    async def publish_discovery_async(self, mqtt_client: mqtt.Client, clean: bool = False) -> mqtt.MQTTMessageInfo | None:
        """Publish discovery using the asynchronous sensor persistence API."""
        topic = self._discovery_topic()
        if clean:
            info = self._publish_clean_discovery(mqtt_client, topic)
        else:
            components: dict[str, Any] = {}
            # Snapshot: awaiting below lets other tasks (e.g. cloud recovery) add sensors mid-iteration
            for sensor in list(self.sensors.values()):
                components.update(await sensor.get_discovery_async(mqtt_client))
            discovery_json = self._build_discovery_json(mqtt_client, components)
            if discovery_json is not None and (dump := self._dump_path()) is not None:
                await asyncio.to_thread(dump.write_text, discovery_json)
                logger.debug(f"{self.log_identity} discovery JSON dumped to {dump.resolve()}")
            info = self._publish_discovery_json(mqtt_client, topic, discovery_json)
        self.publish_attributes(mqtt_client, clean, propagate=False)
        for device in self.children:
            await device.publish_discovery_async(mqtt_client, clean=clean)
        return info

    async def republish_discovery(self, mqtt_client: mqtt.Client) -> None:
        """Periodically republish the HA discovery payload at the configured interval.

        Runs as a background coroutine alongside the sensor scan group tasks.
        Sleeps in 1-second increments and republishes when the configured interval
        has elapsed. Exits when the device goes offline, the shutdown event is set,
        or the task is cancelled.

        Args:
            mqtt_client: The MQTT client used for publishing discovery payloads.
        """
        wait = active_config.home_assistant.republish_discovery_interval
        while self.online and not self._shutdown_event.is_set() and active_config.home_assistant.republish_discovery_interval > 0:
            try:
                await asyncio.sleep(1)
                wait -= 1
                if wait <= 0:
                    logger.info(f"{self.log_identity} re-publishing discovery")
                    await self.publish_discovery_async(mqtt_client, clean=False)
                    wait = active_config.home_assistant.republish_discovery_interval
            except asyncio.CancelledError:
                logger.debug(f"{self.log_identity} republish_discovery sleep interrupted")
                break
