from __future__ import annotations

import logging
from typing import Any, cast

import paho.mqtt.client as mqtt

from sigenergy2mqtt.common import (
    PERCENTAGE,
    Constants,
    DeviceClass,
    HybridInverter,
    InputType,
    ProtocolVersion,
    PVInverter,
    UnitOfFrequency,
    UnitOfPower,
    UnitOfReactivePower,
)
from sigenergy2mqtt.config import active_config
from sigenergy2mqtt.modbus import ModbusDataType
from sigenergy2mqtt.sensors.base import (
    AvailabilityMixin,
    DiscoveryKeys,
    NumericSensor,
    ReservedSensor,
    ScanInterval,
    SelectSensor,
    SwitchSensor,
    ThreePhaseAdjustmentTargetValue,
    WriteOnlySensor,
)

logger = logging.getLogger(__name__)


class PlantStatus(WriteOnlySensor, HybridInverter, PVInverter):
    ADDRESS = 40000

    def __init__(self, plant_index: int):
        super().__init__(
            name="Plant Power On/Off",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_status",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            protocol_version=ProtocolVersion.V1_8,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "0:Stop 1:Start"
        return attributes


## //---------------------- 5-2-2 Plant setting parameter power dispatch register definition ----------------------// ##
"""
The power dispatch registers in Table 5-2-2 applies at the location marked ③ in figure. For these registers to take effect, 
the following two conditions must be met: 

    a.The Modbus register for remote EMS enable (40029) is set to 0x01; 
    b.The Modbus register for remote EMS control mode (40031)is set to 0x00. 

*Note: These registers only control the power of PCS and is independent of loads and grid sensors.
"""


class ActivePowerFixedAdjustmentTargetValue(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40001

    def __init__(self, plant_index: int, remote_ems: AvailabilityMixin, remote_ems_mode: RemoteEMSControlMode):
        super().__init__(
            availability_control_sensor=remote_ems,
            name="Active Power Fixed Adjustment Target Value",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_active_power_fixed_adjustment_target_value",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.INT32,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfPower.KILO_WATT,
            device_class=DeviceClass.POWER,
            icon="mdi:lightning-bolt",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V1_8,
        )
        ## NOTE: Min/Max are set dynamically based on the total rated active power of the plant during main.setup_devices ##
        self._remote_ems_mode: RemoteEMSControlMode = remote_ems_mode

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        if active_config.home_assistant.enabled:
            cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({
                "topic": self._remote_ems_mode.is_pcs_remote_control_mode_topic,
                "payload_available": 1,
                "payload_not_available": 0,
            })
        return base

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Remote EMS must be enabled and the EMS must be in PCS Remote Control Mode for this register to take effect."
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state == 0:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': {self._remote_ems_mode.log_identity} is not in PCS Remote Control Mode")
            return False
        return await super().value_is_valid(transport, raw_value)


class ReactivePowerFixedAdjustmentTargetValue(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40003

    def __init__(self, plant_index: int, remote_ems: AvailabilityMixin, remote_ems_mode: RemoteEMSControlMode):
        super().__init__(
            availability_control_sensor=remote_ems,
            name="Reactive Power Fixed Adjustment Target Value",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_reactive_power_fixed_adjustment_target_value",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.INT32,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfReactivePower.KILO_VOLT_AMPERE_REACTIVE,
            device_class=DeviceClass.REACTIVE_POWER,
            icon="mdi:lightning-bolt",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V1_8,
        )
        ## NOTE: Min/Max are set dynamically to ±60% of the total rated active power of the plant during main.setup_devices.
        ## No literal default is given here: the protocol range is relative to the rated power ("base value"), so a
        ## fixed number would be a misleading range when the rated power cannot be read. ##
        self._remote_ems_mode: RemoteEMSControlMode = remote_ems_mode

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        if active_config.home_assistant.enabled:
            cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({
                "topic": self._remote_ems_mode.is_pcs_remote_control_mode_topic,
                "payload_available": 1,
                "payload_not_available": 0,
            })
        return base

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [-60.00 * base value ,60.00 * base value]. Remote EMS must be enabled and the EMS must be in PCS Remote Control Mode for this register to take effect."
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state == 0:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': {self._remote_ems_mode.log_identity} is not in PCS Remote Control Mode")
            return False
        return await super().value_is_valid(transport, raw_value)


class ActivePowerPercentageAdjustmentTargetValue(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40005

    def __init__(self, plant_index: int, remote_ems: AvailabilityMixin, remote_ems_mode: RemoteEMSControlMode):
        super().__init__(
            availability_control_sensor=remote_ems,
            name="Active Power Percentage Adjustment Target Value",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_active_power_percentage_adjustment_target_value",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.INT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=PERCENTAGE,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:percent",
            gain=100,
            precision=None,
            protocol_version=ProtocolVersion.V1_8,
            minimum=-100.00,
            maximum=100.00,
        )
        self._remote_ems_mode: RemoteEMSControlMode = remote_ems_mode

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        if active_config.home_assistant.enabled:
            cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({
                "topic": self._remote_ems_mode.is_pcs_remote_control_mode_topic,
                "payload_available": 1,
                "payload_not_available": 0,
            })
        return base

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [-100.00,100.00]. Remote EMS must be enabled and the EMS must be in PCS Remote Control Mode for this register to take effect."
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state == 0:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': {self._remote_ems_mode.log_identity} is not in PCS Remote Control Mode")
            return False
        return await super().value_is_valid(transport, raw_value)


class QSAdjustmentTargetValue(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40006

    def __init__(self, plant_index: int, remote_ems: AvailabilityMixin, remote_ems_mode: RemoteEMSControlMode):
        super().__init__(
            availability_control_sensor=remote_ems,
            name="Q/S Adjustment Target Value",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_q_s_adjustment_target_value",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.INT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=PERCENTAGE,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:lightning-bolt",
            gain=100,
            precision=None,
            protocol_version=ProtocolVersion.V1_8,
            minimum=-60.0,
            maximum=60.0,
        )
        self._remote_ems_mode: RemoteEMSControlMode = remote_ems_mode

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        if active_config.home_assistant.enabled:
            cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({
                "topic": self._remote_ems_mode.is_pcs_remote_control_mode_topic,
                "payload_available": 1,
                "payload_not_available": 0,
            })
        return base

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [-60.0,60.00]. Remote EMS must be enabled and the EMS must be in PCS Remote Control Mode for this register to take effect."
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state == 0:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': {self._remote_ems_mode.log_identity} is not in PCS Remote Control Mode")
            return False
        return await super().value_is_valid(transport, raw_value)


class PowerFactorAdjustmentTargetValue(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40007

    # Range: (-1,-0.8]U[0.8, 1]
    def __init__(self, plant_index: int, remote_ems: AvailabilityMixin, remote_ems_mode: RemoteEMSControlMode):
        super().__init__(
            availability_control_sensor=remote_ems,
            name="Power Factor Adjustment Target Value",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_power_factor_adjustment_target_value",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.INT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=None,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:lightning-bolt",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V1_8,
            minimum=(-1.0, -0.8),
            maximum=(0.8, 1.0),
        )
        self._remote_ems_mode: RemoteEMSControlMode = remote_ems_mode

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        if active_config.home_assistant.enabled:
            cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({
                "topic": self._remote_ems_mode.is_pcs_remote_control_mode_topic,
                "payload_available": 1,
                "payload_not_available": 0,
            })
        return base

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [(-1.0, -0.8) U (0.8, 1.0)]. Grid Sensor needed. Remote EMS must be enabled and the EMS must be in PCS Remote Control Mode for this register to take effect."
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state == 0:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': {self._remote_ems_mode.log_identity} is not in PCS Remote Control Mode")
            return False
        return await super().value_is_valid(transport, raw_value)


class PhaseActivePowerFixedAdjustmentTargetValue(ThreePhaseAdjustmentTargetValue, HybridInverter):
    def __init__(self, plant_index: int, remote_ems_mode: RemoteEMSControlMode, independent_phase_power_control: IndependentPhasePowerControl, output_type: int, phase: str):
        match phase:
            case "A":
                address = 40008
            case "B":
                address = 40010
            case "C":
                address = 40012
            case _:
                raise ValueError("Phase must be 'A', 'B', or 'C'")
        super().__init__(
            availability_control_sensor=independent_phase_power_control,
            name=f"Phase {phase} Active Power Fixed Adjustment Target Value",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_phase_{phase.lower()}_active_power_fixed_adjustment_target_value",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=address,
            count=2,
            data_type=ModbusDataType.INT32,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfPower.KILO_WATT,
            device_class=DeviceClass.POWER,
            icon="mdi:lightning-bolt",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V1_8,
            phase=phase,
            output_type=output_type,
        )
        ## NOTE: Min/Max are set dynamically based on the total rated active power of the plant during main.setup_devices ##
        self._remote_ems_mode: RemoteEMSControlMode = remote_ems_mode

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        if active_config.home_assistant.enabled:
            cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({
                "topic": self._remote_ems_mode.is_pcs_remote_control_mode_topic,
                "payload_available": 1,
                "payload_not_available": 0,
            })
        return base

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Valid only when Output Type is L1/L2/L3/N. Remote EMS must be enabled and the EMS must be in PCS Remote Control Mode for this register to take effect."
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state == 0:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': {self._remote_ems_mode.log_identity} is not in PCS Remote Control Mode")
            return False
        return await super().value_is_valid(transport, raw_value)


class PhaseReactivePowerFixedAdjustmentTargetValue(ThreePhaseAdjustmentTargetValue, HybridInverter):
    def __init__(self, plant_index: int, remote_ems_mode: RemoteEMSControlMode, independent_phase_power_control: IndependentPhasePowerControl, output_type: int, phase: str):
        match phase:
            case "A":
                address = 40014
            case "B":
                address = 40016
            case "C":
                address = 40018
            case _:
                raise ValueError("Phase must be 'A', 'B', or 'C'")
        super().__init__(
            availability_control_sensor=independent_phase_power_control,
            name=f"Phase {phase} Reactive Power Fixed Adjustment Target Value",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_phase_{phase.lower()}_reactive_power_fixed_adjustment_target_value",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=address,
            count=2,
            data_type=ModbusDataType.INT32,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfReactivePower.KILO_VOLT_AMPERE_REACTIVE,
            device_class=DeviceClass.REACTIVE_POWER,
            icon="mdi:lightning-bolt",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V1_8,
            phase=phase,
            output_type=output_type,
        )
        ## NOTE: Min/Max are set dynamically based on the total rated active power of the plant during main.setup_devices ##
        self._remote_ems_mode: RemoteEMSControlMode = remote_ems_mode

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        if active_config.home_assistant.enabled:
            cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({
                "topic": self._remote_ems_mode.is_pcs_remote_control_mode_topic,
                "payload_available": 1,
                "payload_not_available": 0,
            })
        return base

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Valid only when Output Type is L1/L2/L3/N. Remote EMS must be enabled and the EMS must be in PCS Remote Control Mode for this register to take effect."
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state == 0:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': {self._remote_ems_mode.log_identity} is not in PCS Remote Control Mode")
            return False
        return await super().value_is_valid(transport, raw_value)


class PhaseActivePowerPercentageAdjustmentTargetValue(ThreePhaseAdjustmentTargetValue, HybridInverter):
    def __init__(self, plant_index: int, remote_ems_mode: RemoteEMSControlMode, independent_phase_power_control: IndependentPhasePowerControl, output_type: int, phase: str):
        match phase:
            case "A":
                address = 40020
            case "B":
                address = 40021
            case "C":
                address = 40022
            case _:
                raise ValueError("Phase must be 'A', 'B', or 'C'")
        super().__init__(
            availability_control_sensor=independent_phase_power_control,
            name=f"Phase {phase} Active Power Percentage Adjustment Target Value",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_phase_{phase.lower()}_active_power_percentage_adjustment_target_value",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=address,
            count=1,
            data_type=ModbusDataType.INT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=PERCENTAGE,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:percent",
            gain=100,
            precision=None,
            protocol_version=ProtocolVersion.V1_8,
            minimum=-100.00,
            maximum=100.00,
            phase=phase,
            output_type=output_type,
        )
        self._remote_ems_mode: RemoteEMSControlMode = remote_ems_mode

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        if active_config.home_assistant.enabled:
            cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({
                "topic": self._remote_ems_mode.is_pcs_remote_control_mode_topic,
                "payload_available": 1,
                "payload_not_available": 0,
            })
        return base

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Valid only when Output Type is L1/L2/L3/N. Range: [-100.00,100.00]. Remote EMS must be enabled and the EMS must be in PCS Remote Control Mode for this register to take effect."
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state == 0:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': {self._remote_ems_mode.log_identity} is not in PCS Remote Control Mode")
            return False
        return await super().value_is_valid(transport, raw_value)


class PhaseQSAdjustmentTargetValue(ThreePhaseAdjustmentTargetValue, HybridInverter):
    def __init__(self, plant_index: int, remote_ems_mode: RemoteEMSControlMode, independent_phase_power_control: IndependentPhasePowerControl, output_type: int, phase: str):
        match phase:
            case "A":
                address = 40023
            case "B":
                address = 40024
            case "C":
                address = 40025
            case _:
                raise ValueError("Phase must be 'A', 'B', or 'C'")
        super().__init__(
            availability_control_sensor=independent_phase_power_control,
            name=f"Phase {phase} Q/S Fixed Adjustment Target Value",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_phase_{phase.lower()}_q_s_fixed_adjustment_target_value",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=address,
            count=1,
            data_type=ModbusDataType.INT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=PERCENTAGE,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:percent",
            gain=100,
            precision=None,
            protocol_version=ProtocolVersion.V1_8,
            minimum=-60.00,
            maximum=60.00,
            phase=phase,
            output_type=output_type,
        )
        self._remote_ems_mode: RemoteEMSControlMode = remote_ems_mode

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        if active_config.home_assistant.enabled:
            cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({
                "topic": self._remote_ems_mode.is_pcs_remote_control_mode_topic,
                "payload_available": 1,
                "payload_not_available": 0,
            })
        return base

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Valid only when Output Type is L1/L2/L3/N. Range: [-60.00,60.00]. Remote EMS must be enabled and the EMS must be in PCS Remote Control Mode for this register to take effect."
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state == 0:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': {self._remote_ems_mode.log_identity} is not in PCS Remote Control Mode")
            return False
        return await super().value_is_valid(transport, raw_value)


## //---------------------- End of Plant setting parameter power dispatch register definition ----------------------// ##


class Reserved40026(ReservedSensor, HybridInverter, PVInverter):
    ADDRESS = 40026

    def __init__(self, plant_index: int):
        super().__init__(
            name="Reserved",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_reserved_40026",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=3,
            data_type=ModbusDataType.STRING,
            scan_interval=ScanInterval.medium(plant_index),
            unit=None,
            device_class=None,
            state_class=None,
            icon="mdi:comment-question",
            gain=None,
            precision=None,
            protocol_version=ProtocolVersion.V2_5,
        )


class RemoteEMS(SwitchSensor, HybridInverter, PVInverter, AvailabilityMixin):
    ADDRESS = 40029

    @property
    def payload_available(self) -> bool | int | float | str | None:
        return 1

    @property
    def payload_not_available(self) -> bool | int | float | str | None:
        return 0

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Remote EMS",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_remote_ems",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.high(plant_index),
            protocol_version=ProtocolVersion.V1_8,
        )
        # Set by RemoteEMSPowerLimitGlobalEnable so that changes to either switch update the combined power limits topic
        self.power_limit_global_enable: RemoteEMSPowerLimitGlobalEnable | None = None

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "When needed to control EMS remotely, this register needs to be enabled. When enabled, the plant’s EMS Work Mode (30003) will switch to RemoteEMS"
        return attributes

    async def publish(self, mqtt_client: mqtt.Client, transport: Any, republish: bool = False) -> bool:
        result = await super().publish(mqtt_client, transport, republish=republish)
        if result and self.power_limit_global_enable is not None:
            self.power_limit_global_enable.publish_power_limits_active(mqtt_client)
        return result


class RemoteEMSControlMode(SelectSensor, HybridInverter, PVInverter):
    ADDRESS = 40031

    def __init__(self, plant_index: int, remote_ems: AvailabilityMixin):
        super().__init__(
            availability_control_sensor=remote_ems,
            name="Remote EMS Control Mode",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_remote_ems_control_mode",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.medium(plant_index),
            options=[
                "PCS remote control",  # 0
                "Standby",  # 1
                "Maximum Self-consumption (Default)",  # 2
                "Command Charging (Consume power from the grid first)",  # 3
                "Command Charging (Consume power from the PV first)",  # 4
                "Command Discharging (Output power from PV first)",  # 5
                "Command Discharging (Output power from the battery first)",  # 6
                "",  # 7,
                "V2G (Vehicle to Grid)",  # 8
            ],
            protocol_version=ProtocolVersion.V1_8,
        )

    def clean_state(self, mqtt_client: mqtt.Client) -> None:
        """Clean up published sensor state."""
        for key in ("is_charging_discharging_topic", "is_charging_mode_topic", "is_discharging_mode_topic", "is_pcs_remote_control_mode_topic"):
            topic = getattr(self, key, None)
            if topic:
                self._publish_message(mqtt_client, topic, b"", qos=1)
        return super().clean_state(mqtt_client)

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        self.is_pcs_remote_control_mode_topic = f"{base}/is_pcs_remote_control_mode"
        if active_config.home_assistant.enabled and active_config.ems_mode_check:
            self.is_charging_mode_topic = f"{base}/is_charging_mode"
            self.is_discharging_mode_topic = f"{base}/is_discharging_mode"
            self.is_charging_discharging_topic = f"{base}/is_command_mode"
        return base

    async def publish(self, mqtt_client: mqtt.Client, transport: Any, republish: bool = False) -> bool:
        result = await super().publish(mqtt_client, transport, republish=republish)
        if result and active_config.home_assistant.enabled:
            pcs_remote_control_mode = "0"
            charging_mode = "0"
            discharging_mode = "0"
            charging_discharging_mode = "0"
            if self._availability_control_sensor is not None and self._availability_control_sensor.latest_raw_state in (1, "1"):
                match self.latest_raw_state:
                    case 0:
                        pcs_remote_control_mode = "1"
                    case 3 | 4:
                        charging_mode = "1"
                        discharging_mode = "0"
                        charging_discharging_mode = "1"
                    case 5 | 6:
                        charging_mode = "0"
                        discharging_mode = "1"
                        charging_discharging_mode = "1"
            mqtt_client.publish(self.is_pcs_remote_control_mode_topic, pcs_remote_control_mode, self._qos, self._retain)
            if active_config.ems_mode_check:
                mqtt_client.publish(self.is_charging_mode_topic, charging_mode, self._qos, self._retain)
                mqtt_client.publish(self.is_discharging_mode_topic, discharging_mode, self._qos, self._retain)
                mqtt_client.publish(self.is_charging_discharging_topic, charging_discharging_mode, self._qos, self._retain)
            return True
        return result

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._availability_control_sensor is not None and self._availability_control_sensor.latest_raw_state in (0, "0"):
            logger.error(
                f"{self.log_identity} Failed to write '{cast(list[str], self['options'])[raw_value] if isinstance(raw_value, int) else raw_value}' ({raw_value}): {self._availability_control_sensor.log_identity} is not enabled"
            )
            return False
        return await super().value_is_valid(transport, raw_value)


class IndependentPhasePowerControl(SwitchSensor, AvailabilityMixin, HybridInverter):
    ADDRESS = 40030

    @property
    def payload_available(self) -> bool | int | float | str | None:
        return 1

    @property
    def payload_not_available(self) -> bool | int | float | str | None:
        return 0

    # Valid only when Output Type is L1/L2/L3/N. To enable independent phase control, this parameter must be enabled.
    def __init__(self, plant_index: int, output_type: int):
        super().__init__(
            availability_control_sensor=None,
            name="Independent Phase Power Control",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_independent_phase_power_control",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.high(plant_index),
            protocol_version=ProtocolVersion.V1_8,
        )
        if output_type != Constants.THREE_PHASE_OUTPUT_TYPE:  # L1/L2/L3/N
            self.publishable = False

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Valid only when Output Type is L1/L2/L3/N. To enable independent phase control, this parameter must be enabled"
        return attributes


## //--------------------- 5-2-1 Plant setting parameter power limitation register definition ---------------------// ##


class RemoteEMSLimit(NumericSensor, HybridInverter):
    """Configurable base implementation for Remote EMS limit sensors."""

    def __init__(
        self,
        availability_control_sensor: AvailabilityMixin | None,
        remote_ems_mode: RemoteEMSControlMode | None,
        charging: bool,
        discharging: bool,
        name: str,
        object_id: str,
        plant_index: int,
        address: int,
        icon: str,
        maximum: float,
        protocol_version: ProtocolVersion,
        global_enable: RemoteEMSPowerLimitGlobalEnable | None = None,
    ):
        super().__init__(
            availability_control_sensor=availability_control_sensor,
            name=name,
            object_id=object_id,
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=address,
            count=2,
            data_type=ModbusDataType.UINT32,
            scan_interval=ScanInterval.high(plant_index),
            unit=UnitOfPower.KILO_WATT,
            device_class=DeviceClass.POWER,
            icon=icon,
            gain=1000,
            precision=2,
            protocol_version=protocol_version,
            maximum=maximum,
        )
        self._remote_ems_mode = remote_ems_mode
        self._charging = charging
        self._discharging = discharging
        # Protocol V2.10+: the limit applies when 40162 is enabled or EMS Work Mode (30003) is Remote EMS (7),
        # and the register remains writable (and retained) at all times.
        self._global_enable = global_enable

    def activation_comment(self, legacy: str) -> str:
        """The comment suffix describing when this limit takes effect."""
        if self._global_enable is not None:
            return " Takes effect when Remote EMS Power Limit Global Enable (40162) is enabled, or when the EMS Work Mode (30003) is Remote EMS."
        # Only gated limits depend on the Remote EMS control mode (firmware without global limits)
        return legacy if active_config.ems_mode_check and self._availability_control_sensor is not None else ""

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        power_limits_active_topic = self._global_enable.power_limits_active_topic if self._global_enable is not None else None
        if power_limits_active_topic is not None and self._global_enable is not None and self._global_enable.publishes_power_limits_active and active_config.home_assistant.enabled:
            # Available when either Remote EMS Power Limit Global Enable or Remote EMS is enabled (protocol V2.10)
            cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({
                "topic": power_limits_active_topic,
                "payload_available": 1,
                "payload_not_available": 0,
            })
        if self._remote_ems_mode and active_config.home_assistant.enabled and active_config.ems_mode_check:
            if self._charging and self._discharging:
                cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({
                    "topic": self._remote_ems_mode.is_charging_discharging_topic,
                    "payload_available": 1,
                    "payload_not_available": 0,
                })
            elif self._charging:
                cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({"topic": self._remote_ems_mode.is_charging_mode_topic, "payload_available": 1, "payload_not_available": 0})
            elif self._discharging:
                cast(list[dict[str, float | int | str]], self[DiscoveryKeys.AVAILABILITY]).append({"topic": self._remote_ems_mode.is_discharging_mode_topic, "payload_available": 1, "payload_not_available": 0})
        return base

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._availability_control_sensor is not None and self._availability_control_sensor.latest_raw_state == 0:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': {self._availability_control_sensor.log_identity} is not enabled")
            return False
        return await super().value_is_valid(transport, raw_value)


class MaxChargingLimit(RemoteEMSLimit):
    ADDRESS = 40032

    def __init__(
        self,
        plant_index: int,
        remote_ems: AvailabilityMixin | None,
        remote_ems_mode: RemoteEMSControlMode | None,
        rated_charging_power: float,
        global_enable: RemoteEMSPowerLimitGlobalEnable | None = None,
    ):
        super().__init__(
            availability_control_sensor=remote_ems,
            remote_ems_mode=remote_ems_mode,
            charging=True,
            discharging=False,
            name="Max Charging Limit",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_max_charging_limit",
            plant_index=plant_index,
            address=self.ADDRESS,
            icon="mdi:battery-charging-high",
            maximum=rated_charging_power,
            protocol_version=ProtocolVersion.V1_8,
            global_enable=global_enable,
        )
        self.sanity_check.max_raw = Constants.UINT32_MAX  # This will be the default value read from Modbus if no value is set by user

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = (
            f"The maximum charging power of the ESS in the plant must not exceed the value configured in this sensor. Range: [0, Rated ESS charging power].{self.activation_comment(' Takes effect when Remote EMS control mode (40031) is set to Command Charging.')}"
        )
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._availability_control_sensor is not None and self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state not in (3, 4) and active_config.ems_mode_check:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': Remote EMS control mode is not set to Command Charging")
            return False
        return await super().value_is_valid(transport, raw_value)


class MaxDischargingLimit(RemoteEMSLimit):
    ADDRESS = 40034

    def __init__(
        self,
        plant_index: int,
        remote_ems: AvailabilityMixin | None,
        remote_ems_mode: RemoteEMSControlMode | None,
        rated_discharging_power: float,
        global_enable: RemoteEMSPowerLimitGlobalEnable | None = None,
    ):
        super().__init__(
            availability_control_sensor=remote_ems,
            remote_ems_mode=remote_ems_mode,
            name="Max Discharging Limit",
            charging=False,
            discharging=True,
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_max_discharging_limit",
            plant_index=plant_index,
            address=self.ADDRESS,
            icon="mdi:battery-charging-low",
            maximum=rated_discharging_power,
            protocol_version=ProtocolVersion.V1_8,
            global_enable=global_enable,
        )
        self.sanity_check.max_raw = Constants.UINT32_MAX  # This will be the default value read from Modbus if no value is set by user

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = (
            f"The maximum discharging power of the ESS in the plant must not exceed the value configured in this sensor. Range: [0, Rated ESS discharging power].{self.activation_comment(' Takes effect when Remote EMS control mode (40031) is set to Command Discharging.')}"
        )
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._availability_control_sensor is not None and self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state not in (5, 6) and active_config.ems_mode_check:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': Remote EMS control mode is not set to Command Discharging")
            return False
        return await super().value_is_valid(transport, raw_value)


class PVMaxPowerLimit(RemoteEMSLimit):
    ADDRESS = 40036

    def __init__(self, plant_index: int, remote_ems: AvailabilityMixin | None, remote_ems_mode: RemoteEMSControlMode | None, global_enable: RemoteEMSPowerLimitGlobalEnable | None = None):
        super().__init__(
            availability_control_sensor=remote_ems,
            remote_ems_mode=remote_ems_mode,
            charging=True,
            discharging=True,
            name="PV Max Power Limit",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_pv_max_power_limit",
            plant_index=plant_index,
            address=self.ADDRESS,
            icon="mdi:solar-power",
            maximum=4294967.295,
            protocol_version=ProtocolVersion.V1_8,
            global_enable=global_enable,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = (
            f"The maximum output power of the PV strings in the plant must not exceed the value configured in this sensor.{self.activation_comment(' Takes effect when Remote EMS control mode (40031) is set to Command Charging.')}"
        )
        return attributes

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        if self._availability_control_sensor is not None and self._remote_ems_mode is not None and self._remote_ems_mode.latest_raw_state not in (3, 4, 5, 6) and active_config.ems_mode_check:
            logger.error(f"{self.log_identity} Failed to write value '{raw_value}': Remote EMS control mode is not set to Command Charging/Discharging")
            return False
        return await super().value_is_valid(transport, raw_value)


class GridMaxExportLimit(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40038

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Grid Max Export Limit",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_grid_max_export_limit",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.UINT32,
            scan_interval=ScanInterval.high(plant_index),
            unit=UnitOfPower.KILO_WATT,
            device_class=DeviceClass.POWER,
            icon="mdi:transmission-tower-export",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V2_5,
            maximum=4294967.295,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "The maximum active power fed into the grid must not exceed the value configured in this sensor. Grid Sensor needed. Takes effect globally regardless of the EMS operating mode"
        return attributes


class GridMaxImportLimit(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40040

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Grid Max Import Limit",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_grid_max_import_limit",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.UINT32,
            scan_interval=ScanInterval.high(plant_index),
            unit=UnitOfPower.KILO_WATT,
            device_class=DeviceClass.POWER,
            icon="mdi:transmission-tower-import",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V2_5,
            maximum=4294967.295,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = (
            "The maximum active power absorbed from the grid must not exceed the value configured in this sensor. Grid Sensor needed. Takes effect globally regardless of the EMS operating mode"
        )
        return attributes


class PCSMaxExportLimit(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40042

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="PCS Max Export Limit",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_pcs_max_export_limit",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.UINT32,
            scan_interval=ScanInterval.high(plant_index),
            unit=UnitOfPower.KILO_WATT,
            device_class=DeviceClass.POWER,
            icon="mdi:battery-negative",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V2_5,
            maximum=4294967.294,
        )
        self.sanity_check.max_raw = Constants.UINT32_MAX

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = (
            "The maximum active power output of the inverter in the plant must not exceed the value configured in this sensor. Range:[0, 0xFFFFFFFE]。With value 0xFFFFFFFF, register is not valid. In all other cases, Takes effect globally."
        )
        return attributes


class PCSMaxImportLimit(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40044

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="PCS Max Import Limit",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_pcs_max_import_limit",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.UINT32,
            scan_interval=ScanInterval.high(plant_index),
            unit=UnitOfPower.KILO_WATT,
            device_class=DeviceClass.POWER,
            icon="mdi:battery-positive",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V2_5,
            maximum=4294967.294,
        )
        self.sanity_check.max_raw = Constants.UINT32_MAX

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = (
            "The maximum active power input of the inverter in the plant must not exceed the value configured in this sensor. Range:[0, 0xFFFFFFFE]。With value 0xFFFFFFFF, register is not valid. In all other cases, Takes effect globally."
        )
        return attributes


class PCCPowerFactorAdjustmentTargetValueGridImport(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40157

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="PCC Power Factor Adjustment Target Value (Grid Import)",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_pcc_power_factor_adjustment_target_value_grid_import",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.INT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=None,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:lightning-bolt",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V2_9,
            minimum=(-1.0, -0.8),
            maximum=(0.8, 1.0),
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = (
            "When purchasing electricity at the grid connection point, the power factor must be controlled to the value configured in this sensor. Range: [(-1.0, -0.8) U (0.8, 1.0)]. Grid Sensor needed."
        )
        return attributes


class PCCPowerFactorAdjustmentTargetValueGridExport(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40158

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="PCC Power Factor Adjustment Target Value (Grid Export)",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_pcc_power_factor_adjustment_target_value_grid_export",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.INT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=None,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:lightning-bolt",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V2_9,
            minimum=(-1.0, -0.8),
            maximum=(0.8, 1.0),
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = (
            "When selling electricity at the grid connection point, the power factor must be controlled to the value configured in this sensor. Range: [(-1.0, -0.8) U (0.8, 1.0)]. Grid Sensor needed."
        )
        return attributes


## //--------------------- End of Plant setting parameter power limitation register definition ---------------------// ##


class ESSBackupSOC(NumericSensor, HybridInverter):
    ADDRESS = 40046

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Backup SoC",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_ess_backup_soc",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=PERCENTAGE,
            device_class=DeviceClass.BATTERY,
            icon="mdi:percent-box-outline",
            gain=10,
            precision=None,
            protocol_version=ProtocolVersion.V2_6,
        )
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [0.00,100.00]"
        return attributes


class ESSChargeCutOffSOC(NumericSensor, HybridInverter):
    ADDRESS = 40047

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Charge Cut-Off SoC",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_ess_charge_cut_off_soc",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=PERCENTAGE,
            device_class=DeviceClass.BATTERY,
            icon="mdi:percent-box-outline",
            gain=10,
            precision=None,
            protocol_version=ProtocolVersion.V2_6,
        )
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [0.00,100.00]"
        return attributes


class ESSDischargeCutOffSOC(NumericSensor, HybridInverter):
    ADDRESS = 40048

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Discharge Cut-Off SoC",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_ess_discharge_cut_off_soc",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=PERCENTAGE,
            device_class=DeviceClass.BATTERY,
            icon="mdi:percent-box-outline",
            gain=10,
            precision=None,
            protocol_version=ProtocolVersion.V2_6,
        )
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [0.00,100.00]"
        return attributes


class ActivePowerRegulationGradient(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40049

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Active Power Regulation Gradient",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_active_power_regulation_gradient",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.UINT32,
            scan_interval=ScanInterval.medium(plant_index),
            unit="%/s",
            device_class=None,
            icon="mdi:gradient-horizontal",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V2_8,
            maximum=5000,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range:[0,5000]。Percentage of rated power adjusted per second"
        return attributes


class GridCodeLVRT(SwitchSensor, HybridInverter, PVInverter):
    ADDRESS = 40051

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Low Voltage Ride Through",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_lvrt",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.medium(plant_index),
            protocol_version=ProtocolVersion.V2_8,
        )
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True


class GridCodeLVRTReactivePowerCompensationFactor(NumericSensor, HybridInverter):
    ADDRESS = 40052

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="LVRT Reactive Power Compensation Factor",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_lvrt_reactive_power_compensation_factor",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=None,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:counter",
            gain=100,
            precision=1,
            protocol_version=ProtocolVersion.V2_8,
            maximum=10.0,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [0,10.0]"
        return attributes


class GridCodeLVRTNegativeSequenceReactivePowerCompensationFactor(NumericSensor, HybridInverter):
    ADDRESS = 40053

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="LVRT Negative Sequence Reactive Power Compensation Factor",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_lvrt_negative_sequence_reactive_power_compensation_factor",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=None,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:counter",
            gain=100,
            precision=1,
            protocol_version=ProtocolVersion.V2_8,
            maximum=20.0,  # ProtocolVersion says 0.0-10.0 but live systems are returning 20.0???? (https://github.com/seud0nym/sigenergy2mqtt/issues/80#issuecomment-3689277867)
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Documented Range: [0,10.0] but using 20.0 as maximum because live systems are returning this value"
        return attributes


class GridCodeLVRTMode(SelectSensor, HybridInverter, PVInverter):
    ADDRESS = 40054

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="LVRT Mode",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_lvrt_mode",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.medium(plant_index),
            options=[
                "Reactive power compensation current, active zero-current mode",  # 0
                "",  # 1
                "Zero-current mode",  # 2
                "Constant current mode",  # 3
                "Reactive dynamic current, active zero-current mode",  # 4
                "Reactive power compensation current, active constant-current mode",  # 5
            ],
            protocol_version=ProtocolVersion.V2_8,
        )
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True


class GridCodeLVRTVoltageProtectionBlocking(SwitchSensor, HybridInverter, PVInverter):
    ADDRESS = 40055

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="LVRT Grid Voltage Protection Blocking",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_lvrt_grid_voltage_protection_blocking",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.medium(plant_index),
            protocol_version=ProtocolVersion.V2_8,
        )


class GridCodeHVRT(SwitchSensor, HybridInverter, PVInverter):
    ADDRESS = 40056

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="High Voltage Ride Through",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_hvrt",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.medium(plant_index),
            protocol_version=ProtocolVersion.V2_8,
        )
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True


class GridCodeHVRTReactivePowerCompensationFactor(NumericSensor, HybridInverter):
    ADDRESS = 40057

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="HVRT Reactive Power Compensation Factor",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_hvrt_reactive_power_compensation_factor",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=None,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:counter",
            gain=100,
            precision=1,
            protocol_version=ProtocolVersion.V2_8,
            maximum=10.0,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [0,10.0]"
        return attributes


class GridCodeHVRTNegativeSequenceReactivePowerCompensationFactor(NumericSensor, HybridInverter):
    ADDRESS = 40058

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="HVRT Negative Sequence Reactive Power Compensation Factor",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_hvrt_negative_sequence_reactive_power_compensation_factor",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=None,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:counter",
            gain=100,
            precision=1,
            protocol_version=ProtocolVersion.V2_8,
            maximum=10.0,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [0,10.0]"
        return attributes


class GridCodeHVRTMode(SelectSensor, HybridInverter, PVInverter):
    ADDRESS = 40059

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="HVRT Mode",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_hvrt_mode",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.medium(plant_index),
            options=[
                "Reactive power compensation current, active zero-current mode",  # 0
                "",  # 1
                "Zero-current mode",  # 2
                "Constant current mode",  # 3
                "Reactive dynamic current, active hold mode",  # 4
                "Reactive power compensation current, active constant-current mode",  # 5
            ],
            protocol_version=ProtocolVersion.V2_8,
        )
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True


class GridCodeHVRTVoltageProtectionBlocking(SwitchSensor, HybridInverter, PVInverter):
    ADDRESS = 40060

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="HVRT Grid Voltage Protection Blocking",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_hvrt_grid_voltage_protection_blocking",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.medium(plant_index),
            protocol_version=ProtocolVersion.V2_8,
        )


class GridCodeOverFrequencyDerating(SwitchSensor, HybridInverter, PVInverter):
    ADDRESS = 40061

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Over Frequency Derating",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_over_frequency_derating",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.medium(plant_index),
            protocol_version=ProtocolVersion.V2_8,
        )
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True


class GridCodeOverFrequencyDeratingPowerRampRate(NumericSensor, HybridInverter):
    ADDRESS = 40062

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Over Frequency Derating Power Ramp Rate",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_over_frequency_derating_power_ramp_rate",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=PERCENTAGE,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:percent-box-outline",
            gain=100,
            precision=1,
            protocol_version=ProtocolVersion.V2_8,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [0,100.0]"
        return attributes


class GridCodeOverFrequencyDeratingTriggerFrequency(NumericSensor, HybridInverter):
    ADDRESS = 40063

    def __init__(self, plant_index: int, rated_frequency: float):
        super().__init__(
            availability_control_sensor=None,
            name="Over Frequency Derating Trigger Frequency",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_over_frequency_derating_trigger_frequency",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfFrequency.HERTZ,
            device_class=DeviceClass.FREQUENCY,
            icon="mdi:sine-wave",
            gain=100,
            precision=1,
            protocol_version=ProtocolVersion.V2_8,
            minimum=1.0 * rated_frequency,
            maximum=1.2 * rated_frequency,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range:[1.0*Fn, 1.2*Fn] Reference:[Grid code] Rated Frequency (Register 30276)"
        return attributes


class GridCodeOverFrequencyDeratingCutOffFrequency(NumericSensor, HybridInverter):
    ADDRESS = 40064

    def __init__(self, plant_index: int, rated_frequency: float):
        super().__init__(
            availability_control_sensor=None,
            name="Over Frequency Derating Cut-Off Frequency",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_over_frequency_derating_cut_off_frequency",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfFrequency.HERTZ,
            device_class=DeviceClass.FREQUENCY,
            icon="mdi:sine-wave",
            gain=100,
            precision=1,
            protocol_version=ProtocolVersion.V2_8,
            minimum=1.0 * rated_frequency,
            maximum=1.2 * rated_frequency,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range:[1.0*Fn, 1.2*Fn] Reference:[Grid code] Rated Frequency (Register 30276)"
        return attributes


class GridCodeUnderFrequencyPowerBoost(SwitchSensor, HybridInverter, PVInverter):
    ADDRESS = 40065

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Under-Frequency Power Boost",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_under_frequency_power_boost",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.medium(plant_index),
            protocol_version=ProtocolVersion.V2_8,
        )
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True


class GridCodeUnderFrequencyPowerBoostPowerRampRate(NumericSensor, HybridInverter):
    ADDRESS = 40066

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Under-Frequency Power Boost Power Ramp Rate",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_under_frequency_power_boost_power_ramp_rate",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=PERCENTAGE,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:percent-box-outline",
            gain=100,
            precision=1,
            protocol_version=ProtocolVersion.V2_8,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range: [0,100.0]"
        return attributes


class GridCodeUnderFrequencyPowerBoostTriggerFrequency(NumericSensor, HybridInverter):
    ADDRESS = 40067

    def __init__(self, plant_index: int, rated_frequency: float):
        super().__init__(
            availability_control_sensor=None,
            name="Under-Frequency Power Boost Trigger Frequency",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_under_frequency_power_boost_trigger_frequency",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfFrequency.HERTZ,
            device_class=DeviceClass.FREQUENCY,
            icon="mdi:sine-wave",
            gain=100,
            precision=1,
            protocol_version=ProtocolVersion.V2_8,
            minimum=0.8 * rated_frequency,
            maximum=1.0 * rated_frequency,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range:[0.8*Fn, 1.0*Fn] Reference:[Grid code] Rated Frequency (Register 30276)"
        return attributes


class GridCodeUnderFrequencyPowerBoostCutOffFrequency(NumericSensor, HybridInverter):
    ADDRESS = 40068

    def __init__(self, plant_index: int, rated_frequency: float):
        super().__init__(
            availability_control_sensor=None,
            name="Under-Frequency Power Boost Cut-Off Frequency",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_code_under_frequency_power_boost_cut_off_frequency",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfFrequency.HERTZ,
            device_class=DeviceClass.FREQUENCY,
            icon="mdi:sine-wave",
            gain=100,
            precision=1,
            protocol_version=ProtocolVersion.V2_8,
            minimum=0.8 * rated_frequency,
            maximum=1.0 * rated_frequency,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range:[0.8*Fn, 1.0*Fn] Reference:[Grid code] Rated Frequency (Register 30276)"
        return attributes


class Reserved40069(ReservedSensor, HybridInverter, PVInverter):
    ADDRESS = 40069

    def __init__(self, plant_index: int):
        super().__init__(
            name="Reserved",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_reserved_40069",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=88,
            data_type=ModbusDataType.STRING,
            scan_interval=ScanInterval.low(plant_index),
            unit=None,
            device_class=None,
            state_class=None,
            icon="mdi:comment-question",
            gain=None,
            precision=None,
            protocol_version=ProtocolVersion.V2_9,
        )


class GridPowerLossLockoutAlarmClear(WriteOnlySensor, HybridInverter, PVInverter):
    ADDRESS = 40159

    def __init__(self, plant_index: int):
        super().__init__(
            name="Grid Power Loss Lockout Alarm Clear",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_grid_power_loss_lockout_alarm_clear",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            protocol_version=ProtocolVersion.V2_9,
            name_off="",
            name_on="Clear",
            icon_on="mdi:lock-reset",
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Write 1 to clear the grid power loss lockout alarm"
        return attributes


class ReactivePowerRegulationGradient(NumericSensor, HybridInverter, PVInverter):
    ADDRESS = 40160

    def __init__(self, plant_index: int):
        super().__init__(
            availability_control_sensor=None,
            name="Reactive Power Regulation Gradient",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_reactive_power_regulation_gradient",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.UINT32,
            scan_interval=ScanInterval.medium(plant_index),
            unit="%/s",
            device_class=None,
            icon="mdi:gradient-horizontal",
            gain=1000,
            precision=2,
            protocol_version=ProtocolVersion.V2_10,
            maximum=5000,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Range:[0,5000]。Percentage of rated power adjusted per second"
        return attributes


class RemoteEMSPowerLimitGlobalEnable(SwitchSensor, HybridInverter):
    """Remote EMS power limit global enable (protocol V2.10).

    The ESS max charging/discharging limits and PV max power limit (40032~40036) take effect when this register is 1 or
    the EMS work mode (30003) is Remote EMS, which is the case when Remote EMS (40029) is enabled. Home Assistant
    availability requires every availability topic to be available, so the "either switch is on" condition is
    published as a single combined topic (``power_limits_active_topic``) by both this sensor and Remote EMS.
    """

    ADDRESS = 40162

    def __init__(self, plant_index: int, remote_ems: RemoteEMS | None = None):
        super().__init__(
            availability_control_sensor=None,
            name="Remote EMS Power Limit Global Enable",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_plant_remote_ems_power_limit_global_enable",
            plant_index=plant_index,
            device_address=Constants.PLANT_DEVICE_ADDRESS,
            address=self.ADDRESS,
            scan_interval=ScanInterval.medium(plant_index),
            protocol_version=ProtocolVersion.V2_10,
        )
        self._remote_ems = remote_ems
        if remote_ems is not None:
            remote_ems.power_limit_global_enable = self
        self.power_limits_active_topic: str | None = None

    @property
    def power_limits_active(self) -> bool:
        """True if either this switch or Remote EMS is enabled, so the power limits (40032~40036) take effect."""
        enabled = (1, "1")
        return self.latest_raw_state in enabled or (self._remote_ems is not None and self._remote_ems.latest_raw_state in enabled)

    def configure_mqtt_topics(self, device_id: str) -> str:
        base = super().configure_mqtt_topics(device_id)
        self.power_limits_active_topic = f"{base}/power_limits_active"
        return base

    @property
    def publishes_power_limits_active(self) -> bool:
        """True if the combined topic will be published, which requires both switches to be read and published.

        They are not when hidden (e.g. by no-remote-ems), in which case the power limits cannot depend on the topic.
        """
        return bool(self.power_limits_active_topic) and self.publishable and self._remote_ems is not None and self._remote_ems.publishable

    def publish_power_limits_active(self, mqtt_client: mqtt.Client) -> None:
        """Publish 1 to the combined topic if either switch is enabled, otherwise 0."""
        if self.power_limits_active_topic and active_config.home_assistant.enabled:
            mqtt_client.publish(self.power_limits_active_topic, "1" if self.power_limits_active else "0", self._qos, self._retain)

    async def publish(self, mqtt_client: mqtt.Client, transport: Any, republish: bool = False) -> bool:
        result = await super().publish(mqtt_client, transport, republish=republish)
        if result:
            self.publish_power_limits_active(mqtt_client)
        return result

    def clean_state(self, mqtt_client: mqtt.Client) -> None:
        """Clean up published sensor state."""
        if self.power_limits_active_topic:
            self._publish_message(mqtt_client, self.power_limits_active_topic, b"", qos=1)
        return super().clean_state(mqtt_client)

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = (
            "When enabled, Max Charging Limit (40032), Max Discharging Limit (40034) and PV Max Power Limit (40036) take effect regardless of the EMS Work Mode. "
            "When disabled, they only take effect when the EMS Work Mode (30003) is Remote EMS. Default: disabled"
        )
        return attributes
