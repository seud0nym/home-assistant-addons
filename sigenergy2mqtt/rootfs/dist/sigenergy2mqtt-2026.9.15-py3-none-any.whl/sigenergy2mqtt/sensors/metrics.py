"""
Sensor entities that expose :class:`~sigenergy2mqtt.metrics.Metrics`
values over MQTT.

Each sensor reads one or more class-level attributes from :class:`Metrics` on
every scan interval and publishes the result to its configured state topic
under ``sigenergy2mqtt/metrics/``.
"""

import logging
import time
from typing import Any, cast

from sigenergy2mqtt.common import PERCENTAGE, DeviceClass, ProtocolApplies, ProtocolVersion
from sigenergy2mqtt.config import active_config
from sigenergy2mqtt.metrics import Metrics
from sigenergy2mqtt.sensors.base import DiscoveryKeys, ReadableSensorMixin, WriteOnlySensorMixin

logger = logging.getLogger(__name__)


class MetricsSensor(ReadableSensorMixin):
    """
    Base class for all metrics sensors.

    Subclasses implement :meth:`_update_internal_state` to pull the relevant
    value from :class:`Metrics` and call :meth:`set_latest_state`. The default
    scan interval is 1 second.

    MQTT topics are structured as ``sigenergy2mqtt/metrics/<suffix>`` where
    *suffix* is the ``object_id`` with the ``sigenergy2mqtt_`` prefix stripped,
    and availability is tied to ``sigenergy2mqtt/status``.
    """

    def __init__(
        self,
        attribute: str | None,
        name: str,
        unique_id: str,
        object_id: str,
        unit: str | None = None,
        device_class: DeviceClass | None = None,
        icon: str | None = None,
        precision: int | None = None,
        **kwargs,
    ):
        scan_interval = kwargs.pop("scan_interval", 1)
        super().__init__(
            name=name,
            unique_id=unique_id,
            object_id=object_id,
            unit=unit,
            device_class=device_class,
            state_class=None,
            icon=icon,
            gain=None,
            precision=precision,
            scan_interval=scan_interval,
            **kwargs,
        )
        if attribute is not None and not hasattr(Metrics, attribute):
            raise AttributeError(f"{self.log_identity} Metrics has no attribute '{attribute}'")
        self._attribute = attribute
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True

    def _get_base_topic(self, device_id: str) -> str:
        """Get the base MQTT topic for this sensor.

        Args:
            device_id: The device identifier

        Returns:
            Base topic path
        """
        base = "sigenergy2mqtt/metrics"
        object_id = cast(str, self[DiscoveryKeys.OBJECT_ID])
        suffix = object_id.replace("sigenergy2mqtt_", "")
        return f"{base}/{suffix}"

    async def _update_internal_state(self, **kwargs) -> bool:
        if self._attribute is None:
            raise NotImplementedError(f"{self.log_identity} No attribute has been defined so _update_internal_state must be overridden in the subclass")
        state = getattr(Metrics, self._attribute)
        if state == float("-inf") or state == float("inf"):
            return False
        self.set_latest_state(state)
        return True

    def configure_mqtt_topics(self, device_id: str) -> str:
        """
        Override topic configuration to use the ``sigenergy2mqtt/metrics/`` namespace.

        The state topic is derived from ``object_id`` by stripping the
        ``sigenergy2mqtt_`` prefix: e.g. ``sigenergy2mqtt_modbus_locks``
        becomes ``sigenergy2mqtt/metrics/modbus_locks``.
        """
        topic = self._get_base_topic(device_id)
        self[DiscoveryKeys.STATE_TOPIC] = topic
        self[DiscoveryKeys.AVAILABILITY_TOPIC] = "sigenergy2mqtt/status"
        if self.debug_logging:
            logger.debug(f"{self.log_identity} Configured MQTT topics >>> state_topic={self[DiscoveryKeys.STATE_TOPIC]})")
        return topic

    def publish_attributes(self, mqtt_client: Any, clean: bool = False, **kwargs) -> None:
        """Metrics sensors do not publish extra MQTT attributes."""


# =============================================================================
# MQTT Metrics Sensors
# =============================================================================


class MQTTPublishFailures(MetricsSensor):
    """Cumulative count of MQTT state publish failures."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_mqtt_publish_failures",
            name="MQTT Publish Failures",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_mqtt_publish_failures",
            object_id="sigenergy2mqtt_mqtt_publish_failures",
            icon="mdi:counter",
            precision=0,
        )


class MQTTPhysicalPublishes(MetricsSensor):
    """Percentage of MQTT publish attempts that were physically published."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_mqtt_physical_publish_percentage",
            name="MQTT Physical Publishes",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_mqtt_physical_publish_percentage",
            object_id="sigenergy2mqtt_mqtt_physical_publish_percentage",
            unit=PERCENTAGE,
            icon="mdi:percent",
            precision=2,
        )


# =============================================================================
# Modbus Metrics Sensors
# =============================================================================


class ModbusCacheHits(MetricsSensor):
    """Percentage of modbus reads satisfied from cache."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_cache_hit_percentage",
            name="Modbus Cache Hits",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_cache_hit_percentage",
            object_id="sigenergy2mqtt_modbus_cache_hit_percentage",
            unit=PERCENTAGE,
            icon="mdi:percent",
            precision=2,
        )


class ModbusPhysicalReads(MetricsSensor):
    """Percentage of modbus reads that resulted in a physical bus read (i.e. cache misses)."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_physical_read_percentage",
            name="Modbus Physical Reads",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_physical_reads",
            object_id="sigenergy2mqtt_modbus_physical_reads",
            unit=PERCENTAGE,
            icon="mdi:percent",
            precision=2,
        )


class ModbusReadsPerSecond(MetricsSensor):
    """Modbus register reads per second since service start."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_reads",
            name="Modbus Reads/second",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_reads_sec",
            object_id="sigenergy2mqtt_modbus_reads_sec",
            icon="mdi:timer-play-outline",
            precision=2,
        )

    async def _update_internal_state(self, **kwargs) -> bool:
        elapsed = time.monotonic() - Metrics._started
        if elapsed > 0:
            value = Metrics.sigenergy2mqtt_modbus_reads / elapsed
        else:
            value = 0.0
        self.set_latest_state(value)
        return True


class ModbusReadErrors(MetricsSensor):
    """Cumulative count of modbus read errors."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_read_errors",
            name="Modbus Read Errors",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_read_errors",
            object_id="sigenergy2mqtt_modbus_read_errors",
            icon="mdi:counter",
            precision=0,
        )


class ModbusReadMax(MetricsSensor):
    """Maximum single modbus read duration in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_read_max",
            name="Modbus Read Max",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_read_max",
            object_id="sigenergy2mqtt_modbus_read_max",
            unit="ms",
            icon="mdi:timer-plus-outline",
            precision=2,
        )


class ModbusReadMean(MetricsSensor):
    """Mean modbus read duration per register read, in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_read_mean",
            name="Modbus Read Mean",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_read_mean",
            object_id="sigenergy2mqtt_modbus_read_mean",
            unit="ms",
            icon="mdi:timer-outline",
            precision=2,
        )


class ModbusReadMin(MetricsSensor):
    """Minimum single modbus read duration in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_read_min",
            name="Modbus Read Min",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_read_min",
            object_id="sigenergy2mqtt_modbus_read_min",
            unit="ms",
            icon="mdi:timer-minus-outline",
            precision=2,
        )


class ModbusSkippedErrors(MetricsSensor):
    """Cumulative count of modbus skipped errors."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_skipped_errors",
            name="Modbus Skipped Errors",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_skipped_errors",
            object_id="sigenergy2mqtt_modbus_skipped_reads",
            icon="mdi:counter",
            precision=0,
        )
        self.publishable = any(device.log_skipped is False for device in active_config.modbus)


class ModbusWriteErrors(MetricsSensor):
    """Cumulative count of modbus write errors."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_write_errors",
            name="Modbus Write Errors",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_write_errors",
            object_id="sigenergy2mqtt_modbus_write_errors",
            icon="mdi:counter",
            precision=0,
        )


class ModbusWriteMax(MetricsSensor):
    """Maximum single modbus write duration in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_write_max",
            name="Modbus Write Max",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_write_max",
            object_id="sigenergy2mqtt_modbus_write_max",
            unit="ms",
            icon="mdi:timer-plus-outline",
            precision=2,
        )


class ModbusWriteMean(MetricsSensor):
    """Mean modbus write duration per write call, in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_write_mean",
            name="Modbus Write Mean",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_write_mean",
            object_id="sigenergy2mqtt_modbus_write_mean",
            unit="ms",
            icon="mdi:timer-outline",
            precision=2,
        )


class ModbusWriteMin(MetricsSensor):
    """Minimum single modbus write duration in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_modbus_write_min",
            name="Modbus Write Min",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_write_min",
            object_id="sigenergy2mqtt_modbus_write_min",
            unit="ms",
            icon="mdi:timer-minus-outline",
            precision=2,
        )


class ModbusActiveLocks(MetricsSensor):
    """Number of coroutines currently waiting to acquire a modbus lock."""

    def __init__(self):
        super().__init__(
            attribute=None,
            name="Modbus Active Locks",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_locks",
            object_id="sigenergy2mqtt_modbus_locks",
            icon="mdi:eye-lock",
            precision=0,
        )

    async def _update_internal_state(self, **kwargs) -> bool:
        from sigenergy2mqtt.modbus import ModbusLockFactory

        value = ModbusLockFactory.get_waiter_count()
        self.set_latest_state(value)
        return True


# =============================================================================
# Diagnostic Sensors
# =============================================================================


class Started(MetricsSensor):
    """ISO-8601 timestamp of when the service commenced, set at actual start time."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_started",
            name="Started",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_started",
            object_id="sigenergy2mqtt_started",
            device_class=DeviceClass.TIMESTAMP,
            icon="mdi:calendar-clock",
        )
        self["entity_category"] = "diagnostic"


class ProtocolVersionSensor(MetricsSensor):
    """The Sigenergy modbus protocol version in use."""

    def __init__(self, protocol_version: ProtocolVersion):
        super().__init__(
            attribute=None,
            name="Protocol Version",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_protocol",
            object_id="sigenergy2mqtt_modbus_protocol",
            icon="mdi:book-information-variant",
        )
        self["entity_category"] = "diagnostic"
        self.protocol_version = protocol_version

    async def _update_internal_state(self, **kwargs) -> bool:
        value = self.protocol_version.value
        self.set_latest_state(str(value))
        return True


class ProtocolPublished(MetricsSensor):
    """The date from which the active Sigenergy modbus protocol applies."""

    def __init__(self, protocol_version: ProtocolVersion):
        super().__init__(
            attribute=None,
            name="Protocol Published",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_modbus_protocol_published",
            object_id="sigenergy2mqtt_modbus_protocol_published",
            icon="mdi:book-clock",
        )
        self["entity_category"] = "diagnostic"
        self.protocol_version = protocol_version

    async def _update_internal_state(self, **kwargs) -> bool:
        value = ProtocolApplies(self.protocol_version)
        self.set_latest_state(str(value))
        return True


# =============================================================================
# InfluxDB Metrics Sensors
# =============================================================================


class InfluxDBWrites(MetricsSensor):
    """Cumulative count of InfluxDB write operations."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_influxdb_writes",
            name="InfluxDB Writes",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_influxdb_writes",
            object_id="sigenergy2mqtt_influxdb_writes",
            icon="mdi:database-arrow-up",
            precision=0,
        )
        self.publishable = active_config.influxdb.enabled


class InfluxDBWriteErrors(MetricsSensor):
    """Cumulative count of InfluxDB write errors."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_influxdb_write_errors",
            name="InfluxDB Write Errors",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_influxdb_write_errors",
            object_id="sigenergy2mqtt_influxdb_write_errors",
            icon="mdi:database-alert",
            precision=0,
        )
        self.publishable = active_config.influxdb.enabled


class InfluxDBWriteMax(MetricsSensor):
    """Maximum single InfluxDB write duration in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_influxdb_write_max",
            name="InfluxDB Write Max",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_influxdb_write_max",
            object_id="sigenergy2mqtt_influxdb_write_max",
            unit="ms",
            icon="mdi:timer-plus-outline",
            precision=2,
        )
        self.publishable = active_config.influxdb.enabled


class InfluxDBWriteMin(MetricsSensor):
    """Minimum InfluxDB write duration per write call, in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_influxdb_write_min",
            name="InfluxDB Write Min",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_influxdb_write_min",
            object_id="sigenergy2mqtt_influxdb_write_min",
            unit="ms",
            icon="mdi:timer-outline",
            precision=2,
        )
        self.publishable = active_config.influxdb.enabled


class InfluxDBWriteMean(MetricsSensor):
    """Mean InfluxDB write duration per write call, in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_influxdb_write_mean",
            name="InfluxDB Write Mean",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_influxdb_write_mean",
            object_id="sigenergy2mqtt_influxdb_write_mean",
            unit="ms",
            icon="mdi:timer-outline",
            precision=2,
        )
        self.publishable = active_config.influxdb.enabled


class InfluxDBQueries(MetricsSensor):
    """Cumulative count of InfluxDB query operations."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_influxdb_queries",
            name="InfluxDB Queries",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_influxdb_queries",
            object_id="sigenergy2mqtt_influxdb_queries",
            icon="mdi:database-search",
            precision=0,
        )
        self.publishable = active_config.influxdb.enabled


class InfluxDBQueryErrors(MetricsSensor):
    """Cumulative count of InfluxDB query errors."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_influxdb_query_errors",
            name="InfluxDB Query Errors",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_influxdb_query_errors",
            object_id="sigenergy2mqtt_influxdb_query_errors",
            icon="mdi:database-alert-outline",
            precision=0,
        )
        self.publishable = active_config.influxdb.enabled


class InfluxDBRetries(MetricsSensor):
    """Cumulative count of InfluxDB retry attempts."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_influxdb_retries",
            name="InfluxDB Retries",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_influxdb_retries",
            object_id="sigenergy2mqtt_influxdb_retries",
            icon="mdi:reload",
            precision=0,
        )
        self.publishable = active_config.influxdb.enabled


class InfluxDBRateLimitWaits(MetricsSensor):
    """Cumulative count of number of times execution was paused due to InfluxDB rate limiting."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_influxdb_rate_limit_waits",
            name="InfluxDB Rate Limit Waits",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_influxdb_rate_limit_waits",
            object_id="sigenergy2mqtt_influxdb_rate_limit_waits",
            icon="mdi:reload",
            precision=0,
        )
        self.publishable = active_config.influxdb.enabled


class InfluxDBThroughput(MetricsSensor):
    """InfluxDB data points written per second since service start."""

    def __init__(self):
        super().__init__(
            attribute=None,
            name="InfluxDB Throughput",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_influxdb_throughput",
            object_id="sigenergy2mqtt_influxdb_throughput",
            icon="mdi:speedometer",
            precision=2,
        )
        self.publishable = active_config.influxdb.enabled

    async def _update_internal_state(self, **kwargs) -> bool:
        elapsed = time.monotonic() - Metrics._started
        if elapsed > 0:
            value = Metrics.sigenergy2mqtt_influxdb_batch_total / elapsed
        else:
            value = 0.0
        self.set_latest_state(value)
        return True


# =============================================================================
# StateStore Metrics Sensors
# =============================================================================


class StateStoreSaves(MetricsSensor):
    """Cumulative count of StateStore save operations."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_state_store_saves",
            name="State Store Saves",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_state_store_saves",
            object_id="sigenergy2mqtt_state_store_saves",
            icon="mdi:content-save",
            precision=0,
        )


class StateStoreSaveErrors(MetricsSensor):
    """Cumulative count of StateStore save errors."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_state_store_save_errors",
            name="State Store Save Errors",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_state_store_save_errors",
            object_id="sigenergy2mqtt_state_store_save_errors",
            icon="mdi:content-save-alert",
            precision=0,
        )


class StateStoreSaveMax(MetricsSensor):
    """Maximum single StateStore save duration in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_state_store_save_max",
            name="State Store Save Max",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_state_store_save_max",
            object_id="sigenergy2mqtt_state_store_save_max",
            unit="ms",
            icon="mdi:timer-plus-outline",
            precision=2,
        )


class StateStoreSaveMean(MetricsSensor):
    """Mean StateStore save duration per save call, in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_state_store_save_mean",
            name="State Store Save Mean",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_state_store_save_mean",
            object_id="sigenergy2mqtt_state_store_save_mean",
            unit="ms",
            icon="mdi:timer-outline",
            precision=2,
        )


class StateStoreSaveMin(MetricsSensor):
    """Minimum single StateStore save duration in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_state_store_save_min",
            name="State Store Save Min",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_state_store_save_min",
            object_id="sigenergy2mqtt_state_store_save_min",
            unit="ms",
            icon="mdi:timer-minus-outline",
            precision=2,
        )


class StateStoreLoads(MetricsSensor):
    """Cumulative count of StateStore load operations."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_state_store_loads",
            name="State Store Loads",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_state_store_loads",
            object_id="sigenergy2mqtt_state_store_loads",
            icon="mdi:folder-open-outline",
            precision=0,
        )


class StateStoreLoadHitPercentage(MetricsSensor):
    """Percentage of StateStore load calls that returned a value (cache/disk hit rate)."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_state_store_load_hit_percentage",
            name="State Store Load Hits %",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_state_store_load_hit_percentage",
            object_id="sigenergy2mqtt_state_store_load_hit_percentage",
            unit=PERCENTAGE,
            icon="mdi:percent",
            precision=2,
        )


class StateStoreLoadErrors(MetricsSensor):
    """Cumulative count of StateStore load errors."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_state_store_load_errors",
            name="State Store Load Errors",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_state_store_load_errors",
            object_id="sigenergy2mqtt_state_store_load_errors",
            icon="mdi:folder-alert-outline",
            precision=0,
        )


class StateStoreDeletes(MetricsSensor):
    """Cumulative count of StateStore delete operations."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_state_store_deletes",
            name="State Store Deletes",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_state_store_deletes",
            object_id="sigenergy2mqtt_state_store_deletes",
            icon="mdi:trash-can-outline",
            precision=0,
        )


class StateStoreDeleteErrors(MetricsSensor):
    """Cumulative count of StateStore delete errors."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_state_store_delete_errors",
            name="State Store Delete Errors",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_state_store_delete_errors",
            object_id="sigenergy2mqtt_state_store_delete_errors",
            icon="mdi:delete-alert-outline",
            precision=0,
        )


# =============================================================================
# PVOutput Metrics Sensors
# =============================================================================


class PVOutputUploads(MetricsSensor):
    """Cumulative count of PVOutput upload operations."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_pvoutput_uploads",
            name="PVOutput Uploads",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_pvoutput_uploads",
            object_id="sigenergy2mqtt_pvoutput_uploads",
            icon="mdi:cloud-upload",
            precision=0,
        )
        self.publishable = active_config.pvoutput.enabled


class PVOutputUploadErrors(MetricsSensor):
    """Cumulative count of PVOutput upload errors."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_pvoutput_upload_errors",
            name="PVOutput Upload Errors",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_pvoutput_upload_errors",
            object_id="sigenergy2mqtt_pvoutput_upload_errors",
            icon="mdi:cloud-alert",
            precision=0,
        )
        self.publishable = active_config.pvoutput.enabled


class PVOutputUploadSkipped(MetricsSensor):
    """Cumulative count of skipped PVOutput uploads."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_pvoutput_upload_skipped",
            name="PVOutput Upload Skipped",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_pvoutput_upload_skipped",
            object_id="sigenergy2mqtt_pvoutput_upload_skipped",
            icon="mdi:cloud-off-outline",
            precision=0,
        )
        self.publishable = active_config.pvoutput.enabled


class PVOutputUploadMax(MetricsSensor):
    """Maximum single PVOutput upload duration in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_pvoutput_upload_max",
            name="PVOutput Upload Max",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_pvoutput_upload_max",
            object_id="sigenergy2mqtt_pvoutput_upload_max",
            unit="ms",
            icon="mdi:timer-plus-outline",
            precision=2,
        )
        self.publishable = active_config.pvoutput.enabled


class PVOutputUploadMean(MetricsSensor):
    """Mean PVOutput upload duration per upload call, in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_pvoutput_upload_mean",
            name="PVOutput Upload Mean",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_pvoutput_upload_mean",
            object_id="sigenergy2mqtt_pvoutput_upload_mean",
            unit="ms",
            icon="mdi:timer-outline",
            precision=2,
        )
        self.publishable = active_config.pvoutput.enabled


class PVOutputUploadMin(MetricsSensor):
    """Minimum single PVOutput upload duration in milliseconds."""

    def __init__(self):
        super().__init__(
            attribute="sigenergy2mqtt_pvoutput_upload_min",
            name="PVOutput Upload Min",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_pvoutput_upload_min",
            object_id="sigenergy2mqtt_pvoutput_upload_min",
            unit="ms",
            icon="mdi:timer-minus-outline",
            precision=2,
        )
        self.publishable = active_config.pvoutput.enabled


# =============================================================================
# Reset control
# =============================================================================


class ResetMetrics(WriteOnlySensorMixin):
    """Button that resets all metrics counters to their default values.

    Unlike typical :class:`WriteOnlySensor` subclasses this sensor:

    * does **not** write to a Modbus register,
    * creates a **single** button (not an On/Off pair), and
    * publishes its topics under the ``sigenergy2mqtt/metrics/`` namespace.
    """

    _PAYLOAD_PRESS = "reset"

    def __init__(self):
        super().__init__(
            name="Reset Metrics",
            unique_id=f"{active_config.home_assistant.unique_id_prefix}_metrics_reset",
            object_id="sigenergy2mqtt_metrics_reset",
            unit=None,
            device_class=None,
            state_class=None,
            icon=None,
            gain=None,
            precision=None,
            protocol_version=ProtocolVersion.N_A,
            icon_off="mdi:reload",
            icon_on="mdi:reload",
            name_off="Reset Metrics",
            name_on="Reset Metrics",
            payload_off=self._PAYLOAD_PRESS,
            payload_on=self._PAYLOAD_PRESS,
            value_off=1,
            value_on=1,
        )
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True

    def _get_base_topic(self, device_id: str) -> str:
        """Get the base MQTT topic for this sensor.

        Args:
            device_id: The device identifier

        Returns:
            Base topic path
        """
        base = "sigenergy2mqtt/metrics"
        object_id = cast(str, self[DiscoveryKeys.OBJECT_ID])
        suffix = object_id.replace("sigenergy2mqtt_", "")
        return f"{base}/{suffix}"

    def configure_mqtt_topics(self, device_id: str) -> str:
        """Place command and availability topics inside the metrics namespace."""
        topic = self._get_base_topic(device_id)
        self[DiscoveryKeys.STATE_TOPIC] = topic
        self[DiscoveryKeys.COMMAND_TOPIC] = f"{topic}/set"
        self[DiscoveryKeys.AVAILABILITY_TOPIC] = "sigenergy2mqtt/status"
        if self.debug_logging:
            logger.debug(f"{self.log_identity} Configured MQTT topics >>> command_topic={self[DiscoveryKeys.COMMAND_TOPIC]})")
        return topic

    def get_discovery_components(self) -> dict[str, dict[str, Any]]:
        """Return a single button component instead of the default On/Off pair."""
        config: dict[str, Any] = {}

        for k, v in self.items():
            if v is None:
                continue
            if k == DiscoveryKeys.NAME:
                config[k] = self._names["on"]
            elif k in (DiscoveryKeys.OBJECT_ID, DiscoveryKeys.UNIQUE_ID):
                # Keep the ids as-is — single button, no suffix needed
                config[k] = v
            else:
                config[k] = v

        config[DiscoveryKeys.ICON] = self._icons["on"]
        config["payload_press"] = self._PAYLOAD_PRESS

        components: dict[str, dict[str, Any]] = {self.unique_id: config}

        if self.debug_logging:
            logger.debug(f"{self.log_identity} Discovered components={components}")

        return components

    def publish_attributes(self, mqtt_client: Any, clean: bool = False, **kwargs) -> None:
        """Metrics sensors do not publish extra MQTT attributes."""

    async def _write_value(self, transport: Any | None, mqtt_client: Any, value: float | str, source: str, handler: Any) -> bool:
        """Reset metrics counters."""
        if str(value) == "1":
            logger.info(f"{self.log_identity} Resetting all metrics counters")
            await Metrics.reset()
            return True
        logger.warning(f"ResetMetrics: Ignored unexpected payload '{value}'")
        return False
