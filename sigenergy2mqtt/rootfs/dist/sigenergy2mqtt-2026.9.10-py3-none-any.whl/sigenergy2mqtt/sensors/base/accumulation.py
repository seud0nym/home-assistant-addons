"""Accumulation sensors: ResettableAccumulationSensor, EnergyLifetimeAccumulationSensor, EnergyDailyAccumulationSensor."""

from __future__ import annotations

import asyncio
import logging
import sys
import time
from datetime import timedelta
from typing import TYPE_CHECKING, Any, cast

import paho.mqtt.client as mqtt

from sigenergy2mqtt.common import DeviceClass, StateClass, UnitOfEnergy
from sigenergy2mqtt.i18n import _t
from sigenergy2mqtt.modbus import ModbusDataType
from sigenergy2mqtt.persistence import Category, state_store

from .constants import DiscoveryKeys, SensorAttributeKeys, _sanitize_path_component
from .derived import DerivedSensor
from .mixins import ObservableMixin
from .readable import ReadOnlySensor
from .sensor import Sensor

if TYPE_CHECKING:
    from sigenergy2mqtt.mqtt import MqttHandler

logger = logging.getLogger(__name__)
# =============================================================================


class AccumulationSensor(DerivedSensor):
    """Sensor that accumulates values using Riemann sum.

    Integrates readings over time to calculate a total value (e.g. power to energy).
    """

    if TYPE_CHECKING:

        @property
        def log_identity(self) -> str: ...

        def refresh_log_identity(self) -> None: ...

    def __init__(
        self,
        name: str,
        unique_id: str,
        object_id: str,
        source: Sensor,
        data_type: ModbusDataType,
        unit: str | None,
        device_class: DeviceClass | None,
        state_class: StateClass | None,
        icon: str | None,
        gain: float | None,
        precision: int | None,
        **kwargs,
    ):
        super().__init__(
            name=name,
            unique_id=unique_id,
            object_id=object_id,
            data_type=data_type,
            unit=unit,
            device_class=device_class,
            state_class=state_class,
            icon=icon,
            gain=gain,
            precision=precision,
            source_sensors=(source,),
            **kwargs,
        )

        self._source = source
        self._current_total_lock = asyncio.Lock()
        self._current_total: float = 0.0
        self._last_source_generation: int | None = None

        # Inherit discriminator fields from source early so init-time persistence
        # logs use the real identity rather than plant/dev=n/a.
        for discriminator in ("plant_index", "device_address", "string_number", "phase"):
            if hasattr(source, discriminator):
                setattr(self, discriminator, getattr(source, discriminator))
        self.refresh_log_identity()

        # Use sanitized unique_id for persistence key
        uid = str(self.unique_id)  # pyrefly:ignore
        if uid.startswith("<MagicMock"):  # For testing
            uid = "mock_uid"

        self._state_persistence_key: str = f"{_sanitize_path_component(uid)}.state"

        # Load persisted state
        self._load_persisted_state()
        self.set_latest_state(self._current_total)

    def _load_persisted_state(self) -> None:
        """Load accumulated value from persistent storage."""
        try:
            content = state_store.load_sync(Category.SENSOR, self._state_persistence_key)
        except (OSError, ValueError, TypeError, RuntimeError) as e:
            if isinstance(e, (OSError, RuntimeError)):
                logger.warning(f"{self.log_identity} Failed to read state for {self._state_persistence_key}: {e}")
            else:
                logger.error(f"{self.log_identity} Unexpected error reading state for {self._state_persistence_key}: {e}")
            return

        if content is not None:
            try:
                self._current_total = float(content)
                if self.debug_logging:
                    logger.debug(f"{self.log_identity} Loaded current state for {self._state_persistence_key} ({self._current_total})")
            except (ValueError, TypeError) as e:
                logger.warning(f"{self.log_identity} Failed to parse persisted state for {self._state_persistence_key}: {e}")

    async def _persist_current_total(self, new_total: float) -> None:
        """Persist accumulated value.

        Args:
            new_total: New total value to persist
        """
        async with self._current_total_lock:
            try:
                await state_store.save(Category.SENSOR, self._state_persistence_key, str(new_total))
            except PermissionError as e:
                logger.warning(f"{self.log_identity} Failed to persist state for {self._state_persistence_key}: {e}")
            except (ValueError, TypeError, RuntimeError) as e:
                logger.error(f"{self.log_identity} Unexpected error persisting state for {self._state_persistence_key}: {e}")

    def update_from_source_sensor(self, sensor: Sensor) -> bool:
        """Update accumulated value from source sensor.

        Args:
            sensor: Source sensor providing readings

        Returns:
            True if accumulation was updated
        """
        if sensor is not self._source:
            logger.warning(f"{self.log_identity} Attempt to call update_from_source_sensor from {sensor.log_identity}")
            return False

        if sensor.latest_raw_state is None or sensor.state_count < 2:
            return False  # Need at least two points

        source_generation = getattr(sensor, "update_generation", None)
        if isinstance(source_generation, int) and source_generation > 0:
            if source_generation == self._last_source_generation:
                return False
            self._last_source_generation = source_generation

        # Calculate time difference in hours
        source_interval = getattr(sensor, "successful_read_interval", None)
        if not isinstance(source_interval, (int, float)):
            source_interval = sensor.latest_interval
        interval_hours = source_interval / 3600 if source_interval else 0

        if interval_hours < 0:
            logger.warning(f"{self.log_identity} negative interval IGNORED (interval={source_interval})")
            return False
        if interval_hours >= 2:
            logger.warning(f"{self.log_identity} 2+ hour interval IGNORED (interval={source_interval})")
            return False

        # Convert negative power to zero
        previous = max(0.0, float(sensor.previous_raw_state if sensor.previous_raw_state is not None else 0.0))
        current = max(0.0, float(sensor.latest_raw_state if sensor.latest_raw_state is not None else 0.0))

        # Calculate accumulation using trapezoidal rule: E = 0.5 * (P1 + P2) * Δt
        increase = 0.5 * (previous + current) * interval_hours
        new_total = self._current_total + increase

        # Check for decreasing total
        if new_total < self._current_total and self.state_class == StateClass.TOTAL_INCREASING:
            logger.debug(f"{self.log_identity} negative increase IGNORED (current={self._current_total} prev={previous} curr={current} increase={increase} new={new_total} interval={source_interval:.2f}s)")
            return False

        # Update total
        if new_total != self._current_total:
            self.run_persistence_coroutine(self._persist_current_total(new_total))

        self._current_total = new_total
        self.set_latest_state(self._current_total)

        return True


class ResettableAccumulationSensor(ObservableMixin, AccumulationSensor):
    """Sensor that accumulates values with manual reset capability.

    Integrates readings over time to calculate a total value, with ability
    to reset the accumulated value via MQTT.
    """

    def __init__(
        self,
        name: str,
        unique_id: str,
        object_id: str,
        source: Sensor,
        data_type: ModbusDataType,
        unit: str | None,
        device_class: DeviceClass | None,
        state_class: StateClass | None,
        icon: str | None,
        gain: float | None,
        precision: int | None,
        **kwargs,
    ):
        super().__init__(
            name=name,
            unique_id=unique_id,
            object_id=object_id,
            source=source,
            data_type=data_type,
            unit=unit,
            device_class=device_class,
            state_class=state_class,
            icon=icon,
            gain=gain,
            precision=precision,
            **kwargs,
        )

        self._reset_topic = f"sigenergy2mqtt/{self[DiscoveryKeys.OBJECT_ID]}/reset"

    def get_discovery_components(self) -> dict[str, dict[str, Any]]:
        """Get discovery components including reset control.

        Returns:
            Dictionary of component configurations
        """
        # Create reset number input
        updater: dict[str, Any] = {
            DiscoveryKeys.PLATFORM: "number",
            DiscoveryKeys.NAME: _t(f"{self.__class__.__name__}.name_reset", f"Set {self.name}", self.debug_logging),
            DiscoveryKeys.OBJECT_ID: f"{self[DiscoveryKeys.OBJECT_ID]}_reset",
            DiscoveryKeys.UNIQUE_ID: f"{self.unique_id}_reset",
            DiscoveryKeys.ICON: "mdi:numeric",
            DiscoveryKeys.UNIT_OF_MEASUREMENT: self.unit,
            DiscoveryKeys.DISPLAY_PRECISION: self.precision,
            DiscoveryKeys.COMMAND_TOPIC: self._reset_topic,
            DiscoveryKeys.MIN: 0,
            DiscoveryKeys.MAX: sys.float_info.max,
            DiscoveryKeys.MODE: "box",
            DiscoveryKeys.STEP: 10 ** -(self.precision if self.precision else 0),
            DiscoveryKeys.ENABLED_BY_DEFAULT: False,
        }

        components: dict[str, dict[str, Any]] = super().get_discovery_components()
        components[updater[DiscoveryKeys.UNIQUE_ID]] = updater

        return components

    def observable_topics(self) -> set[str]:
        """Get observable MQTT topics including reset topic.

        Returns:
            Set of topic strings
        """
        topics = super().observable_topics()
        topics.add(self._reset_topic)
        return topics

    def get_attributes(self) -> dict[str, float | int | str]:
        """Get sensor attributes including reset topic.

        Returns:
            Dictionary of attributes
        """
        attributes = super().get_attributes()
        attributes[SensorAttributeKeys.RESET_TOPIC] = self._reset_topic
        if self.unit:
            attributes[SensorAttributeKeys.RESET_UNIT] = self.unit
        return attributes

    async def notify(self, transport: Any, mqtt_client: mqtt.Client, value: float | str, source: str, handler: MqttHandler) -> bool:
        """Handle reset command from MQTT.

        Args:
            transport: Transport client or None (unused)
            mqtt_client: MQTT client
            value: New total value
            source: Source topic
            handler: MqttHandler

        Returns:
            True if reset was handled
        """
        if source not in self.observable_topics():
            return False

        new_total = (value if isinstance(value, float) else float(value)) * self.gain

        logger.info(f"{self.log_identity} reset to {value} {self.unit} (raw={new_total})")

        if new_total != self._current_total:
            await self._persist_current_total(new_total)

        self._current_total = new_total
        self.set_latest_state(self._current_total)
        self.force_publish = True

        return True


# =============================================================================
# Energy Accumulation Sensors
# =============================================================================


class EnergyLifetimeAccumulationSensor(ResettableAccumulationSensor):
    """Lifetime energy accumulation sensor.

    Tracks total energy over the lifetime of the device.
    """

    def __init__(
        self,
        name: str,
        unique_id: str,
        object_id: str,
        source: Sensor,
        data_type=None,
        unit=UnitOfEnergy.KILO_WATT_HOUR,
        device_class=DeviceClass.ENERGY,
        state_class=StateClass.TOTAL_INCREASING,
        icon="mdi:home-lightning-bolt",
        gain=1000,
        precision=2,
        **kwargs,
    ):
        if data_type is None:
            data_type = ModbusDataType.UINT32

        super().__init__(
            name,
            unique_id,
            object_id,
            source,
            data_type=data_type,
            unit=unit,
            device_class=device_class,
            state_class=state_class,
            icon=icon,
            gain=gain,
            precision=precision,
            **kwargs,
        )


class EnergyDailyAccumulationSensor(ResettableAccumulationSensor):
    """Daily energy accumulation sensor.

    Tracks energy for the current day, automatically resetting at midnight.
    """

    def __init__(
        self,
        name: str,
        unique_id: str,
        object_id: str,
        source: ReadOnlySensor | DerivedSensor,
        **kwargs,
    ):
        super().__init__(
            name=name,
            unique_id=unique_id,
            object_id=object_id,
            source=source,
            data_type=source.data_type,
            unit=source.unit,
            device_class=source.device_class,
            state_class=source.state_class,
            icon=cast(str, source[DiscoveryKeys.ICON]),
            gain=source.gain,
            precision=source.precision,
            **kwargs,
        )

        self._state_at_midnight_lock = asyncio.Lock()
        self._state_at_midnight: float | None = None

        # Use sanitized unique_id for persistence key
        uid = str(source.unique_id)
        if uid.startswith("<MagicMock"):
            uid = "mock_uid_atmidnight"

        self._midnight_persistence_key = f"{_sanitize_path_component(uid)}.atmidnight"

    def on_added_to_device(self) -> None:
        super().on_added_to_device()
        # Load midnight state if it's from today
        self._load_midnight_state()

    def _load_midnight_state(self) -> None:
        """Load state at midnight if entry is from today."""
        try:
            content = state_store.load_sync(Category.SENSOR, self._midnight_persistence_key, stale_after=timedelta(hours=24))
        except (ValueError, TypeError, RuntimeError) as e:
            logger.warning(f"{self.log_identity} Failed to read midnight state for {self._midnight_persistence_key}: {e}")
            state_store.delete_sync(Category.SENSOR, self._midnight_persistence_key)
            return

        if content is None:
            # Ensure stale/missing files are cleared from disk
            state_store.delete_sync(Category.SENSOR, self._midnight_persistence_key)
            return

        try:
            value = float(content)
            if value <= 0.0:
                logger.debug(f"{self.log_identity} Ignored negative midnight state for {self._midnight_persistence_key} ({value})")
                state_store.delete_sync(Category.SENSOR, self._midnight_persistence_key)
            else:
                self._state_at_midnight = value
                if self.debug_logging:
                    logger.debug(f"{self.log_identity} Loaded midnight state for {self._midnight_persistence_key} ({self._state_at_midnight})")
        except (ValueError, TypeError) as e:
            logger.warning(f"{self.log_identity} Failed to parse midnight state for {self._midnight_persistence_key}: {e}")
            state_store.delete_sync(Category.SENSOR, self._midnight_persistence_key)

    async def _update_state_at_midnight(self, midnight_state: float | None) -> None:
        """Persist state at midnight.

        Args:
            midnight_state: State value at midnight
        """
        if midnight_state is None:
            return

        async with self._state_at_midnight_lock:
            try:
                await state_store.save(Category.SENSOR, self._midnight_persistence_key, str(midnight_state))
            except (ValueError, TypeError, RuntimeError) as e:
                logger.warning(f"{self.log_identity} Failed to update midnight state for {self._midnight_persistence_key}: {e}")

            self._state_at_midnight = midnight_state

    async def notify(self, transport: Any, mqtt_client: mqtt.Client, value: float | str, source: str, handler: MqttHandler) -> bool:
        """Handle reset command.

        Args:
            transport: Transport client or None (unused)
            mqtt_client: MQTT client
            value: New value
            source: Source topic
            handler: MqttHandler

        Returns:
            True if handled
        """
        if source not in self.observable_topics():
            return False

        if self.debug_logging:
            logger.debug(f"{self.log_identity} notified of updated state {value} {self.unit}")

        self._state_now = (value if isinstance(value, float) else float(value)) * self.gain

        # Calculate new midnight state
        source_raw = self._source.latest_raw_state
        updated_midnight_state = (float(source_raw) - self._state_now) if isinstance(source_raw, (float, int)) and source_raw else self._state_now

        if self.debug_logging:
            logger.debug(f"{self.log_identity} source_raw={self._source.latest_raw_state} (from {self._source.unique_id}) state_now={self._state_now} midnight_state={updated_midnight_state}")

        await self._update_state_at_midnight(updated_midnight_state)
        self.set_latest_state(self._state_now)

        logger.info(f"{self.log_identity} reset to {value} {self.unit} (raw={self._state_now})")

        self.force_publish = True
        return True

    async def publish(self, mqtt_client: mqtt.Client, transport: Any, republish: bool = False) -> bool:
        """Publish state, ensuring midnight state is persisted.

        Args:
            mqtt_client: MQTT client
            transport: Modbus client
            republish: If True, republish last state

        Returns:
            True if published
        """
        latest_raw = self._source.latest_raw_state
        if self._state_at_midnight is None and latest_raw is not None:
            # Note: state_store already handles redundancy, so we just ensuring it's "set"
            # if somehow it wasn't on disk but was in memory.
            await self._update_state_at_midnight(float(latest_raw))

        return await super().publish(mqtt_client, transport, republish)

    def update_from_source_sensor(self, sensor: Sensor) -> bool:
        """Update daily accumulation from source values.

        Args:
            sensor: Source sensor

        Returns:
            True if updated
        """
        if sensor is not self._source:
            logger.warning(f"{self.log_identity} Attempt to call update_from_source_sensor from {sensor.log_identity}")
            return False

        if sensor.latest_raw_state is None:
            return False

        val = sensor.latest_raw_state
        now_state = float(val) if val is not None else 0.0

        # Check for day change
        if sensor.state_count > 1:
            was_time = time.localtime(sensor.previous_time)
            now_time = time.localtime(sensor.latest_time)

            if was_time.tm_year != now_time.tm_year or was_time.tm_mon != now_time.tm_mon or was_time.tm_mday != now_time.tm_mday:
                # Day changed - reset midnight state
                self._state_at_midnight = None
                self._states.clear()

        # Initialize midnight state if needed
        if self._state_at_midnight is None or now_state < self._state_at_midnight:
            self.run_persistence_coroutine(self._update_state_at_midnight(now_state))
            self._state_at_midnight = now_state

        # Calculate today's accumulation
        self._state_now = now_state - self._state_at_midnight
        self.set_latest_state(self._state_now)

        return True


class SimpleEnergyDailyAccumulationSensor(AccumulationSensor):
    """Daily energy accumulation sensor that resets to zero at midnight.

    Accumulates values using a Riemann sum throughout the day, automatically
    resetting the accumulated total to zero at midnight without requiring
    a baseline value from the source sensor.

    Unlike EnergyDailyAccumulationSensor, this doesn't track the source sensor's
    state at midnight - it simply accumulates and resets the total.
    """

    def __init__(
        self,
        name: str,
        unique_id: str,
        object_id: str,
        source: Sensor,
        **kwargs,
    ):
        # Set default energy values if not provided in kwargs
        if "data_type" not in kwargs:
            kwargs["data_type"] = ModbusDataType.UINT32
        if "unit" not in kwargs:
            kwargs["unit"] = UnitOfEnergy.KILO_WATT_HOUR
        if "device_class" not in kwargs:
            kwargs["device_class"] = DeviceClass.ENERGY
        if "state_class" not in kwargs:
            kwargs["state_class"] = StateClass.TOTAL_INCREASING
        if "icon" not in kwargs:
            kwargs["icon"] = "mdi:home-lightning-bolt"
        if "gain" not in kwargs:
            kwargs["gain"] = 1000
        if "precision" not in kwargs:
            kwargs["precision"] = 2

        super().__init__(
            name=name,
            unique_id=unique_id,
            object_id=object_id,
            source=source,
            **kwargs,
        )

        # Track the last day we saw to detect day changes
        self._last_day_tuple: tuple[int, int, int] | None = None

    def update_from_source_sensor(self, sensor: Sensor) -> bool:
        """Update daily accumulation from source values.

        Accumulates values throughout the day and resets the total at midnight.

        Args:
            sensor: Source sensor

        Returns:
            True if updated
        """
        if sensor is not self._source:
            logger.warning(f"{self.log_identity} Attempt to call update_from_source_sensor from {sensor.log_identity}")
            return False

        if sensor.latest_raw_state is None:
            return False

        # Check for day change by comparing year, month, day
        if sensor.state_count > 1:
            now_time = time.localtime(sensor.latest_time)
            current_day = (now_time.tm_year, now_time.tm_mon, now_time.tm_mday)

            # Reset if this is a new day
            if self._last_day_tuple is not None and self._last_day_tuple != current_day:
                if self.debug_logging:
                    logger.debug(f"{self.log_identity} Day changed from {self._last_day_tuple} to {current_day}, resetting accumulation")
                self._current_total = 0.0
                self.run_persistence_coroutine(self._persist_current_total(0.0))
                self._states.clear()

            self._last_day_tuple = current_day

        # Perform normal accumulation using parent's logic
        return super().update_from_source_sensor(sensor)
