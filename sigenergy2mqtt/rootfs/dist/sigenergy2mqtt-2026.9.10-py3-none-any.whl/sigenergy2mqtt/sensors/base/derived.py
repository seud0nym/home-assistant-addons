"""DerivedSensor base class for computed sensors."""

from __future__ import annotations

import abc
import asyncio
import logging
from collections.abc import Coroutine
from typing import Any

from pymodbus.pdu import ExceptionResponse

from sigenergy2mqtt.common import ProtocolVersion

from .constants import DiscoveryKeys
from .sensor import Sensor, TypedSensorMixin

logger = logging.getLogger(__name__)
# =============================================================================


class DerivedSensor(TypedSensorMixin, Sensor):
    """Base class for sensors that derive their values from other sensors.

    Derived sensors compute their state based on values from one or more
    source sensors rather than reading directly from Modbus.
    """

    def __init__(self, *args, source_sensors: tuple[Sensor, ...] = (), **kwargs):
        """Initialise the derived sensor.

        Args:
            source_sensors: The sensors whose values drive this sensor's state.
                            Subclasses should always supply this so that source
                            wiring is configured at construction time.
            **kwargs: Forwarded to the Sensor base class.
        """
        if "protocol_version" not in kwargs:
            kwargs["protocol_version"] = ProtocolVersion.N_A

        super().__init__(*args, **kwargs)
        self[DiscoveryKeys.ENABLED_BY_DEFAULT] = True
        self.bound_source_sensors: list[Sensor] = []
        self._pending_update: bool = False

        # Initialise source_sensors from the constructor argument.  Subclasses
        # that use deferred / cross-device binding start with an empty list and
        # populate it later via _declare_source_sensors() / finalise_binding().
        self.source_sensors: list[Sensor] = []
        if source_sensors:
            self._declare_source_sensors(*source_sensors)

    def _declare_source_sensors(self, *sensors: Sensor) -> None:
        """Internal helper – update source_sensors after construction.

        Ordinary subclasses must NOT call this directly; pass ``source_sensors``
        to ``__init__`` instead.  This method exists only for subclasses that
        perform deferred or cross-device binding (e.g.
        ``CrossDeviceDerivedSensor.finalise_binding``).
        """
        self.source_sensors = [s for s in sensors if s is not None]
        if not self.source_sensors:
            logger.error(f"{self.log_identity} - no declared source sensors")
        if not hasattr(self, "bound_source_sensors"):
            self.bound_source_sensors = []

    def bind_source_sensor(self, sensor: Sensor) -> None:
        if not hasattr(self, "bound_source_sensors"):
            self.bound_source_sensors = []
        if sensor not in self.bound_source_sensors:
            self.bound_source_sensors.append(sensor)
        if sensor.debug_logging:
            logger.debug(f"{self.log_identity} Added source sensor {sensor.log_identity}")
            # Force debug logging on derived sensors when source is being debugged
            self.debug_logging = True
            # Re-apply sensor overrides so that an explicit debug-logging=False override will be respected
            self.apply_sensor_overrides()

    def _log_unconsumed_source_value(self, source_name: str, value: Any, timestamp: float | None, sensor: Sensor) -> None:
        """Log when a cached source value is replaced before being consumed."""
        if value is None:
            return

        source_timestamp = getattr(sensor, "last_successful_read_time", None)
        if not isinstance(source_timestamp, (int, float)):
            source_timestamp = getattr(sensor, "latest_time", None)
        age = max(0.0, source_timestamp - timestamp) if isinstance(source_timestamp, (int, float)) and isinstance(timestamp, (int, float)) else None
        expected_interval = self._source_expected_interval(sensor)
        message = f"{self.log_identity} Overwriting unconsumed source value {source_name}={value}"
        if age is not None:
            message += f" (age={age:.2f}s"
            if expected_interval is not None:
                message += f" expected_interval={expected_interval}s"
            message += ")"
        if age is None or expected_interval is None or age > expected_interval:
            logger.warning(message)
        else:
            logger.debug(message)

    @staticmethod
    def _source_expected_interval(sensor: Sensor) -> int | None:
        scan_interval = getattr(sensor, "scan_interval", None)
        if isinstance(scan_interval, int):
            return max(1, 2 * scan_interval)

        source_sensors = getattr(sensor, "source_sensors", ())
        intervals = [getattr(source, "scan_interval", None) for source in source_sensors]
        intervals = [interval for interval in intervals if isinstance(interval, int)]
        return max(1, 2 * max(intervals)) if intervals else None

    @staticmethod
    def _source_timestamp(sensor: Sensor) -> float | None:
        timestamp = getattr(sensor, "last_successful_read_time", None)
        if isinstance(timestamp, (int, float)):
            return timestamp
        timestamp = getattr(sensor, "latest_time", None)
        return timestamp if isinstance(timestamp, (int, float)) and timestamp > 0 else None

    def set_latest_state(self, state: float | str | list[bool] | list[int] | list[float]) -> bool:
        """Update latest state and track pending updates for publishing."""
        self.mark_successful_read()
        try:
            updated = super().set_latest_state(state)
        except Exception:
            self._last_successful_read_time = self._previous_successful_read_time
            self._update_generation -= 1
            raise
        if updated:
            self._pending_update = True
        return updated

    async def publish(self, mqtt_client, transport, republish: bool = False) -> bool:
        published = await super().publish(mqtt_client, transport, republish=republish)
        if published and not republish:
            self._pending_update = False
        return published

    async def _update_internal_state(self, **kwargs) -> bool | Exception | ExceptionResponse:
        """Derived sensors check if they were updated by source sensors."""
        return bool(getattr(self, "_pending_update", False))

    def run_persistence_coroutine(self, coro: Coroutine[Any, Any, None]) -> None:
        """Run a coroutine in the background to persist state.

        Args:
            coro: The coroutine to run
        """
        # This is a fire and forget operation - we don't want to wait for the state to be persisted
        # 1. Try to get the running loop
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No running loop in current thread
            logger.warning(f"{self.log_identity} No running event loop available to persist state.")
            coro.close()
            return

        # 2. Try to schedule the task on the running loop
        try:
            loop.create_task(coro)
        except (RuntimeError, TypeError, ValueError) as e:
            logger.warning(f"{self.log_identity} Failed to persist state: {e}")
            coro.close()

    @abc.abstractmethod
    def update_from_source_sensor(self, sensor: Sensor) -> bool:
        """Apply values from source sensor to this derived sensor.

        Args:
            sensor: The source sensor providing values

        Returns:
            True if values were applied successfully
        """


# =============================================================================


class CrossDeviceDerivedSensor(DerivedSensor):
    """DerivedSensor whose sources may live on any Device in the same plant.

    There are two supported patterns for supplying pending sources:

    1. **Sources known at construction time** – call ``declare_cross_device_sources()``
       from ``__init__`` once the source sensor objects are available.  The
       sources are held in ``_pending_sources`` until the framework calls
       ``finalise_binding()``.

    2. **Sources discovered during binding** – override ``finalise_binding()``,
       find the sensor objects, then forward them to the base implementation::

           def finalise_binding(self, plant_index: int) -> bool:
               sources = ...  # discover from DeviceRegistry
               return super().finalise_binding(plant_index, *sources)

       In this pattern ``declare_cross_device_sources()`` is *not* called and
       ``_pending_sources`` is never used.

    Unlike ordinary DerivedSensors, these sensors are registered in all_sensors
    by _add_sensor without source validation — the validation occurs during
    finalise_binding() which searches all devices in the DeviceRegistry.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Sources declared via declare_cross_device_sources() (pattern 1);
        # kept separate from source_sensors until finalise_binding() runs.
        self._pending_sources: list[Sensor] = []

    def declare_cross_device_sources(self, *sensors: Sensor) -> None:
        """Record sources that may live on any device in the plant.

        Call this from ``__init__`` when the source sensor objects are already
        available at construction time (pattern 1).  Actual binding is completed
        by ``finalise_binding()`` once all devices exist.

        Subclasses that must *discover* their sources from the DeviceRegistry
        should use pattern 2 instead: pass the discovered sensors directly to
        ``super().finalise_binding(plant_index, *sources)`` and skip this method.
        """
        self._pending_sources = [s for s in sensors if s is not None]
        if not self._pending_sources:
            log_id = getattr(self, "_log_identity", self.__class__.__name__)
            logger.error(f"{log_id} - no declared cross-device sources")

    def finalise_binding(self, plant_index: int, *sources: Sensor) -> bool:
        """Wire up sources from the full device graph after all devices are constructed.

        Searches every device registered under *plant_index* for each pending
        source sensor. Applies protocol filtering and calls ``add_derived_sensor``
        / ``bind_source_sensor`` exactly as ``_add_sensor`` does for ordinary
        ``DerivedSensor`` instances.

        Must only be called after this sensor has been added to a device
        (i.e. ``parent_device`` is set) and after all sibling/peer devices for
        the plant have been constructed and registered in the ``DeviceRegistry``.

        Args:
            plant_index: The plant index to search for sources.
            *sources: Optional sensors discovered by a subclass override.  When
                supplied these replace ``_pending_sources`` entirely (pattern 2).
                Subclasses that use ``declare_cross_device_sources()`` in their
                ``__init__`` (pattern 1) should *not* pass this argument.

        Returns:
            True if at least one source was bound successfully.
        """

        from sigenergy2mqtt.devices.base.registry import DeviceRegistry

        owner_device = self.parent_device
        if owner_device is None:
            raise RuntimeError(f"{self.log_identity} finalise_binding called before sensor was added to a device")

        # Pattern 2: caller discovered sources themselves and passed them in.
        # Pattern 1: sources were declared via declare_cross_device_sources() in __init__.
        pending_sources = [s for s in sources if s is not None] if sources else self._pending_sources
        if not pending_sources:
            log_id = getattr(self, "_log_identity", self.__class__.__name__)
            logger.error(f"{log_id} - no pending cross-device sources to bind")
            return False

        added = False
        for pending in pending_sources:
            # Skip sources that violate the owner device's protocol version
            if owner_device.protocol_version > ProtocolVersion.N_A and pending.protocol_version > owner_device.protocol_version:
                logger.debug(f"{self.log_identity} skipped cross-device binding of {pending.__class__.__name__} - source protocol {pending.protocol_version} > device protocol {owner_device.protocol_version}")
                continue

            # Search all devices registered for this plant
            found: Sensor | None = None
            for device in DeviceRegistry.get(plant_index):
                found = device.get_sensor(pending.unique_id, search_children=True)
                if found:
                    break

            if not found:
                logger.warning(f"{self.log_identity} cannot bind cross-device source {pending.__class__.__name__} ({pending.unique_id}) - not found in plant {plant_index}")
                continue

            if found not in self.bound_source_sensors:
                found.add_derived_sensor(self)
                self.bind_source_sensor(found)
                added = True
                if self.debug_logging:
                    logger.debug(f"{self.log_identity} bound cross-device source {found.__class__.__name__} from {getattr(found.parent_device, 'log_identity', 'unknown')}")

        # Populate source_sensors from what was actually bound so that the
        # rest of the framework (protocol checks, etc.) can inspect it.
        self.source_sensors = list(self.bound_source_sensors)
        self._pending_sources = []
        return added
