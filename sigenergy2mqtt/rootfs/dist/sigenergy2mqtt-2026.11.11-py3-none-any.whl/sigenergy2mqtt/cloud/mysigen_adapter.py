"""Adapter for the vendored, unofficial mySigen app API."""

import asyncio
import json
import logging
import time
from collections.abc import Awaitable, Callable
from datetime import timedelta
from typing import Any, Final, TypeVar

from aiohttp import ClientError

from sigenergy2mqtt.metrics.metrics import Metrics

from .exceptions import (
    CloudControlAuthError,
    CloudControlRateLimitedError,
    CloudControlRejectedError,
    CloudControlUnavailableError,
    CloudControlUnsupportedError,
)
from .models import (
    Capabilities,
    InstantControlMode,
    InstantControlStatus,
    InstantOverrideCommand,
)
from .vendor.solidfox.sigenergy_cloud import (
    MYSIGEN_APP_VERSION,
    InstantManualMode,
    SigenergyCloudAPIError,
    SigenergyCloudAuthError,
    SigenergyCloudClient,
    SigenergyCloudError,
    SigenergyCloudRateLimitError,
)

_MODE_TO_APP_CODE = {
    InstantControlMode.CHARGE: InstantManualMode.CHARGING,
    InstantControlMode.DISCHARGE: InstantManualMode.DISCHARGING,
    InstantControlMode.HOLD: InstantManualMode.HOLD_BATTERY,
    InstantControlMode.SELF_CONSUMPTION: InstantManualMode.SELF_CONSUMPTION,
}
_APP_CODE_TO_MODE = {value: key for key, value in _MODE_TO_APP_CODE.items()}
_CAPABILITIES = Capabilities(
    features=frozenset(),
    min_duration=timedelta(minutes=1),
    max_duration=timedelta(minutes=1440),
)
_T = TypeVar("_T")

_TOPOLOGY_DEVICE_TYPES = {
    2: "Aio",  # All-in-One
    3: "Inverter",
    4: "Battery",
    5: "DcCharger",
    6: "AcCharger",
    8: "Gateway",
    9: "Meter",
}

logger = logging.getLogger(__name__)


def _api_error_indicates_availability(exc: SigenergyCloudAPIError) -> bool:
    """Return whether an API error contains a well-formed response from the cloud."""
    if exc.status_code is None or exc.status_code >= 500 or exc.response_body is None:
        return False
    try:
        payload = json.loads(exc.response_body)
    except json.JSONDecodeError:
        return False
    if not isinstance(payload, dict):
        return False
    code = payload.get("code")
    try:
        numeric_code = int(code) if isinstance(code, (int, str)) else None
    except ValueError:
        numeric_code = None
    return numeric_code is None or numeric_code < 500


class MySigenCloudAdapter:
    """Translate domain commands to the unofficial, vendored cloud client."""

    APP_VERSION: Final[str] = MYSIGEN_APP_VERSION

    def __init__(self, username: str, password: str, region: str) -> None:
        self._client = SigenergyCloudClient(username, password, region=region)
        self._connected = False
        self._connection_generation = 0
        self._connect_lock = asyncio.Lock()
        self._rate_limit_until = 0.0
        self._rate_limit_streak = 0
        self._rate_limit_generation = 0
        self._rate_limit_lock = asyncio.Lock()

    async def _wait_for_rate_limit(self) -> None:
        """Wait for the shared cloud cooldown before issuing another request."""
        if self._rate_limit_until <= 0:
            return
        async with self._rate_limit_lock:
            logged = False
            while (delay := self._rate_limit_until - time.monotonic()) > 0:
                if not logged:
                    logger.warning("mySigen Cloud rate limited; pausing requests for %.0f seconds", delay)
                    logged = True
                # A newer 429 may extend the deadline while this task sleeps.
                # Recheck it before allowing the request through.
                await asyncio.sleep(delay)

    def _raise_if_rate_limited(self) -> None:
        """Fail immediately, without waiting, while the shared cooldown is active."""
        if (delay := self._rate_limit_until - time.monotonic()) > 0:
            raise CloudControlRateLimitedError(f"mySigen Cloud rate limited for another {delay:.0f} seconds", retry_after=delay)

    def _record_rate_limit(self) -> float:
        """Extend a shared, exponentially increasing cooldown after HTTP 429."""
        self._rate_limit_streak += 1
        self._rate_limit_generation += 1
        delay = min(30.0 * (2 ** (self._rate_limit_streak - 1)), 900.0)
        self._rate_limit_until = max(self._rate_limit_until, time.monotonic() + delay)
        return max(0.0, self._rate_limit_until - time.monotonic())

    @property
    def model(self) -> str:
        return "mySigen Cloud (unofficial)"

    @property
    def station_id(self) -> str:
        """Return the station selected during cloud discovery."""
        if self._client.station_id is None:
            raise CloudControlUnavailableError("Cloud station has not been discovered")
        return self._client.station_id

    @property
    def capabilities(self) -> Capabilities:
        return _CAPABILITIES

    @property
    def connected(self) -> bool:
        return self._connected

    async def connect(self, *, wait_for_rate_limit: bool = True) -> None:
        """Connect to the cloud API, if not already connected.

        With ``wait_for_rate_limit=False``, an active cooldown raises
        :class:`CloudControlRateLimitedError` instead of delaying the login.
        """
        if not wait_for_rate_limit and not self._connected:
            self._raise_if_rate_limited()
        async with self._connect_lock:
            await self._connect_locked(wait_for_rate_limit=wait_for_rate_limit)

    async def _connect_locked(self, *, wait_for_rate_limit: bool = True) -> None:
        """Connect while the caller holds ``_connect_lock``."""
        if self._connected:
            return
        if wait_for_rate_limit:
            await self._wait_for_rate_limit()
        else:
            self._raise_if_rate_limited()
        started = time.monotonic()
        try:
            await self._client.connect()
            logger.info(f"Connected to {self._client.base_url} unofficial mySigen Cloud API v{MySigenCloudAdapter.APP_VERSION} (region={self._client.region})")
        except SigenergyCloudAuthError as exc:
            await Metrics.cloud_connection(connected=False, error=True)
            raise CloudControlAuthError(str(exc)) from exc
        except SigenergyCloudRateLimitError as exc:
            retry_after = self._record_rate_limit()
            await Metrics.cloud_connection(connected=False, error=True)
            raise CloudControlRateLimitedError(str(exc), retry_after=retry_after) from exc
        except (ClientError, SigenergyCloudError, OSError, TimeoutError) as exc:
            await Metrics.cloud_connection(connected=False, error=True)
            raise CloudControlUnavailableError(str(exc)) from exc
        except Exception:
            await Metrics.cloud_connection(connected=False, error=True)
            raise
        finally:
            await Metrics.cloud_connection_attempt(time.monotonic() - started)
        self._connected = True
        self._connection_generation += 1
        await Metrics.cloud_connection(connected=True)

    async def _reconnect(self, failed_generation: int, *, wait_for_rate_limit: bool = True) -> None:
        """Replace an invalid cloud login unless another task already did so.

        With ``wait_for_rate_limit=False``, an active cooldown raises
        :class:`CloudControlRateLimitedError` instead of delaying the login.
        """
        if not wait_for_rate_limit:
            self._raise_if_rate_limited()
        async with self._connect_lock:
            logger.debug(
                f"Reconnecting to {self._client.base_url} unofficial mySigen Cloud API v{MySigenCloudAdapter.APP_VERSION} (_connection_generation={self._connection_generation}, failed_generation={failed_generation})",
            )
            if self._connection_generation != failed_generation:
                return
            self._connected = False
            await Metrics.cloud_connection(connected=False, reconnect=True)
            await self._connect_locked(wait_for_rate_limit=wait_for_rate_limit)

    async def _invalidate_connection(self, failed_generation: int) -> None:
        """Invalidate a failed login without overwriting a newer connection."""
        async with self._connect_lock:
            if self._connection_generation == failed_generation:
                self._connected = False
                await Metrics.cloud_connection(connected=False)
                logger.debug(
                    f"Connection to {self._client.base_url} unofficial mySigen Cloud API v{MySigenCloudAdapter.APP_VERSION} invalidated (_connection_generation={self._connection_generation}, failed_generation={failed_generation})",
                )

    async def close(self) -> None:
        await self._client.close()
        self._connected = False
        await Metrics.cloud_connection(connected=False)
        logger.info(f"Disconnected from {self._client.base_url} unofficial mySigen Cloud API v{MySigenCloudAdapter.APP_VERSION} (region={self._client.region})")

    async def device_list(self) -> list[dict[str, Any]]:
        """Return app topology devices in the official cloud API shape."""
        topology = await self._cloud_operation(self._client.device_topology)
        devices: list[dict[str, Any]] = []
        for node in self._client.iter_topology_nodes(topology):
            raw_device_type = node.get("deviceType")
            if not isinstance(raw_device_type, int):
                continue
            device_type = _TOPOLOGY_DEVICE_TYPES.get(raw_device_type)
            offline = self._client.topology_node_is_offline(node)
            status = "Offline" if offline else "Normal" if offline is False else "Fault"
            attributes: dict[str, Any] = {}
            if device_type == "Battery" and node.get("batPosition") is not None:
                attributes["batPosition"] = node["batPosition"]
            if device_type == "Inverter" and node.get("ratedActivePower") is not None:
                attributes["ratedActivePower"] = node["ratedActivePower"]

            devices.append({
                "systemId": str(node.get("stationId") or topology.get("stationId") or ""),
                "serialNumber": str(node.get("snCode") or node.get("showSnCode") or ""),
                "deviceType": device_type,
                "status": status,
                "pn": str(node.get("deviceCode") or node.get("gatewayDeviceCode") or ""),
                "firmwareVersion": str(node.get("modelVersionStr") or ""),
                "attrMap": attributes,
            })
        return devices

    async def gateway_info(self) -> dict[str, Any]:
        """Return details and live grid-side values for the station gateway."""
        return await self._cloud_operation(self._client.gateway_info)

    async def gateway_status(self, *, wait_for_rate_limit: bool = True) -> dict[str, Any]:
        """Return the on/off-grid status of the station gateway.

        With ``wait_for_rate_limit=False``, raise
        :class:`CloudControlRateLimitedError` during a cooldown instead of waiting.
        """
        return await self._cloud_operation(self._client.gateway_status, wait_for_rate_limit=wait_for_rate_limit)

    async def set_gateway_off_grid(self, off_grid: bool) -> dict[str, Any]:
        """Manually take the plant off the grid, or return it to the grid.

        A cooldown raises :class:`CloudControlRateLimitedError` rather than delaying
        the command, because a late change to the grid connection could surprise
        whoever requested it.
        """
        return await self._cloud_operation(
            lambda: self._client.set_gateway_off_grid(off_grid),
            reject_api_errors=True,
            operation_name="set_gateway_off_grid",
            wait_for_rate_limit=False,
        )

    async def device_dynamic_info(self, device_type: int, sn_code: str) -> dict[str, Any]:
        return await self._cloud_operation(
            lambda: self._client.device_dynamic_info(device_type, sn_code),
            operation_name="device_dynamic_info",
        )

    async def device_static_info(self, device_type: int, sn_code: str) -> dict[str, Any]:
        return await self._cloud_operation(
            lambda: self._client.device_static_info(device_type, sn_code),
            operation_name="device_static_info",
        )

    async def battery_pack_merge_info(self, sn_code: str) -> dict[str, Any]:
        return await self._cloud_operation(
            lambda: self._client.battery_pack_merge_info(sn_code),
            operation_name="battery_pack_merge_info",
        )

    async def set_instant_override(self, command: InstantOverrideCommand) -> None:
        unsupported = []
        if command.power_kw is not None:
            unsupported.append("power limit")
        if command.charge_priority is not None or command.discharge_priority is not None:
            unsupported.append("source priority")
        if command.starts_at is not None:
            unsupported.append("scheduled start")
        if unsupported:
            raise CloudControlUnsupportedError(f"mySigen cloud backend does not support {', '.join(unsupported)}")
        if not self.capabilities.min_duration <= command.duration <= self.capabilities.max_duration:
            raise CloudControlRejectedError("Duration must be between 1 and 1440 minutes")
        duration_minutes = round(command.duration.total_seconds() / 60)
        await self._cloud_operation(
            lambda: self._client.set_instant_manual_control(_MODE_TO_APP_CODE[command.mode], duration_minutes=duration_minutes),
            reject_api_errors=True,
            operation_name="set_instant_manual_control",
        )

    async def clear_instant_override(self) -> None:
        await self._cloud_operation(self._client.disable_instant_manual_control)

    async def instant_control_status(self) -> InstantControlStatus:
        status = await self._cloud_operation(self._client.instant_manual_control)
        return InstantControlStatus(
            enabled=status.enabled,
            mode=_APP_CODE_TO_MODE.get(status.mode) if status.mode is not None else None,
            ends_at=float(status.end_time) if status.end_time is not None else None,
        )

    @staticmethod
    def _operation_name(
        operation: Callable[[], Awaitable[_T]],
        *,
        operation_name: str | None = None,
    ) -> str:
        """Return a human-readable name for a cloud operation."""
        if operation_name:
            return operation_name
        for candidate in (
            getattr(operation, "__name__", None),
            getattr(getattr(operation, "__func__", None), "__name__", None),
        ):
            if candidate and candidate != "<lambda>":
                return candidate
        return "cloud operation"

    async def _cloud_operation(
        self,
        operation: Callable[[], Awaitable[_T]],
        *,
        reject_api_errors: bool = False,
        operation_name: str | None = None,
        wait_for_rate_limit: bool = True,
    ) -> _T:
        """Run an operation, renewing a cloud login invalidated by the server.

        Logging in to the app on another device can invalidate an otherwise
        healthy session. Retry exactly once after re-authentication; persistent
        authentication failures are still reported to the caller.

        With ``wait_for_rate_limit=False``, an active cooldown raises
        :class:`CloudControlRateLimitedError` instead of delaying the operation.
        """
        if not wait_for_rate_limit:
            self._raise_if_rate_limited()
        await self.connect(wait_for_rate_limit=wait_for_rate_limit)
        generation = self._connection_generation
        operation_label = self._operation_name(operation, operation_name=operation_name)
        for attempt in range(2):
            if wait_for_rate_limit:
                await self._wait_for_rate_limit()
            else:
                self._raise_if_rate_limited()
            rate_limit_generation = self._rate_limit_generation
            started = time.monotonic()
            try:
                try:
                    logger.debug(f"mySigen {operation_label} executing (attempt {attempt + 1}/2, generation={generation})")
                    result = await operation()
                finally:
                    # Stop timing before error handling can reconnect. Login and
                    # station-discovery latency is tracked independently.
                    await Metrics.cloud_query(time.monotonic() - started)
                await Metrics.cloud_availability(True)
                if rate_limit_generation == self._rate_limit_generation:
                    self._rate_limit_streak = 0
                return result
            except SigenergyCloudRateLimitError as exc:
                retry_after = self._record_rate_limit()
                await Metrics.cloud_query_error(rate_limited=True)
                # A rate-limit response proves the API is reachable even though
                # it did not accept this request.
                await Metrics.cloud_availability(True)
                raise CloudControlRateLimitedError(str(exc), retry_after=retry_after) from exc
            except SigenergyCloudAuthError as exc:
                await Metrics.cloud_query_error(auth=True)
                if attempt == 0:
                    await self._reconnect(generation, wait_for_rate_limit=wait_for_rate_limit)
                    generation = self._connection_generation
                    continue
                await self._invalidate_connection(generation)
                raise CloudControlAuthError(str(exc)) from exc
            except ValueError as exc:
                await Metrics.cloud_query_error()
                if reject_api_errors:
                    raise CloudControlRejectedError(str(exc)) from exc
                raise
            except SigenergyCloudAPIError as exc:
                await Metrics.cloud_query_error()
                # Any well-formed non-5xx response proves availability, whether
                # it rejects a command or reports an application-level error.
                # Server errors and malformed responses indicate an outage.
                await Metrics.cloud_availability(_api_error_indicates_availability(exc))
                if reject_api_errors:
                    raise CloudControlRejectedError(str(exc)) from exc
                raise CloudControlUnavailableError(str(exc)) from exc
            except (ClientError, SigenergyCloudError, OSError, TimeoutError) as exc:
                await Metrics.cloud_query_error()
                # A transport failure says nothing about whether the server has
                # invalidated the authenticated session. Preserve it so the next
                # operation can retry without an avoidable password login and
                # station discovery, while reporting degraded reachability.
                await Metrics.cloud_availability(False)
                raise CloudControlUnavailableError(str(exc)) from exc
            except Exception:
                # Malformed or otherwise unexpected vendor responses are still
                # failed queries even when their exception is not normalized.
                await Metrics.cloud_query_error()
                await Metrics.cloud_availability(False)
                raise
        raise AssertionError("cloud operation retry loop exhausted")

    async def available_operational_modes(self) -> dict[str, Any]:
        return await self._cloud_operation(self._client.available_operational_modes)

    async def get_operational_mode(self) -> tuple[int, int]:
        return await self._cloud_operation(self._client.get_operational_mode)

    async def set_operational_mode(self, mode: int, profile_id: int = -1) -> dict[str, Any]:
        return await self._cloud_operation(
            lambda: self._client.set_operational_mode(mode, profile_id),
            operation_name="set_operational_mode",
        )

    async def grid_export_limit(self) -> dict[str, Any]:
        return await self._cloud_operation(self._client.grid_export_limit)

    async def set_grid_export_limit(self, limit_kw: float, *, enabled: bool = True) -> dict[str, Any]:
        return await self._cloud_operation(
            lambda: self._client.set_grid_export_limit(limit_kw, enabled=enabled),
            operation_name="set_grid_export_limit",
        )

    async def grid_import_limit(self) -> dict[str, Any]:
        return await self._cloud_operation(self._client.grid_import_limit)

    async def set_grid_import_limit(self, limit_kw: float, *, enabled: bool = True) -> dict[str, Any]:
        return await self._cloud_operation(
            lambda: self._client.set_grid_import_limit(limit_kw, enabled=enabled),
            operation_name="set_grid_import_limit",
        )

    async def grid_connection_limit(self) -> dict[str, Any]:
        return await self._cloud_operation(self._client.grid_connection_limit)

    async def set_grid_connection_limit(self, limit_a: float, *, enabled: bool = True) -> dict[str, Any]:
        return await self._cloud_operation(
            lambda: self._client.set_grid_connection_limit(limit_a, enabled=enabled),
            operation_name="set_grid_connection_limit",
        )

    async def battery_power_limit(self) -> dict[str, Any]:
        return await self._cloud_operation(self._client.battery_power_limit)

    async def set_battery_power_limit(self, *, max_charge_kw: float | None, max_discharge_kw: float | None) -> dict[str, Any]:
        return await self._cloud_operation(
            lambda: self._client.set_battery_power_limit(
                max_charge_kw=max_charge_kw,
                max_discharge_kw=max_discharge_kw,
            ),
            operation_name="set_battery_power_limit",
        )

    async def solar_power_limit(self) -> dict[str, Any]:
        return await self._cloud_operation(self._client.solar_power_limit)

    async def set_solar_power_limit(self, limit_kw: float | None) -> dict[str, Any]:
        return await self._cloud_operation(
            lambda: self._client.set_solar_power_limit(limit_kw),
            operation_name="set_solar_power_limit",
        )

    async def battery_export_limitation(self) -> dict[str, Any]:
        return await self._cloud_operation(self._client.battery_export_limitation)

    async def set_battery_export_limitation(self, enabled: bool) -> dict[str, Any]:
        return await self._cloud_operation(
            lambda: self._client.set_battery_export_limitation(enabled),
            operation_name="set_battery_export_limitation",
        )
