import asyncio
import logging
import time
from typing import Any, TypedDict

import requests
from requests.adapters import HTTPAdapter
from urllib3.exceptions import MaxRetryError
from urllib3.util.retry import Retry

from sigenergy2mqtt.common import ProtocolVersion, service_health_registry
from sigenergy2mqtt.config import active_config
from sigenergy2mqtt.devices import Device
from sigenergy2mqtt.influxdb.writers import V1HttpWriter, V2HttpWriter, Writer
from sigenergy2mqtt.metrics import Metrics

logger = logging.getLogger(__name__)

# Suppress verbose urllib3 connection logs at module level rather than per-instance,
# since the logger is a global singleton and mutating it in __init__ has side-effects.
logging.getLogger("urllib3").setLevel(logging.INFO)


class InfluxConfigValues(TypedDict):
    """Typed dictionary for resolved InfluxDB configuration values."""

    host: str
    port: int
    db: str
    user: str | None
    pwd: str | None
    token: str | None
    org: str | None
    bucket: str
    base: str
    auth: tuple[str, str] | None


class _ShutdownAwareRetry(Retry):
    """urllib3 :class:`~urllib3.util.retry.Retry` that aborts when shutdown is signalled.

    urllib3 calls :meth:`increment` *between* each attempt to decide whether to
    retry.  By raising :exc:`~urllib3.exceptions.MaxRetryError` there whenever
    :attr:`_shutdown_event` is set, we prevent any further attempt the instant
    the application goes offline — even if the *current* socket call is still
    blocking inside the C runtime.

    :attr:`_shutdown_event` holds an :class:`asyncio.Event`.
    ``asyncio.Event.is_set()`` is safe to call from a worker thread in CPython
    because the underlying ``_value`` attribute is a plain :class:`bool` whose
    read is atomic under the GIL.
    """

    _shutdown_event: asyncio.Event | None = None

    def new(self, **kw: Any) -> "_ShutdownAwareRetry":
        """Propagate the shutdown event to the cloned Retry urllib3 creates per attempt."""
        instance = super().new(**kw)
        instance._shutdown_event = self._shutdown_event
        return instance  # type: ignore[return-value]

    def increment(self, *args: Any, **kwargs: Any) -> Retry:
        """Raise MaxRetryError immediately if shutdown has been signalled."""
        if self._shutdown_event is not None and self._shutdown_event.is_set():
            raise MaxRetryError(None, None, "Shutdown in progress")  # type: ignore[arg-type]
        return super().increment(*args, **kwargs)


class InfluxBase(Device):
    """Base class for InfluxDB integration.

    Provides HTTP connection management, line-protocol serialisation, and
    batched writes. Subclasses are expected to call :meth:`async_init` before
    issuing writes.
    """

    def __init__(self, name: str, plant_index: int, unique: str, manufacturer: str, model: str) -> None:
        """Initialise shared state, HTTP session, and write buffers.

        No network I/O is performed here; call :meth:`async_init` to establish
        the InfluxDB connection asynchronously.

        Args:
            name: Human-readable service name used in log messages.
            plant_index: Zero-based index of the Modbus plant this instance serves.
            unique: Unique identifier string passed to the parent :class:`Device`.
            manufacturer: Manufacturer string for device registration.
            model: Model string for device registration.
        """
        super().__init__(name, plant_index, unique, manufacturer, model, ProtocolVersion.N_A)

        self.plant_index = plant_index

        # Enhanced connection pooling with retry strategy.
        # _ShutdownAwareRetry is used instead of plain Retry so that the
        # retry loop is aborted immediately when the service goes offline,
        # preventing urllib3 from scheduling further connection attempts
        # after a shutdown signal has been received.
        self._session = requests.Session()
        retry_strategy = _ShutdownAwareRetry(
            total=active_config.influxdb.max_retries,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
        )
        # Wire the shutdown event *after* super().__init__() has created it.
        retry_strategy._shutdown_event = self._shutdown_event
        adapter = HTTPAdapter(
            pool_connections=active_config.influxdb.pool_connections,
            pool_maxsize=active_config.influxdb.pool_maxsize,
            max_retries=retry_strategy,
        )
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)

        # Cache mapping state_topic -> {uom, object_id, unique_id}
        self._topic_cache: dict[str, dict[str, Any]] = {}

        # Batch write buffer
        self._write_buffer: list[str] = []
        self._batch_size: int = active_config.influxdb.batch_size
        self._batch_lock = asyncio.Lock()
        self._last_flush: float = time.time()
        self._flush_interval: float = active_config.influxdb.flush_interval

        # Writer selection is populated by _init_connection. Each writer owns
        # its endpoint-specific connection state.
        self._writer_type: str | None = None
        self._writers: dict[str, Writer] = {}

    # ------------------------------------------------------------------
    # Shutdown hook
    # ------------------------------------------------------------------

    @property  # type: ignore[override]
    def online(self) -> bool:  # type: ignore[override]
        """Whether the device is currently considered online."""
        return super().online  # type: ignore[misc]

    @online.setter  # type: ignore[override]
    def online(self, value) -> None:  # type: ignore[override]
        """Set the online status, closing the HTTP session on shutdown.

        Closing the session interrupts any in-flight blocking ``requests``
        calls (including retry loops in :meth:`_init_connection`) so that a
        single shutdown signal is sufficient to exit promptly even when
        InfluxDB is unreachable.
        """
        # Delegate to the Device base-class setter first so that all asyncio
        # bookkeeping (future cancellation, shutdown event, sleeper task
        # cancellation, etc.) is performed before we close the session.
        Device.online.fset(self, value)  # type: ignore[attr-defined]

        # Close the HTTP session when going offline so that any blocking
        # requests call running in a thread-pool worker raises immediately.
        if value is False:
            try:
                self._session.close()
            except OSError:  # pragma: no cover — best-effort cleanup
                pass

    @property
    def service_health_key(self) -> str:
        """Return the service health key for this InfluxDB service instance."""
        return f"influxdb_{self.plant_index}" if self.plant_index >= 0 else "influxdb"

    # ------------------------------------------------------------------
    # Connection initialisation helpers
    # ------------------------------------------------------------------

    def _init_connection(self) -> None:
        """Determine the InfluxDB API version and writable endpoint.

        Probes the server in preference order: v2 with token → v1 with
        credentials → v2 without token → v1 without auth.  The first
        successful probe registers the configured writer and sets
        :attr:`_writer_type`.

        Raises:
            RuntimeError: If no writable endpoint could be found or created.
        """
        config = self.get_config_values()
        test_line = b"state value=1"

        candidates: list[tuple[bool, Writer]] = [
            (bool(config["token"]), V2HttpWriter(config["base"], config["bucket"], config["org"], config["token"], self.log_identity)),
            (bool(config["user"]), V1HttpWriter(config["base"], config["db"], config["auth"], self.log_identity)),
            (True, V2HttpWriter(config["base"], config["bucket"], config["org"], None, self.log_identity)),
            (True, V1HttpWriter(config["base"], config["db"], None, self.log_identity)),
        ]
        for should_try, writer in candidates:
            if should_try and writer.probe(self._session, test_line):
                self._writers[writer.writer_type] = writer
                self._writer_type = writer.writer_type
                return
            if self._shutdown_event.is_set():
                return

        raise RuntimeError(f"{self.log_identity} Initialization failed: could not determine writable endpoint or create database/bucket")

    async def async_init(self) -> bool:
        """Asynchronously initialise the InfluxDB connection.

        Runs :meth:`_init_connection` in a thread to avoid blocking the event
        loop.  If InfluxDB is disabled in config this is a no-op.

        Returns:
            ``True`` if initialisation succeeded (or InfluxDB is disabled),
            ``False`` on any connection error.
        """
        if active_config.influxdb.enabled:
            try:
                await asyncio.to_thread(self._init_connection)
                return True
            except RuntimeError as e:
                logger.error(f"{self.log_identity} Initialization failed: {e}")
                service_health_registry.set_health(self.service_health_key, False)
                return False
        return True

    def copy_connection_from(self, source: "InfluxBase") -> None:
        """Copy established connection state from another :class:`InfluxBase` instance.

        Use this to share a single initialised connection across helper objects
        (e.g. :class:`~.hass_history_sync.HassHistorySync`) without repeating
        the probe handshake.

        Args:
            source: An already-initialised :class:`InfluxBase` whose writer
                attributes will be copied onto this instance.
        """
        self._session = source._session
        self._writer_type = source._writer_type
        self._writers = source._writers.copy()

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def get_config_values(self) -> InfluxConfigValues:
        """Resolve and return InfluxDB configuration values with backwards-compatibility handling.

        If no explicit token is configured but a password is provided without a
        username, the password is treated as a v2 API token (legacy behaviour).

        Returns:
            A :class:`InfluxConfigValues` dict containing all resolved connection
            parameters.
        """
        host = active_config.influxdb.host
        port = active_config.influxdb.port
        db = active_config.influxdb.database
        user = active_config.influxdb.username
        pwd = active_config.influxdb.password
        token = active_config.influxdb.token
        org = active_config.influxdb.org
        bucket = active_config.influxdb.bucket or db

        # Backwards-compat: if no explicit token provided but a password is
        # supplied and no username, treat the password as a v2 token.
        if not token and pwd and not user:
            token = pwd

        base = f"http://{host}:{port}"
        auth = (user, pwd) if user or pwd else None

        return {
            "host": host,
            "port": port,
            "db": db,
            "user": user,
            "pwd": pwd,
            "token": token,
            "org": org,
            "bucket": bucket,
            "base": base,
            "auth": auth,
        }

    # ------------------------------------------------------------------
    # Line protocol serialisation
    # ------------------------------------------------------------------

    def to_line_protocol(self, measurement: str, tags: dict, fields: dict, timestamp: int) -> str:
        """Serialise a data point to InfluxDB line protocol with second-precision timestamps.

        Both the v1 write endpoint (with ``precision=s``) and the v2 write URL
        (with ``precision=s`` in the query string) expect second-precision
        timestamps, so no conversion is applied beyond truncating to an integer.

        Args:
            measurement: Measurement name (slashes are replaced by the caller
                before passing here; spaces and commas are escaped internally).
            tags: Mapping of tag keys to string values.
            fields: Mapping of field keys to ``int``, ``float``, or ``str`` values.
                Integers are written with the ``i`` suffix; strings are quoted.
            timestamp: Unix timestamp in **seconds**.

        Returns:
            A single line-protocol string ready to be written to InfluxDB.
        """

        def esc_measurement(s: str) -> str:
            """Escape spaces and commas in measurement names."""
            return str(s).replace(" ", "\\ ").replace(",", "\\,")

        def esc_key(s: str) -> str:
            """Escape spaces, commas, and equals signs in tag keys, tag values, and field keys."""
            return str(s).replace(" ", "\\ ").replace(",", "\\,").replace("=", "\\=")

        def fmt_val(v: Any) -> str:
            """Format a field value according to line-protocol type rules."""
            if isinstance(v, int):
                return f"{v}i"
            if isinstance(v, float):
                return f"{v}"
            # Backslash must be escaped before quotes, or a trailing backslash
            # in the source value would swallow the escaped quote that follows it.
            escaped = str(v).replace(chr(92), chr(92) + chr(92)).replace(chr(34), chr(92) + chr(34))
            return f'"{escaped}"'

        tags_part = ",".join(f"{esc_key(k)}={esc_key(v)}" for k, v in tags.items()) if tags else ""
        fields_part = ",".join(f"{esc_key(k)}={fmt_val(v)}" for k, v in fields.items())

        # Emit seconds — must stay consistent with precision=s on both write URLs.
        ts_s = int(timestamp)
        return f"{esc_measurement(measurement)}{',' + tags_part if tags_part else ''} {fields_part} {ts_s}"

    # ------------------------------------------------------------------
    # Buffered writes
    # ------------------------------------------------------------------

    async def _flush_buffer_internal(self) -> None:
        """Flush the write buffer to InfluxDB in a single batched request.

        Must be called while holding :attr:`_batch_lock`.  Clears the buffer
        before issuing the network call so that new lines can be accepted
        immediately even if the write fails.
        """
        if not self._write_buffer:
            return

        batch = self._write_buffer
        self._write_buffer = []
        self._last_flush = time.time()

        batch_data = "\n".join(batch).encode("utf-8")
        batch_size = len(batch)
        start = time.time()

        try:
            success = await self.execute_write(batch_data)
            elapsed = time.time() - start
            if success:
                await Metrics.influxdb_write(batch_size, elapsed)
            else:
                await Metrics.influxdb_write_error()
        except (ValueError, TypeError, RuntimeError) as e:
            logger.error(f"InfluxDB batch write failed: {e} (type={self._writer_type} batch_size={batch_size})")
            await Metrics.influxdb_write_error()

    async def write_line(self, line: str) -> None:
        """Append a line-protocol string to the write buffer.

        The buffer is flushed immediately if it has reached :attr:`_batch_size`
        or if more than :attr:`_flush_interval` seconds have elapsed since the
        last flush.

        Args:
            line: A single line-protocol string as returned by
                :meth:`to_line_protocol`.
        """
        async with self._batch_lock:
            self._write_buffer.append(line)
            should_flush = len(self._write_buffer) >= self._batch_size or (time.time() - self._last_flush) >= self._flush_interval
            if should_flush:
                await self._flush_buffer_internal()

    async def flush_buffer(self) -> None:
        """Flush any pending buffered writes to InfluxDB immediately."""
        async with self._batch_lock:
            await self._flush_buffer_internal()

    async def execute_write(self, data: bytes) -> bool:
        """Send a pre-encoded line-protocol payload to InfluxDB over HTTP.

        Dispatches to either the v2 or v1 write endpoint depending on
        :attr:`_writer_type`.  Returns ``False`` without raising if the service
        is offline or the writer has not been initialised.

        Args:
            data: UTF-8 encoded line-protocol payload (one or more lines).

        Returns:
            ``True`` if InfluxDB accepted the payload (HTTP 200 or 204).
        """
        if not self.online:
            return False

        writer = self._writers.get(self._writer_type or "")
        if writer is None:
            return False
        try:
            success = await asyncio.to_thread(writer.write, self._session, data)
        except (OSError, requests.RequestException, TimeoutError) as e:
            logger.error(f"InfluxDB write failed: {e} (type={self._writer_type})")
            success = False
        service_health_registry.set_health(self.service_health_key, success)
        return success
