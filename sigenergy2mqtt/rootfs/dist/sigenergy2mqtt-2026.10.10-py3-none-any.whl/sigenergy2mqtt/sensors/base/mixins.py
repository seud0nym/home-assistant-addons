"""Sensor mixins for readable, writable, observable, and substitute behaviors."""

from __future__ import annotations

import abc
import asyncio
import logging
import re
import time
from typing import TYPE_CHECKING, Any, cast

import paho.mqtt.client as mqtt
from pymodbus.exceptions import ModbusException
from pymodbus.pdu import ExceptionResponse, ModbusPDU

from sigenergy2mqtt.common import Constants, DeviceClass, InputType
from sigenergy2mqtt.config import active_config
from sigenergy2mqtt.modbus import ModbusClient, ModbusDataType

from .constants import (
    DiscoveryKeys,
    ModbusLockFactory,
)
from .sensor import Sensor, SensorDebuggingMixin, TypedSensorMixin

try:
    from ._sigenergy_local_modbus_registers import SIGENERGY_LOCAL_MODBUS_REGISTERS
except ImportError:
    SIGENERGY_LOCAL_MODBUS_REGISTERS = {}

if TYPE_CHECKING:
    from sigenergy2mqtt.mqtt import MqttHandler

logger = logging.getLogger(__name__)
# =============================================================================


class ReadableSensorMixin(Sensor):
    """Mixin for sensors that can be read periodically.

    Adds scan interval configuration for periodic polling.
    """

    def __init__(self, **kwargs):
        if "scan_interval" not in kwargs:
            raise ValueError(f"{self.__class__.__name__}: Missing required parameter 'scan_interval'")

        if not isinstance(kwargs["scan_interval"], int):
            raise TypeError(f"{self.__class__.__name__}: scan_interval must be an int")

        if kwargs["scan_interval"] < 1:
            raise ValueError(f"{self.__class__.__name__}: scan_interval cannot be less than 1 second")

        self.scan_interval = kwargs.pop("scan_interval")
        super().__init__(**kwargs)

        # Apply scan interval overrides
        self._apply_scan_interval_overrides()

    def _apply_scan_interval_overrides(self) -> None:
        """Apply scan interval overrides from configuration."""
        for identifier in active_config.sensor_overrides:
            overrides = self._get_applicable_overrides(identifier)
            if overrides and "scan-interval" in overrides and self.scan_interval != overrides["scan-interval"]:
                logger.debug(f"{self.log_identity} Applying {identifier} 'scan-interval' override ({overrides['scan-interval']})")
                self.scan_interval = overrides["scan-interval"]

    def _get_applicable_overrides(self, identifier: str) -> dict | None:
        """Get override configuration if identifier matches this sensor.

        Args:
            identifier: The override identifier pattern

        Returns:
            Override configuration dict or None
        """
        pattern = re.compile(identifier)
        if self._matches_override_pattern(pattern):
            return active_config.sensor_overrides[identifier]
        return None


# =============================================================================
# Modbus Sensor Mixin
# =============================================================================


class ModbusSensorMixin(SensorDebuggingMixin):
    """Mixin for sensors that read/write Modbus registers.

    Provides Modbus-specific configuration and error handling.
    """

    # Modbus exception codes
    class ExceptionCode:
        ILLEGAL_FUNCTION = 1
        ILLEGAL_DATA_ADDRESS = 2
        ILLEGAL_DATA_VALUE = 3
        SLAVE_DEVICE_FAILURE = 4

    if TYPE_CHECKING:

        @property
        def log_identity(self) -> str: ...

        def refresh_log_identity(self) -> None: ...

    def __init__(self, input_type: InputType, plant_index: int, device_address: int, address: int, count: int, unique_id_override: str | None = None, **kwargs):
        # Validate parameters
        if not (1 <= device_address <= Constants.PLANT_DEVICE_ADDRESS):
            raise AssertionError(f"{self.__class__.__name__}: Invalid device address {device_address}")

        if address < 30000:
            raise AssertionError(f"{self.__class__.__name__}: Invalid address {address}")

        if count <= 0:
            raise AssertionError(f"{self.__class__.__name__}: Invalid count {count}")

        use_slm_naming = (  # Exclude combined alarm sensors from SLM naming otherwise will cause duplicate entity_id error
            not getattr(self, "alarms", None) and active_config.home_assistant.enabled and active_config.home_assistant.sigenergy_local_modbus_naming
        )
        slm_map = SIGENERGY_LOCAL_MODBUS_REGISTERS.get(address) if use_slm_naming else None

        if slm_map:
            self._original_object_id = kwargs.get(DiscoveryKeys.OBJECT_ID)  # Used in Sensor._get_base_topic so that the original object_id is used for topic generation and dashboard population
            kwargs[DiscoveryKeys.OBJECT_ID] = str(slm_map["object_id"])
            kwargs.pop(DiscoveryKeys.UNIT_OF_MEASUREMENT, None)
            uom = cast(str | None, slm_map.get("unit"))
            if uom == "s" and kwargs[DiscoveryKeys.DEVICE_CLASS] == DeviceClass.TIMESTAMP:
                pass  # Sigenergy-Local-Modbus register definitions incorrectly apply numeric UoM "s" to non-numeric device class "timestamp"
            elif uom is not None:
                kwargs["unit"] = uom
            kwargs["gain"] = cast(float | None, slm_map.get("gain"))

        # Set unique_id
        if unique_id_override is not None:
            kwargs[DiscoveryKeys.UNIQUE_ID] = unique_id_override
        else:
            kwargs[DiscoveryKeys.UNIQUE_ID] = f"{active_config.home_assistant.unique_id_prefix}_{plant_index}_{device_address:03d}_{address}"

        self.unique_id = kwargs[DiscoveryKeys.UNIQUE_ID]

        super().__init__(**kwargs)

        self.address = address
        self.count = count
        self.device_address = device_address
        self.input_type = input_type
        self.plant_index = plant_index
        self.illegal_data_address = False  # Set to True when 0x02 ILLEGAL_DATA_ADDRESS exception occurs
        self.refresh_log_identity()

    def _check_register_response(self, rr: ModbusPDU | None, source: str, **kwargs) -> bool:
        """Check and handle Modbus register response.

        Args:
            rr: Modbus response object
            source: Description of operation (for logging)

        Returns:
            True if response is valid

        Raises:
            Exception: For various Modbus error conditions
        """
        if rr is None:
            logger.error(f"{self.log_identity} Modbus {source} failed to read registers (None response)")
            return False

        if self.debug_logging:
            logger.debug(f"{self.log_identity} Modbus {source} response: {rr}")

        if not (rr.isError() or isinstance(rr, ExceptionResponse)):
            return True

        # Handle specific exception codes
        exc_code = rr.exception_code

        if exc_code == self.ExceptionCode.ILLEGAL_FUNCTION:
            self._handle_illegal_function(source, rr, **kwargs)
        elif exc_code == self.ExceptionCode.ILLEGAL_DATA_ADDRESS:
            self._handle_illegal_data_address(source, rr, **kwargs)
        elif exc_code == self.ExceptionCode.ILLEGAL_DATA_VALUE:
            self._handle_illegal_data_value(source, rr, **kwargs)
        elif exc_code == self.ExceptionCode.SLAVE_DEVICE_FAILURE:
            self._handle_slave_device_failure(source, rr, **kwargs)
        else:
            self._handle_unknown_exception(source, rr)

        return False

    def _handle_illegal_function(self, source: str, rr: ModbusPDU, **kwargs) -> None:
        """Handle illegal function exception."""
        logger.log(
            logging.ERROR if "skip_failure_logging" not in kwargs or not kwargs["skip_failure_logging"] else logging.DEBUG,
            f"{self.log_identity} Modbus {source} returned 0x01 ILLEGAL FUNCTION",
        )
        if self.debug_logging:
            logger.debug(rr)
        raise ModbusException("0x01 ILLEGAL FUNCTION")

    def _handle_illegal_data_address(self, source: str, rr: ModbusPDU, **kwargs) -> None:
        """Handle illegal data address exception."""
        logger.log(
            logging.ERROR if "skip_failure_logging" not in kwargs or not kwargs["skip_failure_logging"] else logging.DEBUG,
            f"{self.log_identity} Modbus {source} returned 0x02 ILLEGAL DATA ADDRESS {self.address} (count={self.count} type={self.input_type})",
        )
        if self.debug_logging:
            logger.debug(rr)

        # Mark this sensor as having an illegal data address
        self.illegal_data_address = True

        # Disable retries for invalid addresses on read operations
        if source != "write_registers":
            logger.log(
                logging.WARNING if "skip_failure_logging" not in kwargs or not kwargs["skip_failure_logging"] else logging.DEBUG,
                f"{self.log_identity} Setting max allowed failures to 0 for '{self.unique_id}' because of ILLEGAL DATA ADDRESS exception",
            )
            self._max_failures = 0
            self._max_failures_retry_interval = 0

        raise ModbusException("0x02 ILLEGAL DATA ADDRESS")

    def _handle_illegal_data_value(self, source: str, rr: ModbusPDU, **kwargs) -> None:
        """Handle illegal data value exception."""
        logger.log(
            logging.ERROR if "skip_failure_logging" not in kwargs or not kwargs["skip_failure_logging"] else logging.DEBUG,
            f"{self.log_identity} Modbus {source} returned 0x03 ILLEGAL DATA VALUE",
        )
        if self.debug_logging:
            logger.debug(rr)
        raise ModbusException("0x03 ILLEGAL DATA VALUE")

    def _handle_slave_device_failure(self, source: str, rr: ModbusPDU, **kwargs) -> None:
        """Handle slave device failure exception."""
        logger.log(
            logging.ERROR if "skip_failure_logging" not in kwargs or not kwargs["skip_failure_logging"] else logging.DEBUG,
            f"{self.log_identity} Modbus {source} returned 0x04 SLAVE DEVICE FAILURE",
        )
        if self.debug_logging:
            logger.debug(rr)
        raise ModbusException("0x04 SLAVE DEVICE FAILURE")

    def _handle_unknown_exception(self, source: str, rr: ModbusPDU, **kwargs) -> None:
        """Handle unknown exception."""
        logger.log(
            logging.ERROR if "skip_failure_logging" not in kwargs or not kwargs["skip_failure_logging"] else logging.DEBUG,
            f"{self.log_identity} Modbus {source} returned {rr}",
        )
        raise ModbusException(rr)


# =============================================================================
# Read-Only Sensor
# =============================================================================


class ObservableMixin(abc.ABC):
    """Mixin for sensors that can be observed/controlled via MQTT."""

    @abc.abstractmethod
    async def notify(self, transport: Any, mqtt_client: mqtt.Client, value: float | str, source: str, handler: MqttHandler) -> bool:
        """Handle notification of value change.

        Args:
            transport: Transport client (e.g. ModbusClient) or None for transport-independent sensors
            mqtt_client: MQTT client
            value: New value
            source: Source topic of the value
            handler: MQTT handler

        Returns:
            True if notification was handled
        """

    def observable_topics(self) -> set[str]:
        """Get set of MQTT topics this sensor observes.

        Returns:
            Set of topic strings
        """
        return set()


# =============================================================================
# Writeable Sensor Mixin
# =============================================================================


class WriteableSensorMixin(Sensor):
    """Mixin for sensors that accept MQTT commands independently of transport.

    Subclasses implement :meth:`_write_value` to deliver a validated command to
    their backing service.  The implementation may use Modbus, HTTP, an API, or
    no external transport at all.  Use :class:`ModbusWriteableSensorMixin` for
    the existing Modbus register implementation.
    """

    def __init__(self, availability_control_sensor=None, **kwargs):
        self.set_availability_control_sensor(availability_control_sensor)
        self._use_raw_for_availability = False
        super().__init__(**kwargs)

    def set_availability_control_sensor(self, sensor) -> None:
        """Set the sensor which gates writes and Home Assistant availability."""
        # Imported lazily because AvailabilityMixin is defined in sensor.py,
        # which also supplies the base class for this mixin.
        from .sensor import AvailabilityMixin

        if sensor is not None and not isinstance(sensor, AvailabilityMixin):
            raise TypeError(f"{self.__class__.__name__}: availability_control_sensor must be an instance of AvailabilityMixin")
        self._availability_control_sensor = sensor

    @property
    def command_topic(self) -> str:
        """Get the MQTT topic used to receive commands."""
        topic = cast(str, self.get(DiscoveryKeys.COMMAND_TOPIC))
        if not topic or topic.isspace():
            raise RuntimeError(f"{self.log_identity} command topic is not defined")
        return topic

    def _raw2state(self, raw_value: Any) -> Any:
        """Convert raw value to display state.

        Args:
            raw_value: Raw value from device

        Returns:
            Display-friendly state value
        """
        # Early return removed to allow string processing below

        # Lazy import to avoid circular dependencies
        from .writeable import (
            SelectSensorMixin,
            SwitchSensorMixin,
            WriteOnlySensorMixin,
        )

        # Handle Option-based sensors
        if DiscoveryKeys.OPTIONS in self and isinstance(raw_value, (int, float)):
            option = self._get_option(int(raw_value))
            if option:
                return option

        # Handle WriteOnlySensorMixin states
        if isinstance(self, WriteOnlySensorMixin):
            if raw_value in (self._values["off"], str(self._values["off"]), self._payloads.get("off")):
                return self._names["off"]
            elif raw_value in (self._values["on"], str(self._values["on"]), self._payloads.get("on")):
                return self._names["on"]
            return raw_value

        # Handle SwitchSensorMixin states
        if isinstance(self, SwitchSensorMixin) and isinstance(raw_value, str):
            if self[DiscoveryKeys.PAYLOAD_OFF] == raw_value:
                return "Off"
            elif self[DiscoveryKeys.PAYLOAD_ON] == raw_value:
                return "On"
            return raw_value

        # Handle SelectSensorMixin states
        if isinstance(self, SelectSensorMixin) and isinstance(raw_value, int):
            options = cast(list[str], self[DiscoveryKeys.OPTIONS])
            if raw_value < len(options):
                state = options[raw_value]
                if state not in ("", None):
                    return state
            return raw_value

        # Apply gain and precision
        if isinstance(raw_value, (float, int)):
            state = self._apply_gain_and_precision(raw_value)
            if state is not None:
                return state

        if isinstance(raw_value, str):
            return raw_value

        return raw_value

    def configure_mqtt_topics(self, device_id: str) -> str:
        """Configure the command topic in addition to normal sensor topics."""
        base = super().configure_mqtt_topics(device_id)
        self[DiscoveryKeys.COMMAND_TOPIC] = f"{base}/set"
        gate = self._availability_control_sensor
        if gate is not None and active_config.home_assistant.enabled:
            use_raw_topic = self._use_raw_for_availability and gate.publish_raw
            control_topic = cast(str | None, gate.get(DiscoveryKeys.RAW_STATE_TOPIC if use_raw_topic else DiscoveryKeys.STATE_TOPIC))
            if not control_topic or control_topic.isspace():
                topic_name = "raw_state_topic" if use_raw_topic else "state_topic"
                raise RuntimeError(f"{self.log_identity} - {gate.__class__.__name__} topic is not configured; {topic_name} has not been configured")
            availability = cast(list[dict[str, Any]], self[DiscoveryKeys.AVAILABILITY])
            availability.append({
                "topic": control_topic,
                "payload_available": gate._to_mqtt_payload(gate.payload_available),
                "payload_not_available": gate._to_mqtt_payload(gate.payload_not_available),
            })
        if self.debug_logging:
            logger.debug(f"{self.log_identity} >>> {DiscoveryKeys.COMMAND_TOPIC}={self[DiscoveryKeys.COMMAND_TOPIC]})")
        return base

    async def set_value(self, transport: Any, mqtt_client: mqtt.Client, value: float | str, source: str, handler: MqttHandler) -> bool:
        """Validate and dispatch an MQTT command through ``_write_value``."""
        gate = self._availability_control_sensor
        if gate is not None and gate.latest_raw_state != gate.payload_available:
            logger.error(f"{self.log_identity} Failed to write value '{value}': {gate.log_identity} state {gate.latest_raw_state!r} does not match available payload {gate.payload_available!r}")
            return False
        self.force_publish = True
        try:
            if not await self.value_is_valid(transport, value):
                return False
        except ModbusException as exc:
            logger.error(f"{self.log_identity} value_is_valid check of value '{value}' FAILED: {exc!r}")
            raise
        if source != self.command_topic:
            logger.error(f"{self.log_identity} Attempt to set value '{value}' from unknown topic {source}")
            return False
        return await self._write_value(transport, mqtt_client, value, source, handler)

    @abc.abstractmethod
    async def _write_value(self, transport: Any, mqtt_client: mqtt.Client, value: float | str, source: str, handler: MqttHandler) -> bool:
        """Deliver a validated command value using the sensor's transport."""

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        """Return whether a command value is accepted by this sensor."""
        return True


class ModbusWriteableSensorMixin(TypedSensorMixin, ModbusSensorMixin, WriteableSensorMixin):
    """WriteableSensorMixin implementation that writes values to Modbus registers."""

    async def _write_registers(self, modbus_client: ModbusClient, raw_value: float | str, mqtt_client: mqtt.Client) -> bool:
        """Write value to Modbus registers.

        Args:
            modbus_client: Modbus client for writing
            raw_value: Raw value to write
            mqtt_client: MQTT client for status updates

        Returns:
            True if write was successful
        """
        max_wait = 2
        device_id = self.device_address
        no_response_expected = False

        logger.info(f"{self.log_identity} _write_registers value={self._raw2state(raw_value)} (raw={raw_value} latest_raw_state={self.latest_raw_state} address={self.address} device_id={device_id})")

        # Convert value to registers
        registers = self._convert_value_to_registers(modbus_client, raw_value)
        method = "write_register" if len(registers) == 1 else "write_registers"

        self.force_publish = True

        try:
            return await self._perform_modbus_write(modbus_client, registers, device_id, no_response_expected, method)
        except asyncio.CancelledError:
            logger.warning(f"{self.log_identity} Modbus write interrupted")
            return False
        except TimeoutError:
            logger.warning(f"{self.log_identity} Modbus write failed to acquire lock within {max_wait}s")
            return False
        except ModbusException as e:
            from sigenergy2mqtt.metrics import Metrics

            logger.error(f"{self.log_identity} write_registers: {e!r}")
            await Metrics.modbus_write_error()
            raise

    def _convert_value_to_registers(self, modbus_client: ModbusClient, raw_value: float | str) -> list[int]:
        """Convert a value to Modbus register format.

        Args:
            modbus_client: Modbus client with conversion utilities
            raw_value: Value to convert

        Returns:
            List of register values
        """
        # Unsigned 8-bit integers don't need encoding
        if self.data_type == ModbusDataType.UINT16 and isinstance(raw_value, int) and 0 <= raw_value <= 255:
            return [raw_value]

        # String values
        if self.data_type == ModbusDataType.STRING:
            return modbus_client.convert_to_registers(str(raw_value), cast(Any, self.data_type))

        # Numeric values
        return modbus_client.convert_to_registers(int(raw_value), cast(Any, self.data_type))

    async def _perform_modbus_write(self, modbus_client: ModbusClient, registers: list[int], device_id: int, no_response_expected: bool, method: str) -> bool:
        """Perform the actual Modbus write operation.

        Args:
            modbus_client: Modbus client
            registers: Register values to write
            device_id: Target device ID
            no_response_expected: Whether to wait for response
            method: Method name for logging

        Returns:
            True if write was successful
        """
        start = time.monotonic()

        async with ModbusLockFactory.get(modbus_client).lock(2):  # max_wait=2
            if len(registers) == 1:
                rr = await modbus_client.write_register(self.address, registers[0], device_id=device_id, no_response_expected=no_response_expected)
            else:
                rr = await modbus_client.write_registers(self.address, registers, device_id=device_id, no_response_expected=no_response_expected)

        elapsed = time.monotonic() - start

        # Record metrics
        from sigenergy2mqtt.metrics import Metrics

        await Metrics.modbus_write(len(registers), elapsed)

        if self.debug_logging:
            logger.debug(
                f"{self.log_identity} {method}({self.address}, value={registers}, device_id={device_id}, no_response_expected={no_response_expected}) [plant_index={self.plant_index}] took {elapsed:.3f}s"
            )

        return self._check_register_response(rr, method)

    async def _write_value(self, transport: Any, mqtt_client: mqtt.Client, value: float | str, source: str, handler: MqttHandler) -> bool:
        """Write a validated command value to this sensor's Modbus register."""
        if not isinstance(transport, ModbusClient):
            raise TypeError(f"{self.log_identity}: _write_value requires a ModbusClient transport, got {type(transport)!r}")
        return await self._write_registers(transport, value, mqtt_client)

    async def value_is_valid(self, transport: Any, raw_value: float | str) -> bool:
        """Validate that a value is acceptable for this sensor.

        Args:
            transport: Transport client (not used for validation)
            raw_value: Value to validate

        Returns:
            True if value is valid
        """
        if raw_value is not None and isinstance(raw_value, (float, int)) and self.data_type in (ModbusDataType.UINT16, ModbusDataType.UINT32, ModbusDataType.UINT64) and raw_value < 0:
            raise ValueError(f"Negative value {raw_value} is not valid for unsigned data type {self.data_type.name}")
        return True


# =============================================================================
# Write-Only Sensor


# =============================================================================


class PVPowerSensor(ObservableMixin):
    """Mixin for PV power sensors that can be observed."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    async def notify(self, transport: Any, mqtt_client: mqtt.Client, value: float | str, source: str, handler: MqttHandler) -> bool:
        """Handle notification (currently no-op).

        Args:
            transport: Transport client or None (unused)
            mqtt_client: MQTT client
            value: Notification value
            source: Source topic
            handler: MQTT handler

        Returns:
            Always True
        """
        return True
