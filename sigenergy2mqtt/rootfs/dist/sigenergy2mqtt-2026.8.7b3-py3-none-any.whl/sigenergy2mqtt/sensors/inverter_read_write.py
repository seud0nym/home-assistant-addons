from sigenergy2mqtt.common import PERCENTAGE, DeviceClass, HybridInverter, InputType, Protocol, PVInverter, UnitOfPower, UnitOfReactivePower
from sigenergy2mqtt.config import active_config
from sigenergy2mqtt.modbus import ModbusDataType
from sigenergy2mqtt.sensors.base import NumericSensor, ReservedSensor, ScanInterval, WriteOnlySensor

# 5.4 Hybrid inverter parameter setting address definition (holding register)


class InverterStatus(WriteOnlySensor, HybridInverter, PVInverter):
    ADDRESS = 40500

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            name="Inverter Power On/Off",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_status",
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            protocol_version=Protocol.V1_8,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "0:Stop 1:Start"
        return attributes


class ReservedGridCode(ReservedSensor, HybridInverter):  # 40501 Marked as Reserved in v2.7 2025-05-23
    ADDRESS = 40501

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            name="Grid Code",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_grid_code",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=None,
            device_class=None,
            state_class=None,
            icon="mdi:earth",
            gain=None,
            precision=None,
            protocol_version=Protocol.V1_8,
        )


class DCChargerStatus(WriteOnlySensor, HybridInverter):
    ADDRESS = 41000

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            name="DC Charger Stop/Start",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_dc_charger_{device_address}",
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            protocol_version=Protocol.V1_8,
            payload_off="stop",
            payload_on="start",
            name_off="Stop",
            name_on="Start",
            icon_off="mdi:stop",
            icon_on="mdi:play",
            value_off=1,  # Values are inverted as per protocol to map to Home Assistant buttons
            value_on=0,  # Values are inverted as per protocol to map to Home Assistant buttons
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "0:Start 1:Stop"
        return attributes


class Reserved41001(ReservedSensor):
    ADDRESS = 41001

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            name="Reserved",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_reserved_41001",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.low(plant_index),
            unit=None,
            device_class=None,
            state_class=None,
            icon="mdi:comment-question",
            gain=None,
            precision=None,
            protocol_version=Protocol.V2_9,
        )


class DCChargerMaxChargingPowerLimit(NumericSensor, HybridInverter):
    ADDRESS = 41002

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            availability_control_sensor=None,
            name="Max Charging Power Limit",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_dc_charger_{device_address}_max_charging_power_limit",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.UINT32,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfPower.KILO_WATT,
            device_class=DeviceClass.POWER,
            icon="mdi:ev-station",
            gain=1000,
            precision=2,
            protocol_version=Protocol.V2_9,
            minimum=0.0,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Maximum DC charger charging power limit"
        return attributes


class DCChargerMaxDischargingPowerLimit(NumericSensor, HybridInverter):
    ADDRESS = 41004

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            availability_control_sensor=None,
            name="Max Discharging Power Limit",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_dc_charger_{device_address}_max_discharging_power_limit",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.UINT32,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfPower.KILO_WATT,
            device_class=DeviceClass.POWER,
            icon="mdi:ev-station",
            gain=1000,
            precision=2,
            protocol_version=Protocol.V2_9,
            minimum=0.0,
        )

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["comment"] = "Maximum DC charger discharging power limit"
        return attributes


class ReservedInverterRemoteEMSDispatch(ReservedSensor, PVInverter):  # 41500 Marked as Reserved in v2.8 2025-11-20
    ADDRESS = 41500

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            name="Remote EMS Dispatch",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_remote_ems_dispatch",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.UINT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=None,
            device_class=None,
            state_class=None,
            icon="mdi:toggle-switch",
            gain=None,
            precision=None,
            protocol_version=Protocol.V2_5,
        )


class InverterActivePowerFixedValueAdjustment(NumericSensor, PVInverter):
    ADDRESS = 41501

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            availability_control_sensor=None,
            name="Active Power Fixed Value Adjustment",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_active_power_fixed_value_adjustment",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.INT32,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfPower.KILO_WATT,
            device_class=DeviceClass.POWER,
            icon="mdi:lightning-bolt",
            gain=1000,
            precision=2,
            protocol_version=Protocol.V2_5,
        )


class InverterReactivePowerFixedValueAdjustment(NumericSensor, PVInverter):
    ADDRESS = 41503

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            availability_control_sensor=None,
            name="Reactive Power Fixed Value Adjustment",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_reactive_power_fixed_value_adjustment",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            count=2,
            data_type=ModbusDataType.INT32,
            scan_interval=ScanInterval.medium(plant_index),
            unit=UnitOfReactivePower.KILO_VOLT_AMPERE_REACTIVE,
            device_class=DeviceClass.REACTIVE_POWER,
            icon="mdi:lightning-bolt",
            gain=1000,
            precision=2,
            protocol_version=Protocol.V2_5,
        )


class InverterActivePowerPercentageAdjustment(NumericSensor, PVInverter):
    ADDRESS = 41505

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            availability_control_sensor=None,
            name="Active Power Percentage Adjustment",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_active_power_percentage_adjustment",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.INT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=PERCENTAGE,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:percent",
            gain=100,
            precision=None,
            protocol_version=Protocol.V2_5,
            minimum=-100.00,
            maximum=100.00,
        )


class InverterReactivePowerQSAdjustment(NumericSensor, PVInverter):
    ADDRESS = 41506

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            availability_control_sensor=None,
            name="Reactive Power Q/S Adjustment",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_reactive_power_q_s_adjustment",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.INT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=PERCENTAGE,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:lightning-bolt",
            gain=100,
            precision=None,
            protocol_version=Protocol.V2_5,
            minimum=-60.0,
            maximum=60.0,
        )


class InverterPowerFactorAdjustment(NumericSensor, PVInverter):
    ADDRESS = 41507

    def __init__(self, plant_index: int, device_address: int):
        super().__init__(
            availability_control_sensor=None,
            name="Power Factor Adjustment",
            object_id=f"{active_config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_power_factor_adjustment",
            input_type=InputType.HOLDING,
            plant_index=plant_index,
            device_address=device_address,
            address=self.ADDRESS,
            count=1,
            data_type=ModbusDataType.INT16,
            scan_interval=ScanInterval.medium(plant_index),
            unit=None,
            device_class=DeviceClass.POWER_FACTOR,
            icon="mdi:lightning-bolt",
            gain=1000,
            precision=2,
            protocol_version=Protocol.V2_5,
            minimum=-1.0,
            maximum=1.0,
        )
